WITH
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__21c18c79_2637_4618_bf70_809a6172e8be
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__5132187b_60dc_4b11_9c5e_da2c06658ec0
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 2 * lc.count_in_links
    ),
    nodes_to_delete_init_ttl AS (
        SELECT 
            r.reply_src_addr, 
            r.probe_dst_prefix, 
            r.probe_dst_addr, 
            r.probe_ttl
        FROM 
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    RankedResults AS (
        SELECT
            r.reply_src_addr,
            r.probe_dst_prefix,
            r.probe_dst_addr,
            r.probe_ttl,
            ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
        FROM 
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    filter_ttl AS (
        SELECT
            probe_dst_prefix,
            probe_dst_addr,
            probe_ttl
        FROM 
            RankedResults
        WHERE rn = 1
    ),
    results_filtered AS (
        SELECT
            r.*, r.probe_dst_prefix, ft.probe_ttl AS filtered_ttl
        FROM
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            r.probe_ttl < ft.probe_ttl
                
        UNION ALL

        SELECT
            r.*, r.probe_dst_prefix, 33 AS filtered_ttl
        FROM
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        LEFT JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            ft.probe_dst_prefix = '::'   
    ),
    ttl_distribution AS (
        SELECT 
            probe_dst_prefix,
            probe_ttl,
            COUNT(DISTINCT reply_src_addr) AS node_count
        FROM 
            results_filtered
        GROUP BY 
            probe_dst_prefix, probe_ttl
    ),
    aggregated_data AS (
        SELECT
            probe_dst_prefix,
            groupArray((probe_ttl, node_count)) AS ttl_pairs
        FROM
            ttl_distribution
        GROUP BY
            probe_dst_prefix
    ),
    prefix_ttl_summary AS (
        SELECT
            probe_dst_prefix,
            arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
            arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_node_counts
        FROM 
            aggregated_data
    )
SELECT 
    probe_dst_prefix,
    sorted_ttls AS ttls,
    sorted_node_counts AS node_counts
FROM 
    prefix_ttl_summary where probe_dst_prefix = '::ffff:160.238.100.0'

│ ::ffff:103.15.90.0   │ [1,3,15,16,17] │ [1,1,1,4,32] │

WITH
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__21c18c79_2637_4618_bf70_809a6172e8be
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__5132187b_60dc_4b11_9c5e_da2c06658ec0
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 2 * lc.count_in_links
    ),
    nodes_to_delete_init_ttl AS (
        SELECT 
            r.reply_src_addr, 
            r.probe_dst_prefix, 
            r.probe_dst_addr, 
            r.probe_ttl
        FROM 
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    RankedResults AS (
        SELECT
            r.reply_src_addr,
            r.probe_dst_prefix,
            r.probe_dst_addr,
            r.probe_ttl,
            ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
        FROM 
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    filter_ttl AS (
        SELECT
            probe_dst_prefix,
            probe_dst_addr,
            probe_ttl
        FROM 
            RankedResults
        WHERE rn = 1
    ),
    results_filtered AS (
        SELECT
            r.*, r.probe_dst_prefix, ft.probe_ttl AS filtered_ttl
        FROM
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            r.probe_ttl < ft.probe_ttl
                
        UNION ALL

        SELECT
            r.*, r.probe_dst_prefix, 33 AS filtered_ttl
        FROM
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        LEFT JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            ft.probe_dst_prefix = '::'   
    ),
    address_counts AS (
        SELECT 
            probe_dst_prefix,
            probe_ttl,
            reply_src_addr,
            COUNT(*) AS address_count
        FROM 
            results_filtered
        WHERE reply_src_addr != '::'
        GROUP BY 
            probe_dst_prefix, probe_ttl, reply_src_addr
    ),
    ttl_address_counts AS (
        SELECT
            probe_dst_prefix,
            probe_ttl,
            arraySort(groupArray(address_count)) AS sorted_address_counts  -- 确保每个地址计数数组内部排序
        FROM
            address_counts
        GROUP BY
            probe_dst_prefix, probe_ttl
    ),
    aggregated_data AS (
        SELECT
            probe_dst_prefix,
            groupArray((probe_ttl, sorted_address_counts)) AS ttl_pairs
        FROM
            ttl_address_counts
        GROUP BY
            probe_dst_prefix
    ),
    prefix_ttl_summary AS (
        SELECT
            probe_dst_prefix,
            arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
            arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_address_counts
        FROM 
            aggregated_data
    )
SELECT 
    probe_dst_prefix,
    sorted_ttls AS ttls,
    sorted_address_counts AS address_counts
FROM 
    prefix_ttl_summary where probe_dst_prefix = '::ffff:160.238.100.0'

   ┌─probe_dst_prefix─────┬─ttls──┬─address_counts──────────────────────────────────────────────────────────────────────┐
1. │ ::ffff:160.238.100.0 │ [1,3] │ [[11,15,26,29],[6,6,6,7,7,7,7,7,7,7,7,7,7,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,485]] │
   └──────────────────────┴───────┴─────────────────────────────────────────────────────────────────────────────────────┘

WITH
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__21c18c79_2637_4618_bf70_809a6172e8be
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__21c18c79_2637_4618_bf70_809a6172e8be
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 2 * lc.count_in_links
    ),
    nodes_to_delete_init_ttl AS (
        SELECT 
            r.reply_src_addr, 
            r.probe_dst_prefix, 
            r.probe_dst_addr, 
            r.probe_ttl
        FROM 
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    RankedResults AS (
        SELECT
            r.reply_src_addr,
            r.probe_dst_prefix,
            r.probe_dst_addr,
            r.probe_ttl,
            ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
        FROM 
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    filter_ttl AS (
        SELECT
            probe_dst_prefix,
            probe_dst_addr,
            probe_ttl
        FROM 
            RankedResults
        WHERE rn = 1
    ),
    results_filtered AS (
        SELECT
            r.*, r.probe_dst_prefix, ft.probe_ttl AS filtered_ttl
        FROM
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            r.probe_ttl < ft.probe_ttl
                
        UNION ALL

        SELECT
            r.*, r.probe_dst_prefix, 33 AS filtered_ttl
        FROM
            results__21c18c79_2637_4618_bf70_809a6172e8be r
        LEFT JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            ft.probe_dst_prefix = '::'   
    ),
    ttl_distribution AS (
        SELECT 
            probe_dst_prefix,
            probe_ttl,
            COUNT(DISTINCT reply_src_addr) AS node_count
        FROM 
            results_filtered
        GROUP BY 
            probe_dst_prefix, probe_ttl
    ),
    aggregated_data AS (
        SELECT
            probe_dst_prefix,
            groupArray((probe_ttl, node_count)) AS ttl_pairs
        FROM
            ttl_distribution
        GROUP BY
            probe_dst_prefix
    ),
    prefix_ttl_summary AS (
        SELECT
            probe_dst_prefix,
            arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
            arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_node_counts
        FROM 
            aggregated_data
    ),
    address_counts AS (
        SELECT 
            probe_dst_prefix,
            probe_ttl,
            reply_src_addr,
            COUNT(*) AS address_count
        FROM 
            results_filtered
        WHERE reply_src_addr != '::'
        GROUP BY 
            probe_dst_prefix, probe_ttl, reply_src_addr
    ),
    ttl_address_counts AS (
        SELECT
            probe_dst_prefix,
            probe_ttl,
            arraySort(groupArray(address_count)) AS sorted_address_counts  -- 确保每个地址计数数组内部排序
        FROM
            address_counts
        GROUP BY
            probe_dst_prefix, probe_ttl
    ),
    aggregated_data_y AS (
        SELECT
            probe_dst_prefix,
            groupArray((probe_ttl, sorted_address_counts)) AS ttl_pairs
        FROM
            ttl_address_counts
        GROUP BY
            probe_dst_prefix
    ),
    prefix_ttl_summary_y AS (
        SELECT
            probe_dst_prefix,
            arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
            arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_address_counts
        FROM 
            aggregated_data_y
    ),
    parameter AS (
        SELECT 
            probe_dst_prefix,
            sorted_ttls AS ttls,
            sorted_node_counts AS list_n,
            sorted_address_counts AS list_y
        FROM 
            prefix_ttl_summary_y y
        JOIN
            prefix_ttl_summary p
        ON
            p.probe_dst_prefix = y.probe_dst_prefix
    )
SELECT 
    DISTINCT
    (ttls, list_n, list_y)
FROM
    parameter

WHERE
    probe_dst_prefix = '::ffff:160.238.100.0'

   ┌─probe_dst_prefix─────┬─ttls──┬─list_n─┬─list_y────────────────────────────────────────────────────────────────────┐
1. │ ::ffff:160.238.100.0 │ [1,3] │ [4,27] │ [[11,15,26,29],[6,6,6,7,7,7,7,7,7,7,7,7,7,8,8,8,8,8,8,8,8,8,8,8,8,8,485]] │
   └──────────────────────┴───────┴────────┴───────────────────────────────────────────────────────────────────────────┘

   ┌─probe_dst_prefix─────┬─ttls──┬─address_counts──────────────────────────────────────────────────────────────────────┐
1. │ ::ffff:194.165.27.0  │ [1,3] │ [[1,1,1,6,7,9,9],[2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4]] │
   └──────────────────────┴───────┴─────────────────────────────────────────────────────────────────────────────────────┘
   第一跳7个节点：如果按均匀分布，那么随机一条流经过每个节点的概率是1/7，则对应的统计保证是33个包，如果按实际分布算，则第一个节点对应的统计保证是165个包
   第三跳32个节点：如果按均匀分布，那么随机一条流经过每个节点的概率是1/32，对应的统计保证是204个包，如果按实际分布算，则最后一个节点对应的统计保证是137个包


   select distinct reply_src_addr from results__21c18c79_2637_4618_bf70_809a6172e8be where probe_dst_prefix='::ffff:194.165.27.0' and probe_ttl=1

   ┌─reply_src_addr───────┐
1. │ ::ffff:10.222.104.6  │
2. │ ::ffff:10.220.2.6    │
3. │ ::ffff:10.222.113.6  │
4. │ ::ffff:10.222.104.18 │
5. │ ::ffff:10.220.3.18   │
6. │ ::ffff:10.222.113.18 │
   └──────────────────────┘
   ┌─reply_src_addr─────┐
7. │ ::ffff:10.220.2.18 │
   └────────────────────┘

probe_dst_addr：
   ┌─probe_dst_addr───────┐
1. │ ::ffff:194.165.27.18 │
2. │ ::ffff:194.165.27.25 │
3. │ ::ffff:194.165.27.27 │
4. │ ::ffff:194.165.27.39 │
5. │ ::ffff:194.165.27.41 │
6. │ ::ffff:194.165.27.42 │
7. │ ::ffff:194.165.27.58 │
8. │ ::ffff:194.165.27.60 │
9. │ ::ffff:194.165.27.61 │
   └──────────────────────┘
    ┌─probe_dst_addr───────┐
10. │ ::ffff:194.165.27.0  │
11. │ ::ffff:194.165.27.3  │
12. │ ::ffff:194.165.27.4  │
13. │ ::ffff:194.165.27.7  │
14. │ ::ffff:194.165.27.10 │
15. │ ::ffff:194.165.27.11 │
16. │ ::ffff:194.165.27.12 │
17. │ ::ffff:194.165.27.13 │
18. │ ::ffff:194.165.27.15 │
19. │ ::ffff:194.165.27.17 │
    └──────────────────────┘
    ┌─probe_dst_addr───────┐
20. │ ::ffff:194.165.27.23 │
21. │ ::ffff:194.165.27.28 │
22. │ ::ffff:194.165.27.33 │
23. │ ::ffff:194.165.27.37 │
24. │ ::ffff:194.165.27.38 │
25. │ ::ffff:194.165.27.40 │
26. │ ::ffff:194.165.27.43 │
27. │ ::ffff:194.165.27.44 │
28. │ ::ffff:194.165.27.46 │
29. │ ::ffff:194.165.27.49 │
30. │ ::ffff:194.165.27.51 │
31. │ ::ffff:194.165.27.52 │
32. │ ::ffff:194.165.27.56 │
33. │ ::ffff:194.165.27.57 │
34. │ ::ffff:194.165.27.67 │
    └──────────────────────┘

第一跳：
10.4.164.82
10.4.168.82
10.4.172.82
10.4.176.82