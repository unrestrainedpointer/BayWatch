import geoip2.database
import ipaddress

# 1. 打开 GeoLite2-Country.mmdb 数据库
reader = geoip2.database.Reader('/root/NSDI_24/rgmda/examples/GeoLite2-Country.mmdb')

# 2. 打开 prefixes_full_14_000_000 文件并读取前 100000 行
input_file = '/root/NSDI_24/rgmda/examples/utils/prefixes_full_14_000_000'
output_file = '/root/NSDI_24/rgmda/examples/utils/Singapore'

with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
    count = 0
    for line in infile:
        if count >= 100000:
            break

        prefix = line.strip()
        # 确保是一个有效的 /24 前缀
        try:
            network = ipaddress.ip_network(prefix)
        except ValueError:
            continue

        # 3. 获取前缀的起始 IP 地址
        ip = str(network.network_address)

        try:
            # 使用 GeoLite2 库进行定位
            response = reader.country(ip)
            if response.country.iso_code == 'SG':  # SG 是新加坡的国家代码
                # 4. 打印新加坡的前缀到输出文件
                outfile.write(prefix + '\n')
        except geoip2.errors.AddressNotFoundError:
            continue

        count += 1

# 关闭数据库
reader.close()

print("已将位于新加坡的前缀保存到文件:", output_file)