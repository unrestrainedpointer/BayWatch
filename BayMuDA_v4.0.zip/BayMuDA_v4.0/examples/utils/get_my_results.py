from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import LinksQuery, results_table
from diamond_miner.typing import IPNetwork

@dataclass(frozen=True)
class Query_results(LinksQuery):
    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        return f'''
        WITH
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            groupArray((probe_ttl, reply_src_addr)) AS nodes
        SELECT
            uniq_nodes,
            arrayMap(t -> (t.1, countEqual(nodes, t)), uniq_nodes),
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM {results_table(measurement_id)}
        WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
        '''