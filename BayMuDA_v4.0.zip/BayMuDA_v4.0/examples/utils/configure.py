import logging
from uuid import uuid4

# Configuration
credentials = {
    "base_url": "http://localhost:8123",
    "database": "default",
    "username": "default",
    "password": "",
}

# measurement_id, start_number, prefix_num, prefixes, process_num, pps = str(uuid4()), 5385551, 10771100, [], 24, 500_000
measurement_id, start_number, prefix_num, prefixes, process_num, pps = str(uuid4()), 0, 10000, [], 16, 100_000
k_core = 16
# measurement_id = '067095a8-2a81-406d-b82d-4bd839bc4e46'
# ICMP traceroute towards every /24 in 1.0.0.0/22 starting with 6 flows per prefix between TTLs 2-32
'''
prefixes = [("8.65.232.0/24", "udp", range(2, 33), 6)]
'''
path = '/root/multipath-scanning/BayMuDA_v4.0/examples/utils/prefixes_full_14_000_000'
# path = '/root/SIGCOMM_25/Ground_truth/_3_probe_dst_prefix_first_10000.txt'
# path = '/root/SIGCOMM_25/Ground_truth/unique_probe_dst_prefixes.txt'
with open(path, 'r', encoding='utf-8') as f:
    i = 0
    prefix = f.readline()
    while prefix:
        if '.0' not in prefix or i < start_number:
            i += 1
            prefix = f.readline()
            continue
        prefixes.append((prefix.rstrip() + '/24', 'udp', range(2, 33), 6))
        i += 1
        if i == prefix_num:
            break
        prefix = f.readline()
    f.close()

'''
campus_network = [
    '202.112.38.146/32',
    '202.112.38.70/32',
    '202.112.38.6/32',
    '219.243.214.224/30',
    '2001:da8:a0:1003::2/64',
    '202.112.38.142/32',
    '2001:da8:a0:1004::2/64',
    '202.112.38.10/32',
    '2001:da8:a0:1001::2/64',
    '202.112.38.2/32',
    '118.229.4.69/32',
    '118.229.4.70/32',
    '118.229.4.5/32',
    '118.229.4.6/32',
    '118.229.4.37/30',
    '118.229.4.81/30',
    '118.229.2.65/30',
    '118.229.2.17/30',
    '172.17.2.21/30',
    '172.17.2.25/30',
    '172.17.2.29/30',
    '118.229.2.21/30',
    '118.229.2.1/30',
    '118.229.2.5/30',
    '118.229.2.77/30',
    '118.229.2.37/30',
    '118.229.2.13/30',
    '118.229.2.17/30',
    '118.229.2.29/30',
    '118.229.2.33/30',
    '172.17.2.33/30',
    '172.17.2.37/30',
    '172.17.2.41/30',
    '172.17.2.45/30'
]
prefixes, index_max = [], 0
for prefix in campus_network:
    prefixes.append((prefix, "udp", range(2, 33), 6))
    if index_max == 0:
        break
    index_max += 1

prefixes = [("219.243.214.224/30", "udp", range(2, 33), 6)]
'''
ALERT_LEVEL = 60
logging.addLevelName(ALERT_LEVEL, "ALERT")

# 定义一个日志记录函数
def alert(self, message, *args, **kws):
    if self.isEnabledFor(ALERT_LEVEL):
        self._log(ALERT_LEVEL, message, args, **kws)

# 将新的日志级别方法添加到 logging.Logger 类
logging.Logger.alert = alert

# 设置日志配置
logging.basicConfig(level=ALERT_LEVEL)

# 使用新定义的日志级别
logger = logging.getLogger(__name__)