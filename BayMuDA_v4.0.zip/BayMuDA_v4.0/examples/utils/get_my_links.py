from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import LinksQuery, ResultsQuery, links_table, results_table
from diamond_miner.typing import IPNetwork

@dataclass(frozen=True)
class Query_num_postaddr(LinksQuery):
    
    def statement(self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET) -> str:
        # 使用self.near_or_far_addr作为过滤条件
        near_addr = self.near_addr or '::'
        return f'''
        SELECT COUNT(DISTINCT far_addr) AS unique_far_addr_count
        FROM {links_table(measurement_id)}
        WHERE {self.filters(subset)} AND near_addr = '{near_addr}'
        '''

@dataclass(frozen=True)
class Query_num_addr(ResultsQuery):
    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        addr = self.node_addr or '::'

        return f'''
        SELECT COUNT(*) AS unique_far_addr_count
        FROM {results_table(measurement_id)}
        WHERE {self.filters(subset)} and reply_src_addr = '{addr}'
        '''

class Query_postaddr(LinksQuery):
    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        near_addr = self.near_addr or '::'
        prefix = self.prefix or '::'
         
        return f'''
        SELECT far_addr
        FROM {links_table(measurement_id)}
        WHERE {self.filters(subset)} and near_addr = '{near_addr}' and probe_dst_prefix = '{prefix}'
        '''

class Query_postaddr_2(LinksQuery):
    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        near_addr = self.near_addr or '::'
        prefix = self.prefix or '::'

        return f'''
        SELECT DISTINCT far_addr
        FROM {links_table(measurement_id)}
        WHERE {self.filters(subset)} and near_addr = '{near_addr}' and probe_dst_prefix != '{prefix}'
        '''
    
class Query_postaddr_count(LinksQuery):
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        near_addr = self.near_or_far_addr
        print(near_addr)

        return f'''
        SELECT count(DISTINCT far_addr)
        FROM {links_table(measurement_id)}
        WHERE near_addr = '{near_addr}' and far_addr != '::'
        '''

# 得到该前缀下和node目标地址一样且ttl大于等于node的地址列表filter_participant
class Query_target(ResultsQuery):
    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        node = self.node_addr
        prefix = self.filter_destination_prefix

        return f'''
        SELECT DISTINCT probe_dst_addr
        FROM {results_table(measurement_id)}
        WHERE reply_src_addr = '{node}' and toString(probe_dst_addr) like '{prefix[0: len(prefix) - 1] + '%'}'
        '''

class Query_ttllarge_addrs(ResultsQuery):
    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        node_ttl = self.node_ttl or '::'
        probe_dst_addr = self.probe_dst_addr or '::'
        # print(f"probe_dst_addr: {probe_dst_addr}")

        return f'''
        SELECT (probe_ttl, reply_src_addr)
        FROM {results_table(measurement_id)}
        WHERE probe_dst_addr = '{probe_dst_addr}' and probe_ttl > {node_ttl}
        '''