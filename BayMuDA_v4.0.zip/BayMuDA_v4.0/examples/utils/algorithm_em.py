from collections import Counter
from diamond_miner.defaults import DEFAULT_FAILURE_RATE
from math import ceil
import numpy as np
import math
import torch
from utils.algorithm_utils import cal_ttl_init, generate_dict, gini_coefficient
from utils.neural_network import cal_m_k, cal_n_k, TopologyNeuralNetwork, train

def calculate_i(ttl_inital, keys):
    if ttl_inital == 2: 
        return -1
    for i_tmp in range(len(keys)):
        if keys[i_tmp] == ttl_inital:
            i = i_tmp
            return i
    return -1

def calculate_initial_distribution(y, is_finished):
    count = list(Counter(y).values())
    if not is_finished:
        count.append(0)
    return count

def calculate_matrix(matrix, shape):
    initial_matrix = np.zeros(shape)
    for elem in matrix:
        # print(f"elem: {elem}")
        # pos_tmp = elem['id_pair']
        pos_tmp = elem[0]
        # pos, value = (pos_tmp['near_id'], pos_tmp['far_id']), elem['id_pair_count']
        pos, value = (pos_tmp[0], pos_tmp[1]), elem[1]
        if pos[0]-1 < shape[0] and pos[1]-1 < shape[1]:
            initial_matrix[pos[0]-1][pos[1]-1] = value
    initial_matrix = initial_matrix.tolist()
    for i in range(len(initial_matrix)):
        initial_matrix[i] = torch.softmax(torch.tensor(initial_matrix[i], dtype=torch.float32), dim=0).tolist()
    return initial_matrix

def can_multiply_matrices(matrix_list):
    if len(matrix_list) < 2:
        return True  # 只有一个矩阵或者没有矩阵时，可以认为是可以连乘的
    
    for i in range(len(matrix_list) - 1):
        cols_a = len(matrix_list[i][0])
        rows_b = len(matrix_list[i + 1])
        
        if cols_a != rows_b:
            return False  # 如果前一个矩阵的列数不等于后一个矩阵的行数，无法连乘
    
    return True  # 所有相邻的矩阵都可以连乘

def f_or_not(ttl, prefix, finished_ttl_by_round_p):
    return ttl in finished_ttl_by_round_p['ll_round'] or ttl in finished_ttl_by_round_p['l_round']

def process_result(dict_result, finished_ttl_by_round_p, round_):
    model_structure, prefix = {}, dict_result['probe_dst_prefix']
    # print(f"dict_result: {dict_result}")
    dict_ttls, dict_y = generate_dict(dict_result['ttls'], dict_result['list_n'], dict_result['list_y'], dict_result['ttl_and_probes_array'])
    dict_ttls = {k: dict_ttls[k] for k in sorted(dict_ttls, reverse=True)}
    # for item in dict_result['ttl_pairs']:
        # print(f"item: {item}\n")
    # dict_matrixes = {item['near_ttl']: item['id_pairs'] for item in dict_result['ttl_pairs']}
    dict_matrixes = {item[0]: item[1] for item in dict_result['ttl_pairs']}

    keys, i = list(dict_ttls.keys()), 0
    loop_count = 0
    while i < len(keys) and i >= 0:
        loop_count += 1
        if loop_count > 10:
            print(f"Looping Exception: {loop_count}")
            break
        ttl_final = keys[i]
        ttl_inital = cal_ttl_init(ttl_final, dict_ttls)
        
        f = f_or_not(ttl_inital, prefix, finished_ttl_by_round_p)
        initial_distribution = calculate_initial_distribution(dict_y[ttl_inital], f) if ttl_inital in dict_ttls.keys() else [1]
        count = list(Counter(dict_y[ttl_final]).values())
        num_states_per_layer, initial_matrixes, unfinished_ttl_exit = [], [], False
        for ttl_tmp in range(ttl_inital, ttl_final):
            unfinished_ttl_exit = unfinished_ttl_exit or (ttl_tmp not in finished_ttl_by_round_p['ll_round'])
            next_nodes_num = dict_ttls[ttl_tmp+1] if ttl_tmp+1 in dict_ttls.keys() else 1
            next_nodes_num = next_nodes_num + 1 if not f_or_not(ttl_tmp+1, prefix, finished_ttl_by_round_p) and ttl_tmp+1 in dict_ttls.keys() and ttl_tmp+1 != ttl_final else next_nodes_num
            next_nodes_num = len(count) if ttl_tmp == ttl_final - 1 else next_nodes_num
            if f_or_not(ttl_tmp, prefix, finished_ttl_by_round_p):
                current_nodes_num = dict_ttls[ttl_tmp] if ttl_tmp in dict_ttls.keys() else 1
                num_states_per_layer.append(current_nodes_num)
                initial_matrix = calculate_matrix(dict_matrixes[ttl_tmp], (current_nodes_num, next_nodes_num)) if ttl_tmp in dict_matrixes.keys() else np.full((current_nodes_num, next_nodes_num), 1/next_nodes_num).tolist()
            else:
                current_nodes_num = dict_ttls[ttl_tmp]+1 if ttl_tmp in dict_ttls.keys() else 1
                num_states_per_layer.append(current_nodes_num)
                initial_matrix = calculate_matrix(dict_matrixes[ttl_tmp], (current_nodes_num, next_nodes_num)) if ttl_tmp in dict_matrixes.keys() else np.full((current_nodes_num, next_nodes_num), 1/next_nodes_num).tolist()
            initial_matrixes.append(initial_matrix)
        num_states_per_layer.append(len(count))

        if unfinished_ttl_exit:# ttl_inital到ttl_final的TTL都结束了，那就不需要训练模型了啊
            model_structure[(ttl_inital, ttl_final)] = (initial_distribution, initial_matrixes, num_states_per_layer, dict_y[ttl_final])
        i = calculate_i(ttl_inital, keys)
    return model_structure

def remove_first_min(lst):
    if not lst:
        return []
    min_val = min(lst)
    return [x for x in lst if x != min_val]

def model_construct_train(model_structure):
    distribution_ttl, matrix_ttl, model_structure, is_uniform = {}, {}, dict(sorted(model_structure.items(), key=lambda item: item[0][0])), {}
    for ttl_interval in model_structure.keys():
        model_para = model_structure[ttl_interval]
        initial_distribution, initial_matrixes, num_states_per_layer, y = model_para[0], model_para[1], model_para[2], model_para[3]
        # 如果每一层的Gini系数都不大的话，就做均匀分布假设，不估计了
        if(len(remove_first_min(initial_distribution)) != 0):
            gini_list = [gini_coefficient(remove_first_min(initial_distribution))]
        else:
            gini_list = [gini_coefficient(initial_distribution)]
        for i in range(len(initial_matrixes)):
            if(len(remove_first_min(initial_matrixes[i])) != 0):
                gini_list.append(gini_coefficient(remove_first_min(initial_matrixes[i])))
            else:
                gini_list.append(gini_coefficient(initial_matrixes[i]))
        if all(gini <= 0.4 for gini in gini_list):
            for ttl_i in range(ttl_interval[0], ttl_interval[1]):
                if ttl_i not in distribution_ttl.keys():
                    distribution_ttl[ttl_i] = [1/len(initial_distribution) for _ in range(len(initial_distribution))]
                    matrix_ttl[ttl_i] = [[1/len(initial_matrixes[i]) for _ in range(len(initial_matrixes[i]))] for i in range(len(initial_matrixes))]
                    is_uniform[ttl_i] = True
            continue
        topology_bayes = TopologyNeuralNetwork(initial_distribution, initial_matrixes, num_states_per_layer)
        train(topology_bayes, y)
        layer_distributions, transition_matrices = topology_bayes.get_distributions(), topology_bayes.get_transition_matrices()
        for ttl_i in range(ttl_interval[0], ttl_interval[1]):
            if ttl_i not in distribution_ttl.keys():
                distribution_ttl[ttl_i] = layer_distributions[ttl_i-ttl_interval[0]]
                matrix_ttl[ttl_i] = transition_matrices[ttl_i-ttl_interval[0]]
                is_uniform[ttl_i] = False
    return distribution_ttl, matrix_ttl, is_uniform

import numpy as np

def em_estimate_layers(initial_distribution,
                       initial_matrices,
                       num_state_per_layer,
                       y,
                       num_iters=20,
                       alpha=1e-5):
    """
    分层 HMM EM 接口：只观测到最终层 y，估计每层分布与相邻层转移概率。

    参数
    ----
    initial_distribution : np.ndarray, shape=(L_0+1,)
        第 0 层状态分布，最后一项对应隐含“新节点”。
    initial_matrices : List[np.ndarray]
        长度 H，每项 shape=(L_h+1, L_{h+1}+1)，第 h->h+1 层转移初值。
    num_state_per_layer : List[int]
        长度 H+1，num_state_per_layer[h]=L_h，已知节点数（不含隐“新节点”）。
    y : List[int]
        观测序列，只在第 H 层，值范围 [0, L_H-1]。
    num_iters : int
        EM 最大迭代次数。
    alpha : float
        平滑常数，防止零概率。

    返回
    ----
    layer_distributions : List[np.ndarray]
        长度 H+1，第 h 层的后验分布，shape=(L_h+1,).
    transition_matrices : List[np.ndarray]
        长度 H，每项 shape=(L_h+1, L_{h+1}+1)，更新后的转移概率。
    """
    initial_matrix_t = [torch.tensor(matrix, dtype=torch.float32) for matrix in initial_matrices]
    sub = initial_matrix_t[0].shape[0] - len(initial_distribution)
    for i in range(0, sub):
        initial_distribution.append(0)
    initial_distribution = np.asarray(initial_distribution, dtype=float)
    initial_matrices = [np.array(M, dtype=float) for M in initial_matrices]
    y = np.asarray(y, dtype=int)

    H = len(initial_matrices)
    # 初始化
    pi = [initial_distribution.copy()]
    for M in initial_matrices:
        # 行归一化并平滑
        M = (M + alpha)
        M = M / M.sum(axis=1, keepdims=True)
        pi.append(None)  # 占位
    trans = [M.copy() for M in initial_matrices]

    # 只观测到第 H 层，构造观测计数 n_H[j]
    L_H = num_state_per_layer[H]
    n_H = np.bincount(y, minlength=L_H)
    # 把隐类也统计成 0 次
    # n_H = np.concatenate([n_H, [0]])

    for it in range(num_iters):
        # E 步：前向-后向计算 ξ_h(i,j)
        # 对第 H 层直接给后验分布
        gamma = [None]*(H+1)
        gamma[H] = n_H / n_H.sum()
        # 从后往前做简化的后向传递（忽略中间观测，仅末层观测）
        # 这里简化处理：把 gamma[H] 反向投影到各层
        for h in range(H-1, -1, -1):
            # gamma_h(i) = sum_j gamma_{h+1}(j) * trans[h][i,j]
            try:
                gamma[h] = trans[h].dot(gamma[h+1])
                gamma[h] = gamma[h] / gamma[h].sum()
            except Exception as e:
                # —— 打印 shape —— #
                print(f"""
                initial_distribution.shape: {initial_distribution.shape}
                number of matrices: {len(initial_matrices)} 
                initial_matrices[0].shape: {initial_matrices[0].shape}
                initial_matrices[-1].shape: {initial_matrices[-1].shape}
                num_state_per_layer: {num_state_per_layer}
                gamma[h+1]: {gamma[h+1].shape}
                trans[h]: {trans[h].shape}
                H: {H}
                h: {h}
                y: {y}
                """)
                print(e)

        # M 步：更新每层转移矩阵
        for h in range(H):
            # 软计数 ξ_h(i,j) ≈ gamma[h](i) * trans[h][i,j] * gamma[h+1](j) / norm
            # 这里 norm 保证行和等于 gamma[h](i)
            M = trans[h]
            num = (M * gamma[h][:,None] * gamma[h+1][None,:])
            # 行归一化，并加平滑
            M_new = num + alpha
            M_new = M_new / M_new.sum(axis=1, keepdims=True)
            trans[h] = M_new

    # 收集每层分布
    layer_distributions = gamma
    transition_matrices  = trans
    return [arr.tolist() for arr in layer_distributions], [M.tolist() for M in transition_matrices]

def em_estimate_layers_full(initial_distribution,
                            initial_matrices,
                            num_state_per_layer,
                            y,
                            num_iters=10,
                            alpha=1e-10,
                            noise_scale=1e-2):
    """
    分层 HMM EM（完整 Baum–Welch），假设 initial_distribution、
    initial_matrices、num_state_per_layer 都已经包含了“新节点”这一维度。
    内部不再额外 +1。

    initial_distribution: [1, 1, 1, 1, 2, 0]是每个节点出现的次数（第一层共6个节点，包括假设的节点）
    initial_matrices: [
        [这是第一层到第二层的转移矩阵，因为假设了一个新节点，所以是 6×7 的矩阵],
            [0.3117910325527191, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886],
            [0.3117910325527191, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886],
            [0.3117910325527191, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886],
            [0.3117910325527191, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886, 0.1147015169262886],
            [0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548],
            [0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548, 0.1428571492433548]
        ],
        。。。
    ]
    num_state_per_layer：[6, 7, 7, 7, 1, 5, 7, 7, 5, 4]
    y: [0, 1, 2, 3, 3, 3]每个观测值的编号
    """
    import numpy as np
    if len(initial_distribution) < len(initial_matrices[0]):
        del initial_matrices[0][-1]
    y = np.asarray(y, dtype=int) # array([0, 1, 2, 3, 3, 3])
    N = len(y) # 6
    H = len(initial_matrices) # 9这表示转移的次数，贝叶斯网络层数为10层

    # 1) 初始化 π 和 A，直接用用户传进来的 shape
    pi = np.array(initial_distribution, dtype=float) # array([1., 1., 1., 1., 2., 0.])
    pi += noise_scale * np.random.rand(*pi.shape) # array([1.00951379, 1.00610785, 1.00518267, 1.00610852, 2.00112194, 0.00907106])
    pi = (pi + alpha) # array([1.0095138 , 1.00610785, 1.00518267, 1.00610852, 2.00112194, 0.00907106])
    pi /= pi.sum() # 这一步进行归一化 array([0.16721817, 0.166654  , 0.16650075, 0.16665411, 0.33147041,0.00150255]) 

    # 这里将initial_matrices添加噪声之后存入trans中
    trans = []
    for M0 in initial_matrices:
        M = np.array(M0, dtype=float)
        M += noise_scale * np.random.rand(*M.shape)
        M = (M + alpha)
        M /= M.sum(axis=1, keepdims=True) # 因为添加了噪声和alpha，所以这里需要归一化
        trans.append(M)

    # EM 迭代
    for _ in range(num_iters):
        # E步：给定当前参数，计算[如果这些参数是真的，观测到的数据下各隐藏状态出现的概率分布]
        exp_pi    = np.zeros_like(pi)
        exp_trans = [np.zeros_like(M) for M in trans]

        for k in range(N):
            yk = y[k]

            # 前向
            alpha_f = [None]*(H+1) # alpha_f(i)表示到达层h，处于状态i的未归一化概率，因为把第1层也加入了，因此是H+1个元素
            alpha_f[0] = pi.copy() # 初始的alpha_0=pi
            for h in range(H):
                try:
                    alpha_f[h+1] = alpha_f[h].dot(trans[h])
                except Exception as e:
                    print(f"""
                        initial_distribution: {initial_distribution}
                        matrices: {initial_matrices} 
                        num_state_per_layer: {num_state_per_layer}
                        H: {H}
                        h: {h}
                        y: {y}
                        """)
                    print(f"异常信息：{e}")
                    raise

            # 构造 emission mask，长度直接和 alpha_f[H] 对齐
            emit = np.zeros_like(alpha_f[H])
            if not (0 <= yk < emit.shape[0]):
                raise ValueError(f"观测 y={yk} 超出范围 [0, {emit.shape[0]})")
            emit[yk] = 1.0
            alpha_f[H] *= emit # 这里过后，alpha_f[H] 就是观测到 yk 时的未归一化概率分布 [0.22112519998901548, 0.0, 0.0, 0.0]因为这里只观测到了0

            # 后向
            beta_b = [None]*(H+1)
            beta_b[H] = np.ones_like(alpha_f[H])
            for h in range(H-1, -1, -1):
                if h == H-1:
                    beta_b[h] = (trans[h] * emit[None, :]).dot(beta_b[h+1])
                else:
                    beta_b[h] = trans[h].dot(beta_b[h+1])

            # 归一化常数
            llk = alpha_f[H].sum()

            # 计算 γ
            gamma = [None]*(H+1)
            for h in range(H+1):
                gamma[h] = alpha_f[h] * beta_b[h] / llk
            exp_pi += gamma[0]

            # 计算 ξ 并累计到 exp_trans
            for h in range(H):
                if h == H-1:
                    xi = (alpha_f[h][:,None]
                          * trans[h]
                          * (beta_b[h+1][None,:] * emit[None,:]))
                else:
                    xi = (alpha_f[h][:,None]
                          * trans[h]
                          * beta_b[h+1][None,:])
                xi /= llk
                exp_trans[h] += xi

        # M 步更新
        pi = exp_pi + alpha
        pi /= pi.sum()
        for h in range(H):
            # gamma_ = 2.0  
            # counts = exp_trans[h] + alpha  # 加一点 α 防止 0**gamma
            # sharp = counts ** gamma_   
            # trans[h] = sharp / sharp.sum(axis=1, keepdims=True)
            trans[h] = exp_trans[h] + alpha
            trans[h] /= trans[h].sum(axis=1, keepdims=True)

    # 最后返回最后一次计算到的 gamma
    layer_distributions = [g.tolist() for g in gamma]
    transition_matrices  = [M.tolist() for M in trans]
    return layer_distributions, transition_matrices



def model_construct_train_with_em(model_structure):
    distribution_ttl, matrix_ttl, model_structure, is_uniform = {}, {}, dict(sorted(model_structure.items(), key=lambda item: item[0][0])), {}
    for ttl_interval in model_structure.keys():
        model_para = model_structure[ttl_interval]
        initial_distribution, initial_matrixes, num_states_per_layer, y = model_para[0], model_para[1], model_para[2], model_para[3]
        # 如果每一层的Gini系数都不大的话，就做均匀分布假设，不估计了
        # if(len(remove_first_min(initial_distribution)) != 0):
        #     gini_list = [gini_coefficient(remove_first_min(initial_distribution))]
        # else:
        #     gini_list = [gini_coefficient(initial_distribution)]
        # for i in range(len(initial_matrixes)):
        #     if(len(remove_first_min(initial_matrixes[i])) != 0):
        #         gini_list.append(gini_coefficient(remove_first_min(initial_matrixes[i])))
        #     else:
        #         gini_list.append(gini_coefficient(initial_matrixes[i]))
        # if all(gini <= 0.4 for gini in gini_list):
        #     for ttl_i in range(ttl_interval[0], ttl_interval[1]):
        #         if ttl_i not in distribution_ttl.keys():
        #             distribution_ttl[ttl_i] = [1/len(initial_distribution) for _ in range(len(initial_distribution))]
        #             matrix_ttl[ttl_i] = [[1/len(initial_matrixes[i]) for _ in range(len(initial_matrixes[i]))] for i in range(len(initial_matrixes))]
        #             is_uniform[ttl_i] = True
        #     continue
        # topology_bayes = TopologyNeuralNetwork(initial_distribution, initial_matrixes, num_states_per_layer)
        # train(topology_bayes, y)
        layer_distributions, transition_matrices = em_estimate_layers_full(initial_distribution, initial_matrixes, num_states_per_layer, y)
        for ttl_i in range(ttl_interval[0], ttl_interval[1]):
            if ttl_i not in distribution_ttl.keys():
                distribution_ttl[ttl_i] = layer_distributions[ttl_i-ttl_interval[0]]
                matrix_ttl[ttl_i] = transition_matrices[ttl_i-ttl_interval[0]]
                is_uniform[ttl_i] = False
    return distribution_ttl, matrix_ttl, is_uniform

def find_min_index(distribution):
    min_index = 0
    for i in range(len(distribution)):
        if distribution[i] < distribution[min_index]:
            min_index = i
    return min_index

def select_p_by_gini(distribution):
    gini_distribution = gini_coefficient(distribution)
    if len(distribution) <= 2:
        # return min(distribution) if gini_coefficient(distribution) < 0.4 else max(distribution)
        return min(distribution) if gini_coefficient(distribution) < 0.4 else max(distribution)
    if gini_distribution < 0.4:
        # return min(distribution)
        return 1/len(distribution)
    first = max(distribution)
    distribution_copy = [i for i in distribution]
    distribution_copy.remove(first)
    second = max(distribution_copy)
    gini_fs = gini_coefficient([first, second])
    gini_copy = gini_coefficient(distribution_copy)
    values_above = [v for v in distribution if v > 0.02]
    min_value = min(values_above) if len(values_above) > 0 else 0.5
    if gini_fs > 0.4:
        return first
    if gini_fs > 0.3:
        if gini_copy < 0.3:
            return min(distribution_copy)
        while gini_copy > 0.3 and len(distribution_copy) > 1:
            distribution_copy.remove(min(distribution_copy))
            gini_copy = gini_coefficient(distribution_copy)
        return min(distribution_copy) if min(distribution_copy) > 0.002 else max(distribution_copy)
    while gini_coefficient(distribution) > 0.3:
        distribution.remove(min(distribution))
    return min(distribution) if min(distribution) > 0.002 else max(distribution)
    
def calculate_probes(ttls, probes_ttl, parameters, finished_ttl_by_round_p):
    layer_distributions, transition_matrixes, probes_send = parameters[0], parameters[1], {}
    for ttl in layer_distributions.keys():
        # print(f"probes_ttl: {probes_ttl}")
        # current_probe = probes_ttl[ttl-2]['max_cumulative_probes']
        current_probe = probes_ttl[ttl-2][1]
        if ttl in finished_ttl_by_round_p['ll_round'] and ttl + 1 in finished_ttl_by_round_p['ll_round']:
            probes_send[ttl] = current_probe# ttl结束了，那就不需要发包了，发包数和上一轮一样就行了
            continue
        if ttl not in set(ttls):# 节点为0的ttl，既然此prefix出现就是没结束，那就继续发6个包
            probes_send[ttl] = current_probe + 6
            continue
        mask = [p_i != 0 for p_i in layer_distributions[ttl]]
        dis_tmp = [p_i for p_i in layer_distributions[ttl] if p_i != 0]
        if len(dis_tmp) < 2:
            continue
        try:
            n = min(cal_n_k(dis_tmp, DEFAULT_FAILURE_RATE), 1000)
        except ZeroDivisionError as e:
            print(layer_distributions[ttl])
            print(dis_tmp)
            raise e

        probes_send[ttl] = n
        min_index = find_min_index(dis_tmp)
        p = select_p_by_gini(transition_matrixes[ttl][min_index])
        m_k = cal_m_k(transition_matrixes[ttl][min_index], p, DEFAULT_FAILURE_RATE)
        for distribution_i in range(len(transition_matrixes[ttl])):
            if not mask[distribution_i]:
                continue
            p = select_p_by_gini(transition_matrixes[ttl][distribution_i])
            m = cal_m_k(transition_matrixes[ttl][distribution_i], p, DEFAULT_FAILURE_RATE)
            if layer_distributions[ttl][distribution_i] == 0 or layer_distributions[ttl][min_index] == 0:
                continue
            if ttl not in finished_ttl_by_round_p['ll_round']:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m/layer_distributions[ttl][distribution_i]-m_k/layer_distributions[ttl][min_index]), 5000))
            else:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m/layer_distributions[ttl][distribution_i]), 50000))
    return probes_send

def calculate_probes_for_probing(link_ttls, links, round, prefix, ttls, probes_ttl, parameters, finished_ttl_by_round_p):
    layer_distributions, transition_matrixes, is_uniform, probes_send, counter = parameters[0], parameters[1], parameters[2], {}, 0
    for ttl in layer_distributions.keys():
        if is_uniform[ttl]:
            # print(counter)
            counter += 1
        if ttl not in link_ttls:
            link_num = 0
        else:
            link_index = 0
            for link_i in range(len(link_ttls)):
                if link_ttls[link_i] == ttl:
                    link_index = link_i
                    break
            link_num = links[link_index]
        current_probe = probes_ttl[ttl-2][1]
        if ttl in finished_ttl_by_round_p['ll_round'] and ttl + 1 in finished_ttl_by_round_p['ll_round']:
            probes_send[ttl] = current_probe# ttl结束了，那就不需要发包了，发包数和上一轮一样就行了
            continue
        if ttl not in set(ttls):# 节点为0的ttl，既然此prefix出现就是没结束，那就继续发6个包
            probes_send[ttl] = current_probe + 6
            continue
        mask = [p_i != 0 for p_i in layer_distributions[ttl]]
        dis_tmp = [p_i for p_i in layer_distributions[ttl] if p_i != 0]
        if len(dis_tmp) < 2:
            continue
        try:
            n = min(cal_n_k(dis_tmp, DEFAULT_FAILURE_RATE), 500)
        except ZeroDivisionError as e:
            print(layer_distributions[ttl])
            print(dis_tmp)
            raise e

        probes_send[ttl] = n
        min_index = find_min_index(dis_tmp)
        p = select_p_by_gini(transition_matrixes[ttl][min_index])
        m_k = cal_m_k(transition_matrixes[ttl][min_index], p, DEFAULT_FAILURE_RATE)
        for distribution_i in range(len(transition_matrixes[ttl])):
            if is_uniform[ttl]:
                link_num += 1
                m = cal_m_k([1/link_num for _ in range(link_num)], 1/link_num, DEFAULT_FAILURE_RATE)
                if ttl not in finished_ttl_by_round_p['ll_round']:
                    probes_send[ttl] = max(probes_send[ttl], ceil(m))
                else:
                    probes_send[ttl] = max(probes_send[ttl], ceil(m))
                continue
            if not mask[distribution_i]:
                continue
            link_prob, probe_max = [], 2000 if link_num < 200 else 3000
            probe_max = 1000 if link_num < 100 else probe_max
            probe_max = 500 if link_num < 50 else probe_max
            probe_max = 200 if link_num < 25 else probe_max
            # for p_j in range(len(transition_matrixes[ttl][0])):
            #     for p_i in range(len(layer_distributions[ttl])):
            #         if p_j < len(transition_matrixes[ttl][p_i]):
            #             link_prob.append(layer_distributions[ttl][p_i] * transition_matrixes[ttl][p_i][p_j])
            link_prob = [x for sub in transition_matrixes[ttl] for x in sub]
            import heapq
            link_prob = heapq.nlargest(link_num+1, link_prob)
            # exps = [math.exp(v) for v in link_prob]
            # total = sum(exps)
            # link_prob = [e / total for e in exps]
            total = sum(link_prob)
            link_prob = [v/total for v in link_prob]
            # p = select_p_by_gini(link_prob)
            p = min(link_prob)
            m = cal_m_k(link_prob, p, DEFAULT_FAILURE_RATE)

            gini_link_prob = gini_coefficient(link_prob)
            if gini_link_prob < 0.3:
                m = cal_m_k(link_prob, 1/len(link_prob), DEFAULT_FAILURE_RATE) if len(link_prob) > 2 else m
            else:
                m = ceil(cal_m_k(link_prob, 1/len(link_prob), DEFAULT_FAILURE_RATE) * math.log(gini_link_prob * 10 - 1.8, 2.8)) if len(link_prob) > 2 else 100
            # if m > 200:
            # # if gini_link_prob > 0.1:
            #     print(f"prefix: {prefix}, round: {round}, ttl: {ttl}, len of links: {len(link_prob)}, gini_link_prob: {gini_link_prob}, m: {m}")
            if layer_distributions[ttl][distribution_i] == 0 or layer_distributions[ttl][min_index] == 0:
                continue
            if ttl not in finished_ttl_by_round_p['ll_round']:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m), probe_max))
            else:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m), probe_max))
    return probes_send

def calculate_probes_using_em(link_ttls, links, round, prefix, ttls, probes_ttl, parameters, finished_ttl_by_round_p):
    layer_distributions, transition_matrixes, probes_send = parameters[0], parameters[1], {}
    for ttl in layer_distributions.keys():
        # print(f"probes_ttl: {probes_ttl}")
        # current_probe = probes_ttl[ttl-2]['max_cumulative_probes']
        current_probe = probes_ttl[ttl-2][1]
        if ttl in finished_ttl_by_round_p['ll_round'] and ttl + 1 in finished_ttl_by_round_p['ll_round']:
            probes_send[ttl] = current_probe# ttl结束了，那就不需要发包了，发包数和上一轮一样就行了
            continue
        if ttl not in set(ttls):# 节点为0的ttl，既然此prefix出现就是没结束，那就继续发6个包
            probes_send[ttl] = current_probe + 6
            continue
        mask = [p_i != 0 for p_i in layer_distributions[ttl]]
        dis_tmp = [p_i for p_i in layer_distributions[ttl] if p_i != 0]
        if len(dis_tmp) < 2:
            continue
        try:
            n = min(cal_n_k(dis_tmp, DEFAULT_FAILURE_RATE), 1000)
        except ZeroDivisionError as e:
            print(layer_distributions[ttl])
            print(dis_tmp)
            raise e

        probes_send[ttl] = n
        min_index = find_min_index(dis_tmp)
        p = select_p_by_gini(transition_matrixes[ttl][min_index])
        m_k = cal_m_k(transition_matrixes[ttl][min_index], p, DEFAULT_FAILURE_RATE)
        for distribution_i in range(len(transition_matrixes[ttl])):
            if not mask[distribution_i]:
                continue
            p = select_p_by_gini(transition_matrixes[ttl][distribution_i])
            m = cal_m_k(transition_matrixes[ttl][distribution_i], p, DEFAULT_FAILURE_RATE)
            if layer_distributions[ttl][distribution_i] == 0 or layer_distributions[ttl][min_index] == 0:
                continue
            if ttl not in finished_ttl_by_round_p['ll_round']:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m/layer_distributions[ttl][distribution_i]-m_k/layer_distributions[ttl][min_index]), 5000))
            else:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m/layer_distributions[ttl][distribution_i]), 50000))
    return probes_send

def construct_probes(statistical_gurantee, dict_result, round_):
    results_tmp = []
    for ttl in statistical_gurantee.keys():
        results_tmp.append((17, dict_result['probe_dst_prefix'], ttl, statistical_gurantee[ttl], round_))
    results, last_index = [], len(results_tmp) - 1
    if len(results_tmp) == 0:
        return []
    try:
        results.append((results_tmp[0][0], results_tmp[0][1], results_tmp[0][2], max(results_tmp[0][3], results_tmp[1][3]) ,results_tmp[0][4]))
    except:
        pass
    for result_i in range(1, last_index):
        results.append((results_tmp[result_i][0], results_tmp[result_i][1], results_tmp[result_i][2], max(max(results_tmp[result_i][3], results_tmp[result_i + 1][3]), results_tmp[result_i - 1][3]) ,results_tmp[result_i][4]))
    results.append((results_tmp[last_index][0], results_tmp[last_index][1], results_tmp[last_index][2], max(results_tmp[last_index][3], results_tmp[last_index - 1][3]) ,results_tmp[last_index][4]))
    return results

def correct_finished_ttl(dict_result, finished_ttl_prefix, round_):
    if round_ > 2:
        for ttl in range(2, 33):
            if ttl not in set(dict_result['ttls']):
                finished_ttl_prefix.add(ttl)
    return finished_ttl_prefix

def update_fininshed_ttl(finished_ttl_prefix, finished_ttl_by_round_p):
    finished_ttl_by_round_p['ll_round'] = finished_ttl_by_round_p['ll_round'].union(finished_ttl_by_round_p['l_round'])
    finished_ttl_by_round_p['l_round'] = set([])
    for ttl in finished_ttl_prefix:
        if ttl not in finished_ttl_by_round_p['ll_round']:
            finished_ttl_by_round_p['l_round'].add(ttl)
    return finished_ttl_by_round_p

def finsh(finished_ttl_by_round_p):
    F = True
    for i in range(2, 33):
        if i not in finished_ttl_by_round_p['ll_round']:
            F = False
    return F

def baymuda_statistical_gurantee(dict_result, round_, finished_ttl_prefix, finished_ttl_by_round_p):
    finished_ttl_prefix = correct_finished_ttl(dict_result, finished_ttl_prefix, round_)
    finished_ttl_by_round_p = update_fininshed_ttl(finished_ttl_prefix, finished_ttl_by_round_p)
    # 根据上一轮结果确定参数估计模型的结构
    model_structure = process_result(dict_result, finished_ttl_by_round_p, round_)
    # 参数估计模型的构建以及训练
    parameters = model_construct_train_with_em(model_structure)
    # 根据估计得到的参数确定每跳的发包数量
    statistical_gurantee = calculate_probes_for_probing(dict_result['link_ttls'], dict_result['links_array'], round_, dict_result['probe_dst_prefix'], dict_result['ttls'], dict_result['ttl_and_probes_array'], parameters, finished_ttl_by_round_p)
    results = construct_probes(statistical_gurantee, dict_result, round_) if len(statistical_gurantee) != 0 else []
    return dict_result['probe_dst_prefix'], results, finished_ttl_by_round_p, finsh(finished_ttl_by_round_p)
'''
if __name__ == '__main__':
    ''''''
    import pandas as pd
    from get_cumulative_probe import Query_probes
    from query_finished_ttl import Query_finished_ttl
    from query_matrix import Query_Matrix
    from select_parameter import Query_parameter
    from configure import credentials
    from pych_client import ClickHouseClient
    measurement_id = '91255cc6-55fd-4ac6-a985-23ee42ddb48e'
    with ClickHouseClient(**credentials) as client:
        result = pd.DataFrame(Query_parameter().execute(client, measurement_id))
        probes = pd.DataFrame(Query_probes(round_eq=5).execute(client, measurement_id=measurement_id))
        finished_ttl = pd.DataFrame(Query_finished_ttl(round_eq=5).execute(client, '91255cc6-55fd-4ac6-a985-23ee42ddb48e'))
        matrix = pd.DataFrame(Query_Matrix().execute(client, measurement_id))
    result_probes = pd.merge(result, probes, on='probe_dst_prefix', how='inner')  # 默认是 'inner' 连接
    result_probe_matrix = pd.merge(result_probes, matrix, on='probe_dst_prefix', how='inner')
    for i in range(len(result_probe_matrix)):
        prefix = result_probe_matrix.iloc[0]['probe_dst_prefix']
        finished_ttl_prefix = set([])
        if len(finished_ttl) != 0 and prefix in finished_ttl['probe_dst_prefix'].values:
            finished_ttl_prefix = set(finished_ttl.groupby('probe_dst_prefix').get_group(prefix)['probe_ttl'].tolist())
        dict_result, unfinished_ttl = result_probe_matrix.iloc[0], finished_ttl_prefix
        # model_structure = process_result(dict_result, finished_ttl_prefix)
        # model_construct_train(model_structure)
        baymuda_statistical_gurantee(dict_result, 5, finished_ttl_prefix, {})
'''
'''
    d_0 = [0.16031894087791443, 0.056162696331739426, 0.056162696331739426, 0.055942896753549576, 0.05555560812354088, 0.056162696331739426, 0.056162696331739426, 0.056162696331739426, 0.056162696331739426, 0.0561625212430954, 0.33504390716552734]
    d_1 = [0.013253448531031609, 0.011866091750562191, 0.011866091750562191, 0.011814105324447155, 0.011724359355866909, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866040527820587, 0.8801454305648804]
    d_2 = [0.48, 0.48, 0.04]
    print(select_p_by_gini(d_0))
    print(select_p_by_gini(d_1))
    print(select_p_by_gini(d_2))
'''