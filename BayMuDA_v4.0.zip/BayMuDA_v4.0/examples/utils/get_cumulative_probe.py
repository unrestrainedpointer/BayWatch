from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import ProbesQuery, probes_table
from diamond_miner.typing import IPNetwork
from diamond_miner.queries.fragments import eq, and_, ip_in
from functools import reduce

@dataclass(frozen=True)
class Query_probes(ProbesQuery):
    round_eq: int | None = None  # 这是你可以指定的参数
    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        
        return f'''
        WITH
        probes AS (
            SELECT 
                probe_dst_prefix, 
                probe_ttl, 
                MAX(cumulative_probes) AS max_cumulative_probes
            FROM 
                {probes_table(measurement_id)}
            WHERE 
                round <= {self.round_eq}
            GROUP BY 
                probe_dst_prefix, 
                probe_ttl
        )
        SELECT 
            probe_dst_prefix, 
            arraySort(x -> x.1, groupArray((probe_ttl, max_cumulative_probes))) AS ttl_and_probes_array
        FROM probes
        GROUP BY 
            probe_dst_prefix;
        '''
    
@dataclass(frozen=True)
class Query_probes_simple(ProbesQuery):    
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        
        return f'''
        SELECT 
            *
        FROM 
            {probes_table(measurement_id)}
        '''

# 返回值如下：
# [::ffff:218.103.214.0 │ [(2,6),(3,6),(4,6),(5,6),(6,6),(7,6),(8,6),(9,6),(10,6),(11,6),(12,6),(13,6),(14,6),(15,6),(16,6),(17,6),(18,6),(19,6),(20,6),(21,6),(22,6),(23,6),(24,6),(25,6),(26,6),(27,6),(28,6),(29,6),(30,6),(31,6),(32,6)],...]
if __name__ == '__main__':
    from configure import credentials
    from pych_client import ClickHouseClient
    measurement_id = '91255cc6-55fd-4ac6-a985-23ee42ddb48e'
    with ClickHouseClient(**credentials) as client:
        probes = Query_probes(round_eq=5).execute(client, measurement_id)
    print(probes)