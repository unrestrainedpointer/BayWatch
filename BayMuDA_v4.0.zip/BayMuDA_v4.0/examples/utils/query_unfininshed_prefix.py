from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import LinksQuery, links_table
from diamond_miner.typing import IPNetwork

@dataclass(frozen=True)
class Query_unfinished_prefix(LinksQuery):
    round_eq: int | None = None  # 这是你可以指定的参数

    def statement(self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET) -> str:
        return f'''
        WITH filtered_prefixes AS (
            SELECT 
                probe_dst_prefix, 
                near_ttl,
                COUNT(DISTINCT near_addr, far_addr) AS distinct_count
            FROM 
                {links_table(measurement_id)}
            WHERE 
                near_round < {self.round_eq} AND far_round < {self.round_eq}
            GROUP BY 
                probe_dst_prefix, near_ttl
        ),
        comparison_prefixes AS (
            SELECT 
                probe_dst_prefix, 
                near_ttl,
                COUNT(DISTINCT near_addr, far_addr) AS distinct_count
            FROM 
                {links_table(measurement_id)}
            WHERE 
                near_round <= {self.round_eq} AND far_round <= {self.round_eq}
            GROUP BY 
                probe_dst_prefix, near_ttl
        )
        SELECT DISTINCT fp.probe_dst_prefix
        FROM filtered_prefixes fp
        JOIN comparison_prefixes cp 
        ON fp.probe_dst_prefix = cp.probe_dst_prefix 
        AND fp.near_ttl = cp.near_ttl
        WHERE fp.distinct_count < cp.distinct_count;
    '''