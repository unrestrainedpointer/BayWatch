from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import LinksQuery, ResultsQuery, links_table, results_table
from diamond_miner.typing import IPNetwork

@dataclass(frozen=True)
class Query_parameter(LinksQuery):
    round_eq: int | None = None  # 这是你可以指定的参数

    def statement(self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET) -> str:
        return f'''
        WITH
        ttl_distribution AS (
            SELECT 
                probe_dst_prefix,
                probe_ttl,
                COUNT(DISTINCT reply_src_addr) AS node_count
            FROM 
                {results_table(measurement_id)}
            GROUP BY 
                probe_dst_prefix, probe_ttl
        ),
        aggregated_data AS (
            SELECT
                probe_dst_prefix,
                groupArray((probe_ttl, node_count)) AS ttl_pairs
            FROM
                ttl_distribution
            GROUP BY
                probe_dst_prefix
        ),
        prefix_ttl_summary AS (
            SELECT
                probe_dst_prefix,
                arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
                arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_node_counts
            FROM 
                aggregated_data
        ),
        address_counts AS (
            SELECT 
                probe_dst_prefix,
                probe_ttl,
                reply_src_addr,
                COUNT(*) AS address_count
            FROM 
                {results_table(measurement_id)}
            WHERE reply_src_addr != '::'
            GROUP BY 
                probe_dst_prefix, probe_ttl, reply_src_addr
        ),
        ttl_address_counts AS (
            SELECT
                probe_dst_prefix,
                probe_ttl,
                arraySort(groupArray(address_count)) AS sorted_address_counts  -- 确保每个地址计数数组内部排序
            FROM
                address_counts
            GROUP BY
                probe_dst_prefix, probe_ttl
        ),
        aggregated_data_y AS (
            SELECT
                probe_dst_prefix,
                groupArray((probe_ttl, sorted_address_counts)) AS ttl_pairs
            FROM
                ttl_address_counts
            GROUP BY
                probe_dst_prefix
        ),
        prefix_ttl_summary_y AS (
            SELECT
                probe_dst_prefix,
                arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
                arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_address_counts
            FROM 
                aggregated_data_y
        )
    SELECT 
        probe_dst_prefix,
        sorted_ttls AS ttls,
        sorted_node_counts AS list_n,
        sorted_address_counts AS list_y
    FROM 
        prefix_ttl_summary_y y
    JOIN
        prefix_ttl_summary p
    ON
        p.probe_dst_prefix = y.probe_dst_prefix
    '''

import pandas as pd
from pych_client import ClickHouseClient

if __name__ == '__main__':
    credentials = {
        "base_url": "http://localhost:8123",
        "database": "default",
        "username": "default",
        "password": "",
    }
    with ClickHouseClient(**credentials) as client:
        result_csv = pd.DataFrame(Query_parameter(round_eq=6).execute(client, '91255cc6-55fd-4ac6-a985-23ee42ddb48e'))
        result_csv = result_csv.groupby('probe_dst_prefix')
        # 调整显示选项
        pd.set_option('display.max_colwidth', None)  # 设置为 None 表示不截断列宽
        pd.set_option('display.max_rows', None)      # 设置为 None 表示显示完整的行

        # 假设 result_probe_matrix 是你的 DataFrame
        # 示例：逐行打印 DataFrame
        for index, row in result_csv.get_group('::ffff:64.172.247.0').iterrows():
            print(f"Row {index}:")
            print(row)
            print("-" * 20)  # 分隔符