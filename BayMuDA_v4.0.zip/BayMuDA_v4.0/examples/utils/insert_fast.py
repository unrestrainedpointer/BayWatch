from collections.abc import Iterable, Iterator
from dataclasses import dataclass

from pych_client import ClickHouseClient

from diamond_miner.defaults import (
    DEFAULT_FAILURE_RATE,
    DEFAULT_PREFIX_LEN_V4,
    DEFAULT_PREFIX_LEN_V6,
    PROTOCOLS,
    UNIVERSE_SUBSET,
)
from diamond_miner.format import format_ipv6
from diamond_miner.generators.standalone import split_prefix
from diamond_miner.queries.insert_mda_probes import InsertMDAProbes
from diamond_miner.queries.query import Query, probes_table
from diamond_miner.subsets import subsets_for
from diamond_miner.typing import IPNetwork
from diamond_miner.utilities import available_cpus
from typing import List, Tuple, Iterable 
from concurrent.futures import ProcessPoolExecutor, as_completed
from clickhouse_driver import Client
from utils.configure import logger, ALERT_LEVEL
import logging

logging.basicConfig(level=ALERT_LEVEL)

@dataclass(frozen=True)
class InsertProbes(Query):
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        return f"INSERT INTO {probes_table(measurement_id)} FORMAT JSONCompactEachRow"

def gen_data(prefixes_chunk: Iterable[tuple[str, str, Iterable[int], int]], prefix_len_v4: int, prefix_len_v6: int, round_: int) -> List[Tuple[int, str, int, int, int]]:
    data = []
    for prefix, protocol, ttls, n_probes in prefixes_chunk:
        protocol_id = PROTOCOLS[protocol]  # 获取协议编号
        for af, subprefix, subprefix_size in split_prefix(prefix, prefix_len_v4, prefix_len_v6):
            for ttl in ttls:
                data.append(
                    (protocol_id, format_ipv6(subprefix), ttl, n_probes, round_)
                )
    return data

def chunk_prefixes(prefixes: List[tuple[str, str, Iterable[int], int]], chunk_size: int = 1000000) -> List[List[tuple[str, str, Iterable[int], int]]]:
    if len(prefixes) < chunk_size:
        return [prefixes[i:i + len(prefixes)] for i in range(0, 1)]
    """
    将 prefixes 列表分块，每块 chunk_size 大小
    """
    return [prefixes[i:i + chunk_size] for i in range(0, len(prefixes), chunk_size)]

def insert_probe_counts(
    client: ClickHouseClient,
    measurement_id: str,
    round_: int,
    prefixes: Iterable[tuple[str, str, Iterable[int], int]],
    prefix_len_v4: int = DEFAULT_PREFIX_LEN_V4,
    prefix_len_v6: int = DEFAULT_PREFIX_LEN_V6,
) -> None:
    def parallel_gen_data(p: Iterable[tuple[str, str, Iterable[int], int]], prefix_len_v4: int, prefix_len_v6: int, round_: int, n_workers: int = 24) -> List[Tuple[int, str, int, int, int]]:
        chunk_size = len(p) // n_workers  # 将任务分块
        chunks = [p[i:i + chunk_size] for i in range(0, len(p), chunk_size)]

        results = []
        with ProcessPoolExecutor(max_workers=n_workers) as executor:
            futures = [executor.submit(gen_data, chunk, prefix_len_v4, prefix_len_v6, round_) for chunk in chunks]
            
            for future in as_completed(futures):
                results.extend(future.result())
        
        return results

    def insert_probe_counts(
        client: Client,
        measurement_id: str,
        round_: int,
        prefixes: Iterable[tuple[str, str, Iterable[int], int]],
        prefix_len_v4: int = 24,  # 默认值示例
        prefix_len_v6: int = 48,  # 默认值示例
        n_workers: int = 24,  # 并行处理的进程数
    ) -> None:
        from clickhouse_driver import Client
        credentials_0 = {
            "host": "localhost",  # 通常，ClickHouse HTTP 接口监听在 localhost 的 8123 端口
            "port": "9000",       # 默认端口为 8123，这里显式指定
            "user": "default",    # 默认用户
            "password": "",       # 对应的密码，这里为空
            "database": "default" # 默认数据库
        }
        client, i = Client(**credentials_0), 1
        for p in chunk_prefixes(prefixes, chunk_size=100000):
            # 并行生成所有数据
            probes_data = parallel_gen_data(p, prefix_len_v4, prefix_len_v6, round_, n_workers)

            # 使用 clickhouse_driver 的 Client 批量插入数据
            client.execute(
                f'INSERT INTO {probes_table(measurement_id)} (probe_protocol, probe_dst_prefix, probe_ttl, cumulative_probes, round) VALUES',
                probes_data
            )
            logger.alert(f"=====================================")
            logger.alert(f"{i * 100000} prefixes has been inserted!")
            logger.alert(f"=====================================")
            i += 1
    
    insert_probe_counts(client, measurement_id, round_, prefixes)

def insert_mda_probe_counts(
    client: ClickHouseClient,
    measurement_id: str,
    previous_round: int,
    adaptive_eps: bool = False,
    target_epsilon: float = DEFAULT_FAILURE_RATE,
    concurrent_requests: int = max(available_cpus() // 8, 1),
) -> None:
    """
    Run the Diamond-Miner algorithm and insert the resulting probes into the probes table.

    Args:
        client: ClickHouse client.
        measurement_id: Measurement id.
        previous_round: Round on which to run the Diamond-Miner algorithm.
        adaptive_eps: Set to `True` to handle nested load-balancers.
        target_epsilon: Target failure rate of the MDA algorithm.
        concurrent_requests: Maximum number of requests to execute concurrently.
    """
    # TODO: set filter_partial and filter_virtual to false?
    query = InsertMDAProbes(
        adaptive_eps=adaptive_eps,
        round_leq=previous_round,
        filter_partial=True,
        filter_virtual=True,
        filter_inter_round=True,
        target_epsilon=target_epsilon,
    )
    subsets = subsets_for(query, client, measurement_id)
    query.execute_concurrent(
        client, measurement_id, subsets=subsets, concurrent_requests=concurrent_requests
    )