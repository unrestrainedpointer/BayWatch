import numpy as np
layer = 10

def generate_dict(ttls, list_n, list_y, cumulative_probes):
    # print(f"cumulative_probes: {cumulative_probes}")
    dict_ttls, dict_y = {}, {}
    for ttl_i in range(len(ttls)):
        probes_obtain = 0
        dict_ttls[ttls[ttl_i]] = list_n[ttl_i]
        init_num = 0
        dict_y[ttls[ttl_i]] = []
        for count in list_y[ttl_i]:
            probes_obtain += count
            for count_i in range(0, count):
                dict_y[ttls[ttl_i]].append(init_num)
            init_num += 1
        
        # tmp = cumulative_probes[ttls[ttl_i]-2]['max_cumulative_probes'] - probes_obtain
        tmp = cumulative_probes[ttls[ttl_i]-2][1] - probes_obtain
        if tmp != 0:
            dict_ttls[ttls[ttl_i]] = list_n[ttl_i] + 1
            for count_i in range(0, tmp):
                dict_y[ttls[ttl_i]].append(init_num)
    return dict_ttls, dict_y

# 我们首先看key-layer在不在dict_ttls.keys()中，如果不在
    # 要么是情况3，负数肯定不在dict_ttls.keys()中，这个时候ttl_inital应该是1
    # 要么是情况2的第一种情况，这个时候应该用keys[i + 1]的下一跳，当然i+1得在keys中，但是如果keys[i+1]就是1或者i+1不在keys中，那就用1就好了
    #那我们直接将dict_ttls.keys中key以及其相邻的跳之间组成一个model
def cal_ttl_init(ttl_final, dict_ttls):
    if (ttl_final - layer + 1) not in dict_ttls.keys():
        i_tmp = ttl_final - layer + 1
        while i_tmp not in dict_ttls.keys() and i_tmp > 0:
            i_tmp -= 1
        ttl_inital = i_tmp if (i_tmp > 3) else 2
    else: # 那就是2的第二种情况或者1
        ttl_inital = ttl_final - layer + 1 if ttl_final - layer + 1 > 3 else 2
    return ttl_inital

def gini_coefficient(probabilities):
    """计算Gini系数"""
    n = len(probabilities)
    sorted_probs = np.sort(probabilities)
    cumulative_probs = np.cumsum(sorted_probs)
    lorentz_curve = cumulative_probs / cumulative_probs[-1]  # 规范化为洛伦兹曲线
    gini = 1 - (2 / n) * (np.sum(lorentz_curve) - (n + 1) / 2 / n)
    return gini

def get_context_switches(pid):
    """获取进程的上下文切换次数"""
    status_file = f"/proc/{pid}/status"
    voluntary_switches = 0
    nonvoluntary_switches = 0

    try:
        with open(status_file, 'r') as file:
            for line in file:
                if line.startswith("voluntary_ctxt_switches"):
                    voluntary_switches = int(line.split()[1])
                elif line.startswith("nonvoluntary_ctxt_switches"):
                    nonvoluntary_switches = int(line.split()[1])
    except FileNotFoundError:
        print(f"Process {pid} not found.")
        return None

    return voluntary_switches, nonvoluntary_switches