from clickhouse_driver import Client
# from diamond_miner.generators import probe_generator_parallel
from utils.parallel_pplb_per_packet import probe_generator_parallel_per_packet
from utils.parallel_lb import probe_generator_parallel
from diamond_miner.insert import insert_probe_counts
# from utils.insert_fast import insert_probe_counts
from diamond_miner.queries import InsertLinks, InsertPrefixes, InsertResults
import logging
import multiprocessing
import pandas as pd
from pathlib import Path
from pych_client import ClickHouseClient
import time
from utils.configure_motivation import credentials, measurement_id, prefixes, logger, ALERT_LEVEL
from utils.create_tables_mine import CreateTables
from deletet import drop, string
from utils.get_cumulative_probe import Query_probes_simple
from utils_rgmda import correct_round, send_probes
from diamond_miner.queries.query import probes_table

logging.basicConfig(level=ALERT_LEVEL)
# 运行需要sudo -s 然后需要ulimit -n 50000 然后再运行

# logger.alert(f"{len(prefixes)} prefixes!")

if __name__ == '__main__':
    if multiprocessing.get_start_method(allow_none=True) is None:
        multiprocessing.set_start_method('spawn')    
    with ClickHouseClient(**credentials) as client:
        CreateTables().execute(client, measurement_id)
    finished_ttl_by_round, finished_prefix, num_finished_prefix = {}, set({}), []
    for round_ in range(1, 4): 
        num_finished_prefix.append(len(finished_prefix))
        logger.alert(f"================================================")
        logger.alert(f"ROUND {round_}--Measurement_id {measurement_id}")
        logger.alert(f"================================================")
        if round_ == 1:
            with ClickHouseClient(**credentials) as client:
                start_time = time.time()
                logger.alert(f"insert_probe_counts in round {round_} starts {start_time:.2f} seconds.")
                insert_probe_counts(client=client, measurement_id=measurement_id, round_=1, prefixes=prefixes)
                end_time = time.time()
                logger.alert(f"insert_probe_counts in round {round_} takes {end_time - start_time:.2f} seconds.")
        else:
            start_time = time.time()
            results_filepath_last_round = Path("/root/NSDI_24/rgmda/examples/output/results" + "_" + str(round_ - 1) + ".csv")
            probes_filepath_last_round = Path("/root/NSDI_24/rgmda/examples/output/probes" + "_" + str(round_ - 1) + ".csv")
                
            result = []
            correct_round(results_filepath_last_round, round_)
            with ClickHouseClient(**credentials) as client:
                InsertResults().execute(client, measurement_id, data=results_filepath_last_round.read_bytes())
                InsertPrefixes().execute(client, measurement_id)
                InsertLinks().execute(client, measurement_id)

                probes = pd.DataFrame(Query_probes_simple().execute(client, measurement_id))
                probes['cumulative_probes'] = probes['cumulative_probes'].apply(lambda x: x + 1000)
                probes['round'] = probes['round'].apply(lambda x: x + 1)
            credentials_0 = {
                "host": "localhost",  # 通常，ClickHouse HTTP 接口监听在 localhost 的 8123 端口
                "port": "9000",       # 默认端口为 8123，这里显式指定
                "user": "default",    # 默认用户
                "password": "",       # 对应的密码，这里为空
                "database": "default" # 默认数据库
            }
            client = Client(**credentials_0)
            # 将 DataFrame 转换为 list of tuples
            data = [tuple(row) for row in probes.to_numpy()]

            # 插入到 ClickHouse 表中
            insert_query = f'''
            INSERT INTO {probes_table(measurement_id)} (probe_protocol, probe_dst_prefix, probe_ttl, cumulative_probes, round)
            VALUES
            '''

            client.execute(insert_query, data)
            import os
            os.remove(probes_filepath_last_round)
            os.remove(results_filepath_last_round)

        probes_filepath = Path("/root/NSDI_24/rgmda/examples/output/probes" + "_" + str(round_) + ".csv")
        results_filepath = Path("/root/NSDI_24/rgmda/examples/output/results" + "_" + str(round_) + ".csv")

        with ClickHouseClient(**credentials) as client:
            start_time = time.time()
            n_probes = probe_generator_parallel(filepath=probes_filepath, client=client, measurement_id=measurement_id, round_=round_)
            end_time = time.time()
            logger.alert(f"probe_generator_parallel in round {round_} takes {end_time - start_time:.2f} seconds.")
        logger.alert("n_probes=%s", n_probes)
        if n_probes == 0: break
        try:
            start_time = time.time()
            send_probes(results_filepath, probes_filepath)
            end_time = time.time()
            logger.alert(f"Probing in round {round_} takes {end_time - start_time:.2f} seconds.")
        except RuntimeError as e:
            logging.error("Probing failed: %s", e)
            drop([string(measurement_id)])
            raise