import torch
import torch.nn as nn
import torch.optim as optim

# 定义一个简单的模型
class TopologyBayesianModel(nn.Module):
    def __init__(self, num_states_per_layer, transition_matrices=None, ttl_inital=0):
        super(TopologyBayesianModel, self).__init__()
        self.num_layers = len(num_states_per_layer)
        self.layers = nn.ModuleList()
        self.ttl_inital = ttl_inital
        self.num_observations = num_states_per_layer[-1]
        self.num_states_per_layer = num_states_per_layer
        
        # 初始状态分布
        self.initial_state_probs = nn.Parameter(torch.empty(num_states_per_layer[0]))
        torch.nn.init.uniform_(self.initial_state_probs, -1, 1)

        # 创建每层的状态转移模块
        for i in range(self.num_layers - 1):
            layer = nn.Linear(num_states_per_layer[i], num_states_per_layer[i + 1])
            self.layers.append(layer)
        
        # 创建从最后一层状态到观测值的映射
        self.to_observations = nn.Linear(num_states_per_layer[-2], num_states_per_layer[-1])
        
        # 初始化权重矩阵
        if transition_matrices is not None:
            self._initialize_transition_matrices(transition_matrices)

    def forward(self, x):
        # 应用初始状态分布
        x = torch.softmax(self.initial_state_probs, dim=0).unsqueeze(0)  # 增加batch维度
        for layer in self.layers:
            x = torch.softmax(layer(x), dim=1)
        observations = torch.softmax(self.to_observations(x), dim=1)
        return observations

# 定义变分分布
class VariationalDistribution(nn.Module):
    def __init__(self):
        super(VariationalDistribution, self).__init__()
        self.q_mu = nn.Parameter(torch.randn(1))
        self.q_log_var = nn.Parameter(torch.randn(1))
    
    def sample(self):
        std = torch.exp(0.5 * self.q_log_var)
        return self.q_mu + std * torch.randn_like(self.q_mu)

    def log_prob(self, z):
        std = torch.exp(0.5 * self.q_log_var)
        return -0.5 * torch.sum((z - self.q_mu)**2 / std**2 + torch.log(2 * torch.pi * std**2))

# 变分贝叶斯推断
def variational_inference(model, variational_dist, data, num_samples=1000):
    optimizer = optim.Adam(list(model.parameters()) + list(variational_dist.parameters()), lr=0.01)

    for _ in range(1000):  # 迭代优化
        optimizer.zero_grad()
        
        # 从变分分布中采样
        z_samples = torch.stack([variational_dist.sample() for _ in range(num_samples)])
        
        # 计算ELBO
        log_q_z = variational_dist.log_prob(z_samples).mean()
        log_p_x_z = -((data - model.forward())**2).mean()
        elbo = log_p_x_z - log_q_z
        
        # 反向传播和优化
        loss = -elbo
        loss.backward()
        optimizer.step()
    
    return variational_dist

# 假设观测数据
data = torch.tensor([3.0])

# 实例化模型和变分分布
model = TopologyBayesianModel()
variational_dist = VariationalDistribution()

# 执行变分贝叶斯推断
variational_dist = variational_inference(model, variational_dist, data)

# 输出近似的后验分布参数
print("近似后验分布的均值:", variational_dist.q_mu.item())
print("近似后验分布的方差:", torch.exp(variational_dist.q_log_var).item())