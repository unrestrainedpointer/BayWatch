def process_probes(file_path):
    probes_data = {}

    # 读取文件并按(probe_dst_prefix, probe_ttl)组合分类存储cumulative_probes和round信息
    with open(file_path, 'r') as f:
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) != 5:
                continue
            _, dst_prefix, ttl, cumulative, round = parts
            key = (dst_prefix, ttl)
            if key not in probes_data:
                probes_data[key] = []
            probes_data[key].append((int(round), int(cumulative)))

    total_cumulative_all = 0
    for _, values in probes_data.items():
        sorted_values = sorted(values, key=lambda x: x[0])  # 按round排序
        seen_cumulative = set()
        for round, cumulative in sorted_values:
            if cumulative in seen_cumulative:
                break  # 遇到重复的cumulative_probes时停止累加
            seen_cumulative.add(cumulative)
            total_cumulative_all += cumulative

    return total_cumulative_all

# 请替换为你的实际文件路径
file_path = 'prbes_100000_fmc_round_3'
total_cumulative = process_probes(file_path)

print(f"Total cumulative probes across all groups and rounds: {total_cumulative}")