from diamond_miner.queries import InsertLinks
from configure_motivation import credentials
from pych_client import ClickHouseClient

with ClickHouseClient(**credentials) as client:
    InsertLinks().execute(client, 'cb2cfd9e-15ab-4880-a251-8dc882d4e481')