import matplotlib.pyplot as plt
import numpy as np

# KL散度值
kl_divergences = [0, 0.4, 0.8, 1.2, 1.6, 2.0]

# 准确率数据
# Diamond-miner Node Accuracy
dm_node_acc = [100, 100, 95.74, 91.49, 78.72, 75.53]  # 转换为百分比
# Diamond-miner Edge Accuracy
dm_edge_acc = [100, 83.37, 74.11, 47.27, 34.68, 28.98]  # 转换为百分比
# RGMDA Node Accuracy
rgmda_node_acc = [100, 100, 97.87, 97.87, 94.68, 89.36]  # 转换为百分比
# RGMDA Edge Accuracy
rgmda_edge_acc = [100, 91.69, 81.47, 64.61, 60.81, 47.51]  # 转换为百分比

# 设置柱状图的宽度
bar_width = 0.2

# 设置位置
index = np.arange(len(kl_divergences))

# 创建柱状图
fig, ax = plt.subplots(figsize=(10, 8))  # 增大图表大小
# 设置颜色和条纹样式
patterns = ['//', 'xx', '\\\\', '++']
colors = ['#FF7F50', '#B8860B', '#CD5C5C', '#FA8072']

bars1 = ax.bar(index, dm_node_acc, bar_width, label='Diamond-miner Node Accuracy', color='none', edgecolor='#FF7F50', hatch=patterns[0], linewidth=1.5)
bars2 = ax.bar(index + bar_width, dm_edge_acc, bar_width, label='Diamond-miner Edge Accuracy', color='none', edgecolor='#3CB371', hatch=patterns[1], linewidth=1.5)
bars3 = ax.bar(index + 2 * bar_width, rgmda_node_acc, bar_width, label='RGMDA Node Accuracy', color='none', edgecolor='#B8860B', hatch=patterns[2], linewidth=1.5)
bars4 = ax.bar(index + 3 * bar_width, rgmda_edge_acc, bar_width, label='RGMDA Edge Accuracy', color='none', edgecolor='#CD5C5C', hatch=patterns[3], linewidth=1.5)

# 添加图表标签和标题
ax.set_xlabel('KL Divergence')
ax.set_ylabel('Accuracy (%)')
ax.set_title('Accuracy by KL Divergence and Method')
ax.set_xticks(index + 1.5 * bar_width)
ax.set_xticklabels(kl_divergences)

# 添加背景虚线
ax.grid(True, linestyle='--', which='both', color='grey', alpha=0.5)

# 添加图例
ax.legend()

# 显示图表
plt.tight_layout()  # 自动调整布局
plt.show()

# 保存为PDF文件
fig.savefig("topology_accuracy_chart.pdf", bbox_inches='tight')