from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import ResultsQuery, results_table
from diamond_miner.typing import IPNetwork

@dataclass(frozen=True)
class Query_finished_ttl(ResultsQuery):
    round_eq: int | None = None  # 这是你可以指定的参数

    def statement(self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET) -> str:
        return f'''
        WITH filtered_prefixes AS (
            SELECT 
                probe_dst_prefix, 
                probe_ttl,
                COUNT(DISTINCT reply_src_addr) AS distinct_count
            FROM 
                {results_table(measurement_id)}
            WHERE 
                round < {self.round_eq}
            GROUP BY 
                probe_dst_prefix, probe_ttl
        ),
        comparison_prefixes AS (
            SELECT 
                probe_dst_prefix, 
                probe_ttl,
                COUNT(DISTINCT reply_src_addr) AS distinct_count
            FROM 
                {results_table(measurement_id)}
            WHERE 
                round <= {self.round_eq}
            GROUP BY 
                probe_dst_prefix, probe_ttl
        )
        SELECT DISTINCT fp.probe_dst_prefix, fp.probe_ttl
        FROM filtered_prefixes fp
        JOIN comparison_prefixes cp 
        ON fp.probe_dst_prefix = cp.probe_dst_prefix 
        AND fp.probe_ttl = cp.probe_ttl
        WHERE fp.distinct_count = cp.distinct_count;
    '''
import pandas as pd
from pych_client import ClickHouseClient
'''
if __name__ == '__main__':
    credentials = {
        "base_url": "http://localhost:8123",
        "database": "default",
        "username": "default",
        "password": "",
    }
    with ClickHouseClient(**credentials) as client:
        result_csv = pd.DataFrame(Query_finished_ttl(round_eq=6).execute(client, '91255cc6-55fd-4ac6-a985-23ee42ddb48e'))
        result_csv = result_csv.groupby('probe_dst_prefix')
        print(result_csv.get_group('::ffff:64.172.247.0')['probe_ttl'].tolist())
'''

