from clickhouse_driver import Client
import copy
from diamond_miner.generators import probe_generator_parallel
from diamond_miner.insert import insert_probe_counts
from diamond_miner.queries import CreateTables, InsertLinks, InsertPrefixes, InsertResults
from diamond_miner.queries.query import probes_table
import gc
import logging
import multiprocessing
from multiprocessing import Pool, Value, Lock
import os
import pandas as pd
from pathlib import Path
from pych_client import ClickHouseClient
import signal
import time
from utils.algorithm import rgmda_statistical_gurantee
from utils.algorithm_utils import get_context_switches
from utils.configure import credentials, measurement_id, prefixes, logger, ALERT_LEVEL
from deletet import drop, string
from utils.get_cumulative_probe import Query_probes
from utils.get_links import GetLinksFromResults
from utils.get_nodes import GetNodesFromResults
from utils.query_finished_ttl import Query_finished_ttl
from utils.query_matrix import Query_Matrix
from utils.select_parameter import Query_parameter
from utils_baymuda import correct_round, send_probes

CONTINUE_ROUND = 2
logging.basicConfig(level=ALERT_LEVEL)
# 运行需要sudo -s 然后需要ulimit -n 50000 然后再运行

# 创建一个Value来跟踪休眠的进程数
sleeping_processes = Value('i', 0)
# 创建一个Lock以同步对该值的访问
lock = Lock()
# 允许进入休眠状态的最大进程数
max_sleeping_processes = 12

sleeping_processes_write = Value('i', 0)
lock_write = Lock()
max_sleeping_processes_write = 12

last_sleep_time = Value('d', time.time())

def process_result(args):
    i, result, measurement_id, round_, len_results, finished_ttl_prefix, finished_ttl_by_round_p = args
    global sleeping_processes
    global lock
    global last_sleep_time

    sleep_time_base = 2  # 基础睡眠时间
    cooldown_time = 60  # 冷却时间
    high_threshold = 50
    low_threshold = 20    # 低阈值

    current_load = os.getloadavg()[0]

    with lock:
        # 检查是否超过冷却时间，并且负载高于高阈值
        if current_load > high_threshold and time.time() - last_sleep_time.value > cooldown_time:
            while current_load > low_threshold and sleeping_processes.value < max_sleeping_processes:
                print(f"High load detected at {current_load}. Process {i} sleeping for {sleep_time_base} seconds...")
                time.sleep(sleep_time_base)
                sleeping_processes.value += 1
                current_load = os.getloadavg()[0]  # 再次检查负载
            # 更新最后一次睡眠时间
            last_sleep_time.value = time.time()
            print(f"Load reduced to {current_load}, exiting sleep mode.")

    pid = os.getpid()
    initial_voluntary, initial_nonvoluntary = get_context_switches(pid)
    
    if initial_voluntary is None or initial_nonvoluntary is None:
        print(f"Failed to retrieve context switches for process {pid}")
        return

    # 开始处理任务
    prefix, results, finished_ttl_by_round_p, F = rgmda_statistical_gurantee(result, round_, finished_ttl_prefix, finished_ttl_by_round_p)

    # 处理完毕后再次获取上下文切换次数
    final_voluntary, final_nonvoluntary = get_context_switches(pid)
    
    if final_voluntary is None or final_nonvoluntary is None:
        print(f"Failed to retrieve context switches for process {pid}")
        return

    # 计算上下文切换的总次数
    total_context_switches = (final_voluntary - initial_voluntary) + (final_nonvoluntary - initial_nonvoluntary)
    
    # 如果上下文切换次数超过阈值，记录prefix并终止进程
    # if total_context_switches > 5000:
    with open('terminated_processes.txt', 'a') as f:
        f.write(f"{os.getpid()}: {prefix}\n")
    # print(f"Process {i} exceeded context switch limit. Terminating...")
    # os.kill(os.getpid(), signal.SIGKILL)

    if i != 0 and i % 10000 == 0:
        logger.alert(f"**********************************************************************************")
        logger.alert(f"The {i}th prefix of {len_results}(round: {round_}, measurement_id: {measurement_id})")
        logger.alert(f"**********************************************************************************")
    
    # 完成工作后，减少休眠进程的计数
    with lock:
        if sleeping_processes.value > 0:
            sleeping_processes.value -= 1
    return prefix, results, finished_ttl_by_round_p, F

def write_and_insert_database(all_results, measurement_id, finished_ttl_by_round, finished_prefix):
    # 打包参数对
    args = [(all_results[result_i], measurement_id, result_i, len(all_results)) for result_i in range(len(all_results))]
    start_time = time.time()

    credentials_0 = {
        "host": "localhost",  # 通常，ClickHouse HTTP 接口监听在 localhost 的 8123 端口
        "port": "9000",       # 默认端口为 8123，这里显式指定
        "user": "default",    # 默认用户
        "password": "",       # 对应的密码，这里为空
        "database": "default" # 默认数据库
    }
    client = Client(**credentials_0)
    for result_i in range(len(all_results)):
        prefix = all_results[result_i][0]
        probes_w = all_results[result_i][1]
        finished_ttl_by_round[prefix] = all_results[result_i][2]
        if all_results[result_i][3]: 
            finished_prefix.add(prefix)
        client.execute(f'INSERT INTO {probes_table(measurement_id)} (probe_protocol, probe_dst_prefix, probe_ttl, cumulative_probes, round) VALUES', probes_w)
        if result_i % 10000 == 0:
            logger.alert(f"**********************************************************************************")
            logger.alert(f"The {result_i}th prefix of {len(all_results)} has been inserted(round: {round_}, measurement_id: {measurement_id})")
            logger.alert(f"**********************************************************************************")
    end_time = time.time()

    del all_results
    gc.collect()

    logger.alert(f"Insert operation takes {end_time - start_time:.2f} seconds.")
    return finished_ttl_by_round, finished_prefix

if __name__ == '__main__':
    if multiprocessing.get_start_method(allow_none=True) is None:
        multiprocessing.set_start_method('spawn')    

    finished_ttl_by_round, finished_prefix, num_finished_prefix = {}, set({}), []
    for round_ in range(CONTINUE_ROUND, 100): 
        num_finished_prefix.append(len(finished_prefix))
        logger.alert(f"ROUND {round_}--Number of Finished Prefixes: {len(finished_prefix)}")
        if round_ == 1:
            with ClickHouseClient(**credentials) as client:
                insert_probe_counts(client=client, measurement_id=measurement_id, round_=1, prefixes=prefixes)
        else:
            start_time = time.time()
            if round_ > CONTINUE_ROUND:
                results_filepath_last_round = Path("/root/NSDI_24/rgmda/examples/output/results" + "_" + str(round_ - 1) + ".csv")
                probes_filepath_last_round = Path("/root/NSDI_24/rgmda/examples/output/probes" + "_" + str(round_ - 1) + ".csv")
                    
                result = []
                correct_round(results_filepath_last_round, round_)
                with ClickHouseClient(**credentials) as client:
                    InsertResults().execute(client, measurement_id, data=results_filepath_last_round.read_bytes())
                    InsertPrefixes().execute(client, measurement_id)
                    InsertLinks().execute(client, measurement_id)

                os.remove(results_filepath_last_round)
                os.remove(probes_filepath_last_round)

            with ClickHouseClient(**credentials) as client:
                result = pd.DataFrame(Query_parameter().execute(client, measurement_id))
                probes = pd.DataFrame(Query_probes(round_eq=round_ - 1).execute(client, measurement_id=measurement_id))
                finished_ttl = pd.DataFrame(Query_finished_ttl(round_eq=round_-1).execute(client, measurement_id)) if round_ > 2 else []
                matrix = pd.DataFrame(Query_Matrix().execute(client, measurement_id))
                if len(finished_ttl) > 0:
                    finished_ttl = finished_ttl.groupby('probe_dst_prefix')

            result_probes = pd.merge(result, probes, on='probe_dst_prefix', how='inner')  # 默认是 'inner' 连接
            result_probe_matrix = pd.merge(result_probes, matrix, on='probe_dst_prefix', how='inner')

            tasks = []
            for i in range(len(result_probe_matrix)):
                prefix = result_probe_matrix.iloc[i]['probe_dst_prefix']
                if prefix in finished_prefix:
                    continue
                finished_ttl_prefix = set([])
                if len(finished_ttl) != 0 and prefix in finished_ttl['probe_dst_prefix'].groups:
                    finished_ttl_prefix = set(finished_ttl.get_group(prefix)['probe_ttl'].tolist())
                if prefix not in finished_ttl_by_round.keys():
                    finished_ttl_by_round[prefix] = {}
                if 'll_round' not in finished_ttl_by_round[prefix].keys():
                    finished_ttl_by_round[prefix]['ll_round'] = set([])
                if 'l_round' not in finished_ttl_by_round[prefix].keys():
                    finished_ttl_by_round[prefix]['l_round'] = set([])
                finished_ttl_by_round_p = copy.deepcopy(finished_ttl_by_round[prefix])
                tasks.append((i, result_probe_matrix.iloc[i], measurement_id, round_, len(result_probe_matrix), finished_ttl_prefix, finished_ttl_by_round_p))
            end_time = time.time()
            logger.alert(f"Preprocess in round {round_} takes {end_time - start_time:.2f} seconds.")

            start_time = time.time()
            with Pool() as pool:
                results = pool.map(process_result, tasks)
            end_time = time.time()
            logger.alert(f"Pararmeter Estimation in round {round_} takes {end_time - start_time:.2f} seconds.")

            # 分别写入数据库
            logger.alert(f"Begin to write to file and clickhouse!")
            finished_ttl_by_round, finished_prefix = write_and_insert_database(results, measurement_id, finished_ttl_by_round, finished_prefix)
            logger.alert(f"Finish writing to file and clickhouse!")

        probes_filepath = Path("/root/NSDI_24/rgmda/examples/output/probes" + "_" + str(round_) + ".csv")
        results_filepath = Path("/root/NSDI_24/rgmda/examples/output/results" + "_" + str(round_) + ".csv")

        with ClickHouseClient(**credentials) as client:
            # Write the probes to a file
            n_probes = probe_generator_parallel(filepath=probes_filepath, client=client, measurement_id=measurement_id, round_=round_)
        logger.alert("n_probes=%s", n_probes)
        if n_probes == 0: break
        try:
            start_time = time.time()
            send_probes(results_filepath, probes_filepath)
            end_time = time.time()
            logger.alert(f"Probing in round {round_} takes {end_time - start_time:.2f} seconds.")
        except RuntimeError as e:
            logging.error("Probing failed: %s", e)
            drop([string(measurement_id)])
            raise

    with ClickHouseClient(**credentials) as client:
        nodes = GetNodesFromResults().execute(client, measurement_id)
        links = GetLinksFromResults().execute(client, measurement_id)
    logger.alert(f"Number of Finished Prefixes: {num_finished_prefix}")
    logger.alert(f"{nodes[0].values()} nodes discovered")
    logger.alert(f"{links[0].values()} links discovered")
    gc.collect()