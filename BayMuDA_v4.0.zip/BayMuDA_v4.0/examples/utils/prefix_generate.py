import random
from ipaddress import IPv4Network
import os

# 定义私有和保留地址范围
PRIVATE_RANGES = [
    IPv4Network("10.0.0.0/8"),
    IPv4Network("172.16.0.0/12"),
    IPv4Network("192.168.0.0/16")
]

RESERVED_RANGES = [
    IPv4Network("0.0.0.0/8"),
    IPv4Network("127.0.0.0/8"),
    IPv4Network("169.254.0.0/16"),
    IPv4Network("224.0.0.0/4"),
    IPv4Network("240.0.0.0/4")
]

# 定义函数来检查一个地址是否在私有或保留范围内
def is_reserved_or_private(prefix: IPv4Network) -> bool:
    for network in PRIVATE_RANGES + RESERVED_RANGES:
        if prefix.subnet_of(network):
            return True
    return False

# 获取已有的前缀列表
existing_prefixes = set()
output_file_old = "/root/SIGCOMM_25/BayMuDA_v1.0/examples/utils/prefixes_full_14_000_000_old"
if os.path.exists(output_file_old):
    with open(output_file_old, "r") as f:
        # 读取文件并将已有前缀存储到集合中（集合自动去重）
        existing_prefixes = set(line.strip() for line in f)

# 新生成的前缀列表
new_prefixes = []

# 遍历所有可能的 /24 前缀，去除私有和保留前缀
for i in range(256):  # IPv4地址的第一部分（0-255）
    for j in range(256):  # 第二部分（0-255）
        for k in range(256):  # 第三部分（0-255）
            # 构建 /24 前缀
            prefix_str = f"{i}.{j}.{k}.0"
            prefix = IPv4Network(f"{prefix_str}/24", strict=False)

            # 检查是否是私有或保留前缀
            if not is_reserved_or_private(prefix):
                # 添加到新的前缀列表
                new_prefixes.append(prefix_str)

# 打乱新前缀的顺序
random.shuffle(new_prefixes)

# 过滤出没有在已有文件中的前缀
new_prefixes = [prefix for prefix in new_prefixes if prefix not in existing_prefixes]

# 写入新前缀到文件
output_file = "/root/SIGCOMM_25/BayMuDA_v1.0/examples/utils/prefixes_full_14_000_000"
with open(output_file, "a") as f:  # 以追加模式打开文件
    for prefix in new_prefixes:
        f.write(f"{prefix}\n")

print("IPv4 prefixes have been added to:", output_file)