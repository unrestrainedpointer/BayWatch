from collections import Counter
from diamond_miner.defaults import DEFAULT_FAILURE_RATE
from math import ceil
import numpy as np
import math
import torch
from utils.algorithm_utils import cal_ttl_init, generate_dict, gini_coefficient
from utils.neural_network import cal_m_k, cal_n_k, TopologyNeuralNetwork, train

def calculate_i(ttl_inital, keys):
    if ttl_inital == 2: 
        return -1
    for i_tmp in range(len(keys)):
        if keys[i_tmp] == ttl_inital:
            i = i_tmp
            return i
    return -1

def calculate_initial_distribution(y, is_finished):
    count = list(Counter(y).values())
    if not is_finished:
        count.append(0)
    return count

def calculate_matrix(matrix, shape):
    initial_matrix = np.zeros(shape)
    for elem in matrix:
        # print(f"elem: {elem}")
        # pos_tmp = elem['id_pair']
        pos_tmp = elem[0]
        # pos, value = (pos_tmp['near_id'], pos_tmp['far_id']), elem['id_pair_count']
        pos, value = (pos_tmp[0], pos_tmp[1]), elem[1]
        if pos[0]-1 < shape[0] and pos[1]-1 < shape[1]:
            initial_matrix[pos[0]-1][pos[1]-1] = value
    initial_matrix = initial_matrix.tolist()
    for i in range(len(initial_matrix)):
        initial_matrix[i] = torch.softmax(torch.tensor(initial_matrix[i], dtype=torch.float32), dim=0).tolist()
    return initial_matrix

def can_multiply_matrices(matrix_list):
    if len(matrix_list) < 2:
        return True  # 只有一个矩阵或者没有矩阵时，可以认为是可以连乘的
    
    for i in range(len(matrix_list) - 1):
        cols_a = len(matrix_list[i][0])
        rows_b = len(matrix_list[i + 1])
        
        if cols_a != rows_b:
            return False  # 如果前一个矩阵的列数不等于后一个矩阵的行数，无法连乘
    
    return True  # 所有相邻的矩阵都可以连乘

def f_or_not(ttl, prefix, finished_ttl_by_round_p):
    return ttl in finished_ttl_by_round_p['ll_round'] or ttl in finished_ttl_by_round_p['l_round']

def process_result(dict_result, finished_ttl_by_round_p, round_):
    model_structure, prefix = {}, dict_result['probe_dst_prefix']
    # print(f"dict_result: {dict_result}")
    dict_ttls, dict_y = generate_dict(dict_result['ttls'], dict_result['list_n'], dict_result['list_y'], dict_result['ttl_and_probes_array'])
    dict_ttls = {k: dict_ttls[k] for k in sorted(dict_ttls, reverse=True)}
    # for item in dict_result['ttl_pairs']:
        # print(f"item: {item}\n")
    # dict_matrixes = {item['near_ttl']: item['id_pairs'] for item in dict_result['ttl_pairs']}
    dict_matrixes = {item[0]: item[1] for item in dict_result['ttl_pairs']}

    keys, i = list(dict_ttls.keys()), 0
    loop_count = 0
    while i < len(keys) and i >= 0:
        loop_count += 1
        if loop_count > 10:
            print(f"Looping Exception: {loop_count}")
            break
        ttl_final = keys[i]
        ttl_inital = cal_ttl_init(ttl_final, dict_ttls)
        
        f = f_or_not(ttl_inital, prefix, finished_ttl_by_round_p)
        initial_distribution = calculate_initial_distribution(dict_y[ttl_inital], f) if ttl_inital in dict_ttls.keys() else [1]
        count = list(Counter(dict_y[ttl_final]).values())
        num_states_per_layer, initial_matrixes, unfinished_ttl_exit = [], [], False
        for ttl_tmp in range(ttl_inital, ttl_final):
            unfinished_ttl_exit = unfinished_ttl_exit or (ttl_tmp not in finished_ttl_by_round_p['ll_round'])
            next_nodes_num = dict_ttls[ttl_tmp+1] if ttl_tmp+1 in dict_ttls.keys() else 1
            next_nodes_num = next_nodes_num + 1 if not f_or_not(ttl_tmp+1, prefix, finished_ttl_by_round_p) and ttl_tmp+1 in dict_ttls.keys() and ttl_tmp+1 != ttl_final else next_nodes_num
            next_nodes_num = len(count) if ttl_tmp == ttl_final - 1 else next_nodes_num
            if f_or_not(ttl_tmp, prefix, finished_ttl_by_round_p):
                current_nodes_num = dict_ttls[ttl_tmp] if ttl_tmp in dict_ttls.keys() else 1
                num_states_per_layer.append(current_nodes_num)
                initial_matrix = calculate_matrix(dict_matrixes[ttl_tmp], (current_nodes_num, next_nodes_num)) if ttl_tmp in dict_matrixes.keys() else np.full((current_nodes_num, next_nodes_num), 1/next_nodes_num).tolist()
            else:
                current_nodes_num = dict_ttls[ttl_tmp]+1 if ttl_tmp in dict_ttls.keys() else 1
                num_states_per_layer.append(current_nodes_num)
                initial_matrix = calculate_matrix(dict_matrixes[ttl_tmp], (current_nodes_num, next_nodes_num)) if ttl_tmp in dict_matrixes.keys() else np.full((current_nodes_num, next_nodes_num), 1/next_nodes_num).tolist()
            initial_matrixes.append(initial_matrix)
        num_states_per_layer.append(len(count))

        if unfinished_ttl_exit:# ttl_inital到ttl_final的TTL都结束了，那就不需要训练模型了啊
            model_structure[(ttl_inital, ttl_final)] = (initial_distribution, initial_matrixes, num_states_per_layer, dict_y[ttl_final])
        i = calculate_i(ttl_inital, keys)
    return model_structure

def remove_first_min(lst):
    if not lst:
        return []
    min_val = min(lst)
    return [x for x in lst if x != min_val]

def model_construct_train(model_structure):
    distribution_ttl, matrix_ttl, model_structure, is_uniform = {}, {}, dict(sorted(model_structure.items(), key=lambda item: item[0][0])), {}
    for ttl_interval in model_structure.keys():
        model_para = model_structure[ttl_interval]
        initial_distribution, initial_matrixes, num_states_per_layer, y = model_para[0], model_para[1], model_para[2], model_para[3]
        # 如果每一层的Gini系数都不大的话，就做均匀分布假设，不估计了
        if(len(remove_first_min(initial_distribution)) != 0):
            gini_list = [gini_coefficient(remove_first_min(initial_distribution))]
        else:
            gini_list = [gini_coefficient(initial_distribution)]
        for i in range(len(initial_matrixes)):
            if(len(remove_first_min(initial_matrixes[i])) != 0):
                gini_list.append(gini_coefficient(remove_first_min(initial_matrixes[i])))
            else:
                gini_list.append(gini_coefficient(initial_matrixes[i]))
        if all(gini <= 0.4 for gini in gini_list):
            for ttl_i in range(ttl_interval[0], ttl_interval[1]):
                if ttl_i not in distribution_ttl.keys():
                    distribution_ttl[ttl_i] = [1/len(initial_distribution) for _ in range(len(initial_distribution))]
                    matrix_ttl[ttl_i] = [[1/len(initial_matrixes[i]) for _ in range(len(initial_matrixes[i]))] for i in range(len(initial_matrixes))]
                    is_uniform[ttl_i] = True
            continue
        topology_bayes = TopologyNeuralNetwork(initial_distribution, initial_matrixes, num_states_per_layer)
        train(topology_bayes, y)
        layer_distributions, transition_matrices = topology_bayes.get_distributions(), topology_bayes.get_transition_matrices()
        for ttl_i in range(ttl_interval[0], ttl_interval[1]):
            if ttl_i not in distribution_ttl.keys():
                distribution_ttl[ttl_i] = layer_distributions[ttl_i-ttl_interval[0]]
                matrix_ttl[ttl_i] = transition_matrices[ttl_i-ttl_interval[0]]
                is_uniform[ttl_i] = False
    return distribution_ttl, matrix_ttl, is_uniform

def find_min_index(distribution):
    min_index = 0
    for i in range(len(distribution)):
        if distribution[i] < distribution[min_index]:
            min_index = i
    return min_index

def select_p_by_gini(distribution):
    gini_distribution = gini_coefficient(distribution)
    if len(distribution) <= 2:
        # return min(distribution) if gini_coefficient(distribution) < 0.4 else max(distribution)
        return min(distribution) if gini_coefficient(distribution) < 0.4 else max(distribution)
    if gini_distribution < 0.4:
        # return min(distribution)
        return 1/len(distribution)
    first = max(distribution)
    distribution_copy = [i for i in distribution]
    distribution_copy.remove(first)
    second = max(distribution_copy)
    gini_fs = gini_coefficient([first, second])
    gini_copy = gini_coefficient(distribution_copy)
    values_above = [v for v in distribution if v > 0.02]
    min_value = min(values_above) if len(values_above) > 0 else 0.5
    if gini_fs > 0.4:
        return first
    if gini_fs > 0.3:
        if gini_copy < 0.3:
            return min(distribution_copy)
        while gini_copy > 0.3 and len(distribution_copy) > 1:
            distribution_copy.remove(min(distribution_copy))
            gini_copy = gini_coefficient(distribution_copy)
        return min(distribution_copy) if min(distribution_copy) > 0.002 else max(distribution_copy)
    while gini_coefficient(distribution) > 0.3:
        distribution.remove(min(distribution))
    return min(distribution) if min(distribution) > 0.002 else max(distribution)
    
def calculate_probes(ttls, probes_ttl, parameters, finished_ttl_by_round_p):
    layer_distributions, transition_matrixes, probes_send = parameters[0], parameters[1], {}
    for ttl in layer_distributions.keys():
        # print(f"probes_ttl: {probes_ttl}")
        # current_probe = probes_ttl[ttl-2]['max_cumulative_probes']
        current_probe = probes_ttl[ttl-2][1]
        if ttl in finished_ttl_by_round_p['ll_round'] and ttl + 1 in finished_ttl_by_round_p['ll_round']:
            probes_send[ttl] = current_probe# ttl结束了，那就不需要发包了，发包数和上一轮一样就行了
            continue
        if ttl not in set(ttls):# 节点为0的ttl，既然此prefix出现就是没结束，那就继续发6个包
            probes_send[ttl] = current_probe + 6
            continue
        mask = [p_i != 0 for p_i in layer_distributions[ttl]]
        dis_tmp = [p_i for p_i in layer_distributions[ttl] if p_i != 0]
        if len(dis_tmp) < 2:
            continue
        try:
            n = min(cal_n_k(dis_tmp, DEFAULT_FAILURE_RATE), 1000)
        except ZeroDivisionError as e:
            print(layer_distributions[ttl])
            print(dis_tmp)
            raise e

        probes_send[ttl] = n
        min_index = find_min_index(dis_tmp)
        p = select_p_by_gini(transition_matrixes[ttl][min_index])
        m_k = cal_m_k(transition_matrixes[ttl][min_index], p, DEFAULT_FAILURE_RATE)
        for distribution_i in range(len(transition_matrixes[ttl])):
            if not mask[distribution_i]:
                continue
            p = select_p_by_gini(transition_matrixes[ttl][distribution_i])
            m = cal_m_k(transition_matrixes[ttl][distribution_i], p, DEFAULT_FAILURE_RATE)
            if layer_distributions[ttl][distribution_i] == 0 or layer_distributions[ttl][min_index] == 0:
                continue
            if ttl not in finished_ttl_by_round_p['ll_round']:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m/layer_distributions[ttl][distribution_i]-m_k/layer_distributions[ttl][min_index]), 5000))
            else:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m/layer_distributions[ttl][distribution_i]), 50000))
    return probes_send

def calculate_probes_for_probing(link_ttls, links, round, prefix, ttls, probes_ttl, parameters, finished_ttl_by_round_p):
    layer_distributions, transition_matrixes, is_uniform, probes_send, counter = parameters[0], parameters[1], parameters[2], {}, 0
    for ttl in layer_distributions.keys():
        if is_uniform[ttl]:
            # print(counter)
            counter += 1
        if ttl not in link_ttls:
            link_num = 0
        else:
            link_index = 0
            for link_i in range(len(link_ttls)):
                if link_ttls[link_i] == ttl:
                    link_index = link_i
                    break
            link_num = links[link_index]
        current_probe = probes_ttl[ttl-2][1]
        if ttl in finished_ttl_by_round_p['ll_round'] and ttl + 1 in finished_ttl_by_round_p['ll_round']:
            probes_send[ttl] = current_probe# ttl结束了，那就不需要发包了，发包数和上一轮一样就行了
            continue
        if ttl not in set(ttls):# 节点为0的ttl，既然此prefix出现就是没结束，那就继续发6个包
            probes_send[ttl] = current_probe + 6
            continue
        mask = [p_i != 0 for p_i in layer_distributions[ttl]]
        dis_tmp = [p_i for p_i in layer_distributions[ttl] if p_i != 0]
        if len(dis_tmp) < 2:
            continue
        try:
            n = min(cal_n_k(dis_tmp, DEFAULT_FAILURE_RATE), 500)
        except ZeroDivisionError as e:
            print(layer_distributions[ttl])
            print(dis_tmp)
            raise e

        probes_send[ttl] = n
        min_index = find_min_index(dis_tmp)
        p = select_p_by_gini(transition_matrixes[ttl][min_index])
        m_k = cal_m_k(transition_matrixes[ttl][min_index], p, DEFAULT_FAILURE_RATE)
        for distribution_i in range(len(transition_matrixes[ttl])):
            if is_uniform[ttl]:
                link_num += 1
                m = cal_m_k([1/link_num for _ in range(link_num)], 1/link_num, DEFAULT_FAILURE_RATE)
                if ttl not in finished_ttl_by_round_p['ll_round']:
                    probes_send[ttl] = max(probes_send[ttl], ceil(m))
                else:
                    probes_send[ttl] = max(probes_send[ttl], ceil(m))
                continue
            if not mask[distribution_i]:
                continue
            link_prob, probe_max = [], 2000 if link_num < 300 else 4000
            probe_max = 1000 if link_num < 100 else probe_max
            probe_max = 500 if link_num < 50 else probe_max
            probe_max = 200 if link_num < 25 else probe_max
            for p_j in range(len(transition_matrixes[ttl][0])):
                for p_i in range(len(layer_distributions[ttl])):
                    if p_j < len(transition_matrixes[ttl][p_i]):
                        link_prob.append(layer_distributions[ttl][p_i] * transition_matrixes[ttl][p_i][p_j])
            import heapq
            link_prob = heapq.nlargest(link_num+1, link_prob)
            exps = [math.exp(v) for v in link_prob]
            total = sum(exps)
            link_prob = [e / total for e in exps]
            # link_prob = [sum(layer_distributions[ttl][p_i] * transition_matrixes[ttl][p_i][p_j] for p_i in range(len(layer_distributions[ttl]))) for p_j in range(len(transition_matrixes[ttl][0]))]
            p = select_p_by_gini(link_prob)
            m = cal_m_k(link_prob, p, DEFAULT_FAILURE_RATE)

            gini_link_prob = gini_coefficient(link_prob)
            if gini_link_prob < 0.5:
                m = cal_m_k(link_prob, 1/len(link_prob), DEFAULT_FAILURE_RATE) if len(link_prob) > 2 else m
            else:
                m = ceil(cal_m_k(link_prob, 1/len(link_prob), DEFAULT_FAILURE_RATE) * math.log(gini_link_prob * 10 - 2, 3)) if len(link_prob) > 2 else 100
            # if m > 200:
            #     print(f"prefix: {prefix}, round: {round}, ttl: {ttl}, len of links: {len(link_prob)}, gini_link_prob: {gini_link_prob}, m: {m}")
            if layer_distributions[ttl][distribution_i] == 0 or layer_distributions[ttl][min_index] == 0:
                continue
            if ttl not in finished_ttl_by_round_p['ll_round']:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m), probe_max))
            else:
                probes_send[ttl] = max(probes_send[ttl], min(ceil(m), probe_max))
    return probes_send

def construct_probes(statistical_gurantee, dict_result, round_):
    results_tmp = []
    for ttl in statistical_gurantee.keys():
        results_tmp.append((17, dict_result['probe_dst_prefix'], ttl, statistical_gurantee[ttl], round_))
    results, last_index = [], len(results_tmp) - 1
    if len(results_tmp) == 0:
        return []
    try:
        results.append((results_tmp[0][0], results_tmp[0][1], results_tmp[0][2], max(results_tmp[0][3], results_tmp[1][3]) ,results_tmp[0][4]))
    except:
        pass
    for result_i in range(1, last_index):
        results.append((results_tmp[result_i][0], results_tmp[result_i][1], results_tmp[result_i][2], max(max(results_tmp[result_i][3], results_tmp[result_i + 1][3]), results_tmp[result_i - 1][3]) ,results_tmp[result_i][4]))
    results.append((results_tmp[last_index][0], results_tmp[last_index][1], results_tmp[last_index][2], max(results_tmp[last_index][3], results_tmp[last_index - 1][3]) ,results_tmp[last_index][4]))
    return results

def correct_finished_ttl(dict_result, finished_ttl_prefix, round_):
    if round_ > 2:
        for ttl in range(2, 33):
            if ttl not in set(dict_result['ttls']):
                finished_ttl_prefix.add(ttl)
    return finished_ttl_prefix

def update_fininshed_ttl(finished_ttl_prefix, finished_ttl_by_round_p):
    finished_ttl_by_round_p['ll_round'] = finished_ttl_by_round_p['ll_round'].union(finished_ttl_by_round_p['l_round'])
    finished_ttl_by_round_p['l_round'] = set([])
    for ttl in finished_ttl_prefix:
        if ttl not in finished_ttl_by_round_p['ll_round']:
            finished_ttl_by_round_p['l_round'].add(ttl)
    return finished_ttl_by_round_p

def finsh(finished_ttl_by_round_p):
    F = True
    for i in range(2, 33):
        if i not in finished_ttl_by_round_p['ll_round']:
            F = False
    return F

def baymuda_statistical_gurantee(dict_result, round_, finished_ttl_prefix, finished_ttl_by_round_p):
    finished_ttl_prefix = correct_finished_ttl(dict_result, finished_ttl_prefix, round_)
    finished_ttl_by_round_p = update_fininshed_ttl(finished_ttl_prefix, finished_ttl_by_round_p)
    # 根据上一轮结果确定参数估计模型的结构
    model_structure = process_result(dict_result, finished_ttl_by_round_p, round_)
    # 参数估计模型的构建以及训练
    parameters = model_construct_train(model_structure)
    # 根据估计得到的参数确定每跳的发包数量
    statistical_gurantee = calculate_probes_for_probing(dict_result['link_ttls'], dict_result['links_array'], round_, dict_result['probe_dst_prefix'], dict_result['ttls'], dict_result['ttl_and_probes_array'], parameters, finished_ttl_by_round_p)
    results = construct_probes(statistical_gurantee, dict_result, round_) if len(statistical_gurantee) != 0 else []
    return dict_result['probe_dst_prefix'], results, finished_ttl_by_round_p, finsh(finished_ttl_by_round_p)
'''
if __name__ == '__main__':
    ''''''
    import pandas as pd
    from get_cumulative_probe import Query_probes
    from query_finished_ttl import Query_finished_ttl
    from query_matrix import Query_Matrix
    from select_parameter import Query_parameter
    from configure import credentials
    from pych_client import ClickHouseClient
    measurement_id = '91255cc6-55fd-4ac6-a985-23ee42ddb48e'
    with ClickHouseClient(**credentials) as client:
        result = pd.DataFrame(Query_parameter().execute(client, measurement_id))
        probes = pd.DataFrame(Query_probes(round_eq=5).execute(client, measurement_id=measurement_id))
        finished_ttl = pd.DataFrame(Query_finished_ttl(round_eq=5).execute(client, '91255cc6-55fd-4ac6-a985-23ee42ddb48e'))
        matrix = pd.DataFrame(Query_Matrix().execute(client, measurement_id))
    result_probes = pd.merge(result, probes, on='probe_dst_prefix', how='inner')  # 默认是 'inner' 连接
    result_probe_matrix = pd.merge(result_probes, matrix, on='probe_dst_prefix', how='inner')
    for i in range(len(result_probe_matrix)):
        prefix = result_probe_matrix.iloc[0]['probe_dst_prefix']
        finished_ttl_prefix = set([])
        if len(finished_ttl) != 0 and prefix in finished_ttl['probe_dst_prefix'].values:
            finished_ttl_prefix = set(finished_ttl.groupby('probe_dst_prefix').get_group(prefix)['probe_ttl'].tolist())
        dict_result, unfinished_ttl = result_probe_matrix.iloc[0], finished_ttl_prefix
        # model_structure = process_result(dict_result, finished_ttl_prefix)
        # model_construct_train(model_structure)
        baymuda_statistical_gurantee(dict_result, 5, finished_ttl_prefix, {})
'''
'''
    d_0 = [0.16031894087791443, 0.056162696331739426, 0.056162696331739426, 0.055942896753549576, 0.05555560812354088, 0.056162696331739426, 0.056162696331739426, 0.056162696331739426, 0.056162696331739426, 0.0561625212430954, 0.33504390716552734]
    d_1 = [0.013253448531031609, 0.011866091750562191, 0.011866091750562191, 0.011814105324447155, 0.011724359355866909, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866040527820587, 0.8801454305648804]
    d_2 = [0.48, 0.48, 0.04]
    print(select_p_by_gini(d_0))
    print(select_p_by_gini(d_1))
    print(select_p_by_gini(d_2))
'''