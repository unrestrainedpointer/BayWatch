import pandas as pd

# 读取CSV文件
df = pd.read_csv('/root/NSDI_24/diamonds/lb_pp.csv', header=None)

# 给列命名便于操作
df.columns = ['col1', 'col2', 'col3', 'col4', 'col5']

# 根据第一列分组，并计算每组第四列的最大值和最小值
grouped = df.groupby('col1')['col4'].agg(['min', 'max']).reset_index()

# 将结果保存到txt文件中
with open('prefix.txt', 'w') as f:
    for index, row in grouped.iterrows():
        f.write(f"{row['col1']}\t{row['min']}\t{row['max']+2}\n")