WITH
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__5132187b_60dc_4b11_9c5e_da2c06658ec0
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__5132187b_60dc_4b11_9c5e_da2c06658ec0
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 2 * lc.count_in_links
    ),
    nodes_to_delete_init_ttl AS (
        SELECT 
            r.reply_src_addr, 
            r.probe_dst_prefix, 
            r.probe_dst_addr, 
            r.probe_ttl
        FROM 
            results__5132187b_60dc_4b11_9c5e_da2c06658ec0 r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    RankedResults AS (
        SELECT
            r.reply_src_addr,
            r.probe_dst_prefix,
            r.probe_dst_addr,
            r.probe_ttl,
            ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
        FROM 
            results__5132187b_60dc_4b11_9c5e_da2c06658ec0 r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    filter_ttl AS (
        SELECT
            probe_dst_prefix,
            probe_dst_addr,
            probe_ttl
        FROM 
            RankedResults
        WHERE rn = 1
    ),
    results_filtered AS (
        SELECT
            r.*, r.probe_dst_prefix, ft.probe_ttl AS filtered_ttl
        FROM
            results__5132187b_60dc_4b11_9c5e_da2c06658ec0 r
        JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            r.probe_ttl < ft.probe_ttl
                
        UNION ALL

        SELECT
            r.*, r.probe_dst_prefix, 33 AS filtered_ttl
        FROM
            results__5132187b_60dc_4b11_9c5e_da2c06658ec0 r
        LEFT JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE
            ft.probe_dst_prefix = '::'   
    ),
    ttl_distribution AS (
        SELECT 
            probe_dst_prefix,
            probe_ttl,
            COUNT(DISTINCT reply_src_addr) AS node_count
        FROM 
            results_filtered
        GROUP BY 
            probe_dst_prefix, probe_ttl
    ),
    aggregated_data AS (
        SELECT
            probe_dst_prefix,
            groupArray((probe_ttl, node_count)) AS ttl_pairs
        FROM
            ttl_distribution
        GROUP BY
            probe_dst_prefix
    ),
    prefix_ttl_summary AS (
        SELECT
            probe_dst_prefix,
            arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
            arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_node_counts
        FROM 
            aggregated_data
    ),
    address_counts AS (
        SELECT 
            probe_dst_prefix,
            probe_ttl,
            reply_src_addr,
            COUNT(*) AS address_count
        FROM 
            results_filtered
        WHERE reply_src_addr != '::'
        GROUP BY 
            probe_dst_prefix, probe_ttl, reply_src_addr
    ),
    ttl_address_counts AS (
        SELECT
            probe_dst_prefix,
            probe_ttl,
            arraySort(groupArray(address_count)) AS sorted_address_counts  -- 确保每个地址计数数组内部排序
        FROM
            address_counts
        GROUP BY
            probe_dst_prefix, probe_ttl
    ),
    aggregated_data_y AS (
        SELECT
            probe_dst_prefix,
            groupArray((probe_ttl, sorted_address_counts)) AS ttl_pairs
        FROM
            ttl_address_counts
        GROUP BY
            probe_dst_prefix
    ),
    prefix_ttl_summary_y AS (
        SELECT
            probe_dst_prefix,
            arrayMap(pair -> pair.1, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_ttls,
            arrayMap(pair -> pair.2, arraySort(pair -> pair.1, ttl_pairs)) AS sorted_address_counts
        FROM 
            aggregated_data_y
    )
SELECT 
    probe_dst_prefix,
    sorted_ttls,
    sorted_address_counts
FROM
    prefix_ttl_summary_y