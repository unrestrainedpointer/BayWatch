def split_bits(n: int):
    """
    对 0 ≤ n < 2^15 的整数，返回高 8 位和低 7 位的值（都是整数）。
    """
    if not (0 <= n < (1 << 15)):
        raise ValueError("n 必须在 [0, 2^15) 范围内")
    high8 = n >> 7            # 右移 7 位，丢弃最低的 7 位，留下高 8 位
    low7  = n & ((1 << 7) - 1)  # 与 0b1111111（127）按位与，保留最低 7 位
    return high8, low7

print(split_bits(0))    # (0, 0)
print(split_bits(1))    # (0, 1)
print(split_bits(127))  # (0, 127)
print(split_bits(128))  # (1, 0)
print(split_bits(255))  # (1, 127)
print(split_bits(256))  # (255, 127)
print(split_bits(32767))  # (255, 127)