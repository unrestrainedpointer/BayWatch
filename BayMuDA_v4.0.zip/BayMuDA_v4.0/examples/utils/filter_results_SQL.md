> 初始情况：

        WITH
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            groupArray((probe_ttl, reply_src_addr)) AS nodes,
            arrayMap(t -> (t.1, countEqual(nodes, t)), uniq_nodes) AS y_nodes
        SELECT
            uniq_nodes,
            y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)

> 在此基础上识别uniq_nodes中哪些节点需要删除
    > 待删除初始节点：
        > 删除条件1：在results中出现的次数超过links中作为near_addr出现次数的1000倍
        >
        > 删除条件2：在links中near_addr为node的所有far_addr集合包含了links中near_addr为node且probe_dst_prefix和node一致的所有far_addr集合
    > 待删除节点：该前缀下从上面每一个初始节点开始的同一traceroute的所有后续节点
> 根据uniq_nodes中的所有待删除节点，y_nodes中也作出相应的调整
************************************************************************
************************************************************************
WITH
    -- 各种处理
    -- 首先根据上面的逻辑得到uniq_nodes: 每个探测前缀下所有的不同节点
    uniq_nodes_list AS (
        SELECT
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    )
    -- 接下来得到y_nodes: 每个目标前缀下每一跳对应的节点（就是该prefix下每个traceroute每一跳都是啥节点）
    y_nodes_list AS (
        SELECT
            groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    )
************************************************************************
************************************************************************
WITH
    uniq_nodes_list AS (
        SELECT
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    ),
    y_nodes_list AS (
        SELECT
            groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    ),
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__f8779caf_acf2_443a_9dde_deac1a8cb120
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 1000 * lc.count_in_links
    ),
    far_addr_sets AS (
        SELECT near_addr, groupArray(far_addr) AS far_addrs
        FROM links__f8779caf_acf2_443a_9dde_deac1a8cb120
        GROUP BY near_addr
    ),
    far_addr_comparison AS (
        SELECT f1.near_addr AS node
        FROM far_addr_sets f1
        JOIN uniq_nodes_list un ON f1.near_addr = un.probe_dst_prefix
        WHERE arrayContains(f1.far_addrs, (SELECT far_addrs FROM far_addr_sets WHERE near_addr = f1.near_addr))
    ),
    nodes_to_delete_final AS (
        SELECT node
        FROM nodes_to_delete_init
        INTERSECT
        SELECT node
        FROM far_addr_comparison
    ),
    marked_nodes AS (
        SELECT unnest(arrayAppend(arrayFill(x -> x, 1, probe_ttl), arrayMap(x -> x + 1, uniq_nodes))) AS marked_node
        FROM nodes_to_delete_final, uniq_nodes_list
        WHERE probe_dst_prefix = node
    ),
    marked_y_nodes AS (
        SELECT y_nodes
        FROM y_nodes_list
        WHERE arrayExists(x -> arrayElement(x, 2) IN (SELECT marked_node FROM marked_nodes), y_nodes)
    )
SELECT *
FROM marked_y_nodes;

Received exception from server (version 24.3.2):
Code: 43. DB::Exception: Received from localhost:9000. DB::Exception: First argument for function 'arrayElement' must be array, got 'Tuple(Tuple(UInt8, IPv6), IPv6)' instead: In scope x -> ((x[2]) IN (SELECT marked_node FROM marked_nodes)). (ILLEGAL_TYPE_OF_ARGUMENT)



************************************************************************
************************************************************************


WITH
    ranked_prefixes AS (
        SELECT
            probe_dst_prefix,
            ROW_NUMBER() OVER (ORDER BY probe_dst_prefix) as rn
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        GROUP BY probe_dst_prefix
        -- 确保每个前缀只被计算一次
    ),
    top_prefixes AS (
        SELECT probe_dst_prefix
        FROM ranked_prefixes
        WHERE rn <= 100
    ),
    uniq_nodes_list AS (
        SELECT
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        WHERE probe_dst_prefix IN (SELECT probe_dst_prefix FROM top_prefixes)
        GROUP BY probe_protocol, probe_src_addr, probe_dst_prefix
    ),
    y_nodes_list AS (
        SELECT
            groupArray(((probe_ttl, probe_dst_addr), reply_src_addr)) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        WHERE probe_dst_prefix IN (SELECT probe_dst_prefix FROM top_prefixes)
        GROUP BY probe_protocol, probe_src_addr, probe_dst_prefix
    ),
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__f8779caf_acf2_443a_9dde_deac1a8cb120
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 10 * lc.count_in_links
    ),
    far_addr_sets AS (
        SELECT near_addr, groupArray(far_addr) AS far_addrs
        FROM links__f8779caf_acf2_443a_9dde_deac1a8cb120
        GROUP BY near_addr
    ),
    expanded_uniq_nodes AS (
        SELECT
            probe_protocol,
            probe_src_addr,
            probe_dst_prefix,
            node.2 AS reply_src_addr
        FROM uniq_nodes_list
        ARRAY JOIN uniq_nodes AS node
    ),
    far_addr_comparison AS (
        SELECT f1.near_addr AS node
        FROM far_addr_sets f1
        INNER JOIN expanded_uniq_nodes un ON f1.near_addr = un.reply_src_addr
        WHERE arrayExists(x -> has(f1.far_addrs, x), f1.far_addrs)
    ),
    nodes_to_delete_final AS (
        SELECT node
        FROM nodes_to_delete_init
        INTERSECT
        SELECT node
        FROM far_addr_comparison
    ),
    marked_nodes AS (
        SELECT unnest(arrayAppend(arrayFill(x -> x, 1, probe_ttl), arrayMap(x -> x + 1, uniq_nodes))) AS marked_node
        FROM nodes_to_delete_final, uniq_nodes_list
        WHERE probe_dst_prefix = node
    ),
    marked_y_nodes AS (
        SELECT y_nodes
        FROM y_nodes_list
        WHERE arrayExists(x -> arrayElement(x, 2) IN (SELECT marked_node FROM marked_nodes), y_nodes)
    )
SELECT *
FROM marked_y_nodes;

WITH
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__5874a405_c34b_4d67_9f94_8e80a84ffa44
        -- WHERE {self.filters(subset)}
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__5874a405_c34b_4d67_9f94_8e80a84ffa44
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 10 * lc.count_in_links
    ),
    nodes_to_delete_init_ttl AS (
        SELECT 
            r.reply_src_addr, 
            r.probe_dst_prefix, 
            r.probe_dst_addr, 
            r.probe_ttl
        FROM 
            results__5874a405_c34b_4d67_9f94_8e80a84ffa44 r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    RankedResults AS (
        SELECT
            r.reply_src_addr,
            r.probe_dst_prefix,
            r.probe_dst_addr,
            r.probe_ttl,
            ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
        FROM 
            results__5874a405_c34b_4d67_9f94_8e80a84ffa44 r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    filter_ttl AS (
        SELECT
            probe_dst_prefix,
            probe_dst_addr,
            probe_ttl
        FROM 
            RankedResults
        WHERE rn = 1
    ),
    results_filtered AS (
        SELECT
            r.*
        FROM
            results__5874a405_c34b_4d67_9f94_8e80a84ffa44 r
        JOIN
            filter_ttl ft
        ON
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE 
            r.probe_ttl < ft.probe_ttl
    )
SELECT *
FROM results_filtered limit 1;

s

    uniq_nodes_list AS (
        SELECT
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    ),
    y_nodes_list AS (
        SELECT
            groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results__f8779caf_acf2_443a_9dde_deac1a8cb120
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    ),




WITH
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__ee6585e3_eaef_4781_9ab7_f62e366b21fc
        -- WHERE {self.filters(subset)}
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__ee6585e3_eaef_4781_9ab7_f62e366b21fc
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 2 * lc.count_in_links
    ),
    nodes_to_delete_init_ttl AS (
        SELECT 
            r.reply_src_addr, 
            r.probe_dst_prefix, 
            r.probe_dst_addr, 
            r.probe_ttl
        FROM 
            results__ee6585e3_eaef_4781_9ab7_f62e366b21fc r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    RankedResults AS (
        SELECT
            r.reply_src_addr,
            r.probe_dst_prefix,
            r.probe_dst_addr,
            r.probe_ttl,
            ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
        FROM 
            results__ee6585e3_eaef_4781_9ab7_f62e366b21fc r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    filter_ttl AS (
        SELECT
            probe_dst_prefix,
            probe_dst_addr,
            probe_ttl
        FROM 
            RankedResults
        WHERE rn = 1
    ),
    results_filtered AS (
        SELECT
            r.*
        FROM
            results__ee6585e3_eaef_4781_9ab7_f62e366b21fc r
        JOIN
            filter_ttl ft
        ON
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE 
            r.probe_ttl < ft.probe_ttl
    )
SELECT *
FROM results_filtered limit 1;

select probe_dst_addr, probe_ttl, reply_src_addr from results__ee6585e3_eaef_4781_9ab7_f62e366b21fc where probe_dst_addr='::ffff:104.225.1.5'

   ┌─reply_src_addr──────┬─probe_dst_prefix───┬─probe_dst_addr─────┬─probe_ttl─┬─reply_src_addr──────┐
1. │ ::ffff:154.54.5.101 │ ::ffff:104.225.1.0 │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101 │
2. │ ::ffff:154.54.5.101 │ ::ffff:104.225.1.0 │ ::ffff:104.225.1.6 │        13 │ ::ffff:154.54.5.101 │
3. │ ::ffff:154.54.1.193 │ ::ffff:104.225.1.0 │ ::ffff:104.225.1.7 │        13 │ ::ffff:154.54.1.193 │
4. │ ::ffff:154.54.5.101 │ ::ffff:104.225.1.0 │ ::ffff:104.225.1.8 │        13 │ ::ffff:154.54.5.101 │
5. │ ::ffff:154.54.5.101 │ ::ffff:104.225.1.0 │ ::ffff:104.225.1.9 │        13 │ ::ffff:154.54.5.101 │
   └─────────────────────┴────────────────────┴────────────────────┴───────────┴─────────────────────┘



   ┌─probe_dst_addr─────┬─probe_ttl─┬─reply_src_addr──────┐
1. │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101 │
   └────────────────────┴───────────┴─────────────────────┘
   ┌─probe_dst_addr─────┬─probe_ttl─┬─reply_src_addr──────┐
2. │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101 │
3. │ ::ffff:104.225.1.5 │        17 │ ::ffff:154.54.2.5   │
   └────────────────────┴───────────┴─────────────────────┘
    ┌─probe_dst_addr─────┬─probe_ttl─┬─reply_src_addr────────┐
 4. │ ::ffff:104.225.1.5 │         1 │ ::ffff:10.4.172.126   │
 5. │ ::ffff:104.225.1.5 │         1 │ ::ffff:10.4.172.126   │
 6. │ ::ffff:104.225.1.5 │         3 │ ::ffff:11.95.18.41    │
 7. │ ::ffff:104.225.1.5 │         4 │ ::ffff:10.102.11.125  │
 8. │ ::ffff:104.225.1.5 │         5 │ ::ffff:42.120.242.217 │
 9. │ ::ffff:104.225.1.5 │         7 │ ::ffff:58.61.162.161  │
10. │ ::ffff:104.225.1.5 │         8 │ ::ffff:119.147.222.45 │
11. │ ::ffff:104.225.1.5 │         9 │ ::ffff:202.97.93.81   │
12. │ ::ffff:104.225.1.5 │        10 │ ::ffff:202.97.66.229  │
13. │ ::ffff:104.225.1.5 │        11 │ ::ffff:202.97.27.238  │
14. │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101   │
15. │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101   │
16. │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101   │
17. │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101   │
18. │ ::ffff:104.225.1.5 │        13 │ ::ffff:154.54.5.101   │
19. │ ::ffff:104.225.1.5 │        14 │ ::ffff:154.54.40.145  │
20. │ ::ffff:104.225.1.5 │        14 │ ::ffff:154.54.40.145  │
21. │ ::ffff:104.225.1.5 │        15 │ ::ffff:154.54.45.161  │
22. │ ::ffff:104.225.1.5 │        16 │ ::ffff:154.54.26.54   │
    └────────────────────┴───────────┴───────────────────────┘


WITH
    node_counts AS (
        SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
        FROM results__5874a405_c34b_4d67_9f94_8e80a84ffa44
        -- WHERE {self.filters(subset)}
        GROUP BY reply_src_addr
    ),
    link_counts AS (
        SELECT near_addr AS node, COUNT(*) AS count_in_links
        FROM links__5874a405_c34b_4d67_9f94_8e80a84ffa44
        GROUP BY near_addr
    ),
    nodes_to_delete_init AS (
        SELECT nc.node
        FROM node_counts nc
        JOIN link_counts lc ON nc.node = lc.node
        WHERE nc.count_in_results > 100 * lc.count_in_links
    ),
    nodes_to_delete_init_ttl AS (
        SELECT 
            r.reply_src_addr, 
            r.probe_dst_prefix, 
            r.probe_dst_addr, 
            r.probe_ttl
        FROM 
            results__5874a405_c34b_4d67_9f94_8e80a84ffa44 r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    RankedResults AS (
        SELECT
            r.reply_src_addr,
            r.probe_dst_prefix,
            r.probe_dst_addr,
            r.probe_ttl,
            ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
        FROM 
            results__5874a405_c34b_4d67_9f94_8e80a84ffa44 r
        JOIN 
            nodes_to_delete_init ndl
        ON 
            r.reply_src_addr = ndl.node
    ),
    filter_ttl AS (
        SELECT
            probe_dst_prefix,
            probe_dst_addr,
            probe_ttl
        FROM 
            RankedResults
        WHERE rn = 1
    ),
    results_filtered AS (
        SELECT
            r.*, r.probe_dst_prefix
        FROM
            results__5874a405_c34b_4d67_9f94_8e80a84ffa44 r
        JOIN
            filter_ttl ft
        ON
            r.probe_dst_prefix = ft.probe_dst_prefix AND
            r.probe_dst_addr = ft.probe_dst_addr
        WHERE 
            r.probe_ttl < ft.probe_ttl
    )
SELECT 
    groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
    groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)) AS y_nodes,
    probe_protocol, probe_src_addr, probe_dst_prefix
FROM 
    results_filtered
GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    
    ,
    uniq_nodes_list AS (
        SELECT
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results_filtered
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    ),
    y_nodes_list AS (
        SELECT
            groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM results_filtered
        -- WHERE {self.filters(subset)}
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)
    )



df6fbd63_9146_4b99_a474_2ac377d6bfa8

WITH
            node_counts AS (
                SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
                FROM results__9888ba71_7e31_4248_ae80_f66c49a7b770
                -- WHERE {self.filters(subset)}
                GROUP BY reply_src_addr
            ),
            link_counts AS (
                SELECT near_addr AS node, COUNT(*) AS count_in_links
                FROM links__9888ba71_7e31_4248_ae80_f66c49a7b770
                GROUP BY near_addr
            ),
            nodes_to_delete_init AS (
                SELECT nc.node
                FROM node_counts nc
                JOIN link_counts lc ON nc.node = lc.node
                WHERE nc.count_in_results > 2 * lc.count_in_links
            ),
            nodes_to_delete_init_ttl AS (
                SELECT 
                    r.reply_src_addr, 
                    r.probe_dst_prefix, 
                    r.probe_dst_addr, 
                    r.probe_ttl
                FROM 
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770 r
                JOIN 
                    nodes_to_delete_init ndl
                ON 
                    r.reply_src_addr = ndl.node
            ),
            RankedResults AS (
                SELECT
                    r.reply_src_addr,
                    r.probe_dst_prefix,
                    r.probe_dst_addr,
                    r.probe_ttl,
                    ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
                FROM 
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770 r
                JOIN 
                    nodes_to_delete_init ndl
                ON 
                    r.reply_src_addr = ndl.node
            ),
            filter_ttl AS (
                SELECT
                    probe_dst_prefix,
                    probe_dst_addr,
                    probe_ttl
                FROM 
                    RankedResults
                WHERE rn = 1
            ),
            results_filtered AS (
                SELECT
                    r.*, r.probe_dst_prefix, ft.probe_ttl AS filtered_ttl
                FROM
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770 r
                JOIN
                    filter_ttl ft
                ON
                    r.probe_dst_prefix = ft.probe_dst_prefix AND
                    r.probe_dst_addr = ft.probe_dst_addr
                WHERE
                    r.probe_ttl < ft.probe_ttl -- 只选出满足此条件的匹配行
                
                UNION ALL

                SELECT
                    r.*, r.probe_dst_prefix, 33 AS filtered_ttl
                FROM
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770 r
                ANY LEFT JOIN
                    filter_ttl ft
                ON
                    r.probe_dst_prefix = ft.probe_dst_prefix AND
                    r.probe_dst_addr = ft.probe_dst_addr
                WHERE
                    ft.probe_dst_prefix = '::'   
            )
        SELECT 
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)),
            groupArray((probe_ttl, reply_src_addr)) AS nodes,
            arrayMap(t -> (t.1, countEqual(nodes, t)), uniq_nodes) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM 
            results_filtered
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)

WITH
            node_counts AS (
                SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
                FROM results__9888ba71_7e31_4248_ae80_f66c49a7b770
                -- WHERE {self.filters(subset)}
                GROUP BY reply_src_addr
            ),
            link_counts AS (
                SELECT near_addr AS node, COUNT(*) AS count_in_links
                FROM links__9888ba71_7e31_4248_ae80_f66c49a7b770
                GROUP BY near_addr
            ),
            nodes_to_delete_init AS (
                SELECT nc.node
                FROM node_counts nc
                JOIN link_counts lc ON nc.node = lc.node
                WHERE nc.count_in_results > 2 * lc.count_in_links
            ),
            nodes_to_delete_init_ttl AS (
                SELECT 
                    r.reply_src_addr, 
                    r.probe_dst_prefix, 
                    r.probe_dst_addr, 
                    r.probe_ttl
                FROM 
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770 r
                JOIN 
                    nodes_to_delete_init ndl
                ON 
                    r.reply_src_addr = ndl.node
            ),
            RankedResults AS (
                SELECT
                    r.reply_src_addr,
                    r.probe_dst_prefix,
                    r.probe_dst_addr,
                    r.probe_ttl,
                    ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
                FROM 
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770 r
                JOIN 
                    nodes_to_delete_init ndl
                ON 
                    r.reply_src_addr = ndl.node
            ),
            MaxTTL AS (
                SELECT
                    probe_dst_prefix,
                    probe_dst_addr,
                    MAX(probe_ttl) AS max_ttl
                FROM 
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770
                GROUP BY 
                    probe_dst_prefix,
                    probe_dst_addr
            ),
            filter_ttl AS (
                SELECT
                    rr.reply_src_addr,
                    rr.probe_dst_prefix,
                    rr.probe_dst_addr,
                    CASE 
                        WHEN rr.is_matched THEN
                            CASE WHEN rr.rn = 1 THEN rr.probe_ttl ELSE NULL END
                        ELSE
                            mt.max_ttl
                    END AS final_ttl
                FROM 
                    RankedResults rr
                LEFT JOIN
                    MaxTTL mt
                ON
                    rr.probe_dst_prefix = mt.probe_dst_prefix AND
                    rr.probe_dst_addr = mt.probe_dst_addr
            ),
            results_filtered AS (
                SELECT
                    r.*, r.probe_dst_prefix
                FROM
                    results__9888ba71_7e31_4248_ae80_f66c49a7b770 r
                JOIN
                    filter_ttl ft
                ON
                    r.probe_dst_prefix = ft.probe_dst_prefix AND
                    r.probe_dst_addr = ft.probe_dst_addr
                WHERE 
                    r.probe_ttl < ft.final_ttl
            )
        SELECT 
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)),
            groupArray((probe_ttl, reply_src_addr)) AS nodes,
            arrayMap(t -> (t.1, countEqual(nodes, t)), uniq_nodes) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM 
            results_filtered
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)


   ┌─probe_dst_prefix─────┬─probe_dst_addr───────┬─probe_ttl─┐
1. │ ::ffff:125.217.240.0 │ ::ffff:125.217.240.1 │         9 │
2. │ ::ffff:125.217.240.0 │ ::ffff:125.217.240.2 │         9 │
3. │ ::ffff:125.217.240.0 │ ::ffff:125.217.240.4 │         9 │
4. │ ::ffff:202.116.54.0  │ ::ffff:202.116.54.0  │         9 │
5. │ ::ffff:202.116.54.0  │ ::ffff:202.116.54.3  │         9 │
6. │ ::ffff:202.116.54.0  │ ::ffff:202.116.54.5  │         9 │
   └──────────────────────┴──────────────────────┴───────────┘
    ┌─probe_dst_prefix─────┬─probe_dst_addr───────┬─probe_ttl─┐
 7. │ ::ffff:125.217.240.0 │ ::ffff:125.217.240.0 │         9 │
 8. │ ::ffff:125.217.240.0 │ ::ffff:125.217.240.3 │         9 │
 9. │ ::ffff:125.217.240.0 │ ::ffff:125.217.240.5 │         9 │
10. │ ::ffff:202.116.54.0  │ ::ffff:202.116.54.1  │         9 │
11. │ ::ffff:202.116.54.0  │ ::ffff:202.116.54.2  │         9 │
12. │ ::ffff:202.116.54.0  │ ::ffff:202.116.54.4  │         9 │
    └──────────────────────┴──────────────────────┴───────────┘


# 得到筛选后的results的正确SQL
WITH
            node_counts AS (
                SELECT reply_src_addr AS node, COUNT(*) AS count_in_results
                FROM results__9d62283d_8bf9_4428_8605_fc64d6f77f06
                -- WHERE {self.filters(subset)}
                GROUP BY reply_src_addr
            ),
            link_counts AS (
                SELECT near_addr AS node, COUNT(*) AS count_in_links
                FROM links__9d62283d_8bf9_4428_8605_fc64d6f77f06
                GROUP BY near_addr
            ),
            nodes_to_delete_init AS (
                SELECT nc.node
                FROM node_counts nc
                JOIN link_counts lc ON nc.node = lc.node
                WHERE nc.count_in_results > 2 * lc.count_in_links
            ),
            nodes_to_delete_init_ttl AS (
                SELECT 
                    r.reply_src_addr, 
                    r.probe_dst_prefix, 
                    r.probe_dst_addr, 
                    r.probe_ttl
                FROM 
                    results__9d62283d_8bf9_4428_8605_fc64d6f77f06 r
                JOIN 
                    nodes_to_delete_init ndl
                ON 
                    r.reply_src_addr = ndl.node
            ),
            RankedResults AS (
                SELECT
                    r.reply_src_addr,
                    r.probe_dst_prefix,
                    r.probe_dst_addr,
                    r.probe_ttl,
                    ROW_NUMBER() OVER (PARTITION BY r.probe_dst_prefix, r.probe_dst_addr ORDER BY r.probe_ttl ASC) as rn
                FROM 
                    results__9d62283d_8bf9_4428_8605_fc64d6f77f06 r
                JOIN 
                    nodes_to_delete_init ndl
                ON 
                    r.reply_src_addr = ndl.node
            ),
            filter_ttl AS (
                SELECT
                    probe_dst_prefix,
                    probe_dst_addr,
                    probe_ttl
                FROM 
                    RankedResults
                WHERE rn = 1
            ),
            results_filtered AS (
                SELECT
                    r.*, r.probe_dst_prefix, ft.probe_ttl AS filtered_ttl
                FROM
                    results__9d62283d_8bf9_4428_8605_fc64d6f77f06 r
                JOIN
                    filter_ttl ft
                ON
                    r.probe_dst_prefix = ft.probe_dst_prefix AND
                    r.probe_dst_addr = ft.probe_dst_addr
                WHERE
                    r.probe_ttl < ft.probe_ttl -- 只选出满足此条件的匹配行
                
                UNION ALL

                SELECT
                    r.*, r.probe_dst_prefix, 33 AS filtered_ttl
                FROM
                    results__9d62283d_8bf9_4428_8605_fc64d6f77f06 r
                ANY LEFT JOIN
                    filter_ttl ft
                ON
                    r.probe_dst_prefix = ft.probe_dst_prefix AND
                    r.probe_dst_addr = ft.probe_dst_addr
                WHERE
                    ft.probe_dst_prefix = '::'   
            )
        SELECT 
            groupUniqArray((probe_ttl, reply_src_addr)) AS uniq_nodes,
            groupArray(((probe_ttl, probe_dst_prefix), reply_src_addr)),
            groupArray((probe_ttl, reply_src_addr)) AS nodes,
            arrayMap(t -> (t.1, countEqual(nodes, t)), uniq_nodes) AS y_nodes,
            probe_protocol, probe_src_addr, probe_dst_prefix
        FROM 
            results_filtered
        GROUP BY (probe_protocol, probe_src_addr, probe_dst_prefix)



[2024-04-20 20:09:35.601] [info] packets_received=9035675 packets_received_invalid=18 icmp_distinct_incl_dest=33245 icmp_distinct_excl_dest=10469
[2024-04-20 20:09:35.601] [info] pcap_received=9035685 pcap_dropped=0 pcap_interface_dropped=0
**********************************************************************************
Round: 5 and Measurement_id: 9d62283d-8bf9-4428-8605-fc64d6f77f06
**********************************************************************************
Traceback (most recent call last):
  File "/usr/local/lib/python3.10/dist-packages/httpx/_transports/default.py", line 66, in map_httpcore_exceptions
    yield
  File "/usr/local/lib/python3.10/dist-packages/httpx/_transports/default.py", line 110, in __iter__
    for part in self._httpcore_stream:
  File "/usr/local/lib/python3.10/dist-packages/httpcore/_sync/connection_pool.py", line 367, in __iter__
    raise exc from None
  File "/usr/local/lib/python3.10/dist-packages/httpcore/_sync/connection_pool.py", line 363, in __iter__
    for part in self._stream:
  File "/usr/local/lib/python3.10/dist-packages/httpcore/_sync/http11.py", line 349, in __iter__
    raise exc
  File "/usr/local/lib/python3.10/dist-packages/httpcore/_sync/http11.py", line 341, in __iter__
    for chunk in self._connection._receive_response_body(**kwargs):
  File "/usr/local/lib/python3.10/dist-packages/httpcore/_sync/http11.py", line 210, in _receive_response_body
    event = self._receive_event(timeout=timeout)
  File "/usr/local/lib/python3.10/dist-packages/httpcore/_sync/http11.py", line 220, in _receive_event
    with map_exceptions({h11.RemoteProtocolError: RemoteProtocolError}):
  File "/usr/lib/python3.10/contextlib.py", line 153, in __exit__
    self.gen.throw(typ, value, traceback)
  File "/usr/local/lib/python3.10/dist-packages/httpcore/_exceptions.py", line 14, in map_exceptions
    raise to_exc(exc) from exc
httpcore.RemoteProtocolError: peer closed connection without sending complete message body (incomplete chunked read)

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "/root/REVERSE-MDA/diamond-miner-main/diamond_miner/examples/diamond-miner-filter-node-clickhouse.py", line 102, in <module>
    result = Query_results_filtered().execute(client, measurement_id)
  File "/usr/local/lib/python3.10/dist-packages/diamond_miner/queries/query.py", line 98, in execute
    rows += client.json(statement, data=data, settings=settings)
  File "/usr/local/lib/python3.10/dist-packages/pych_client/client.py", line 150, in json
    result = self.text(query, params, data, settings)
  File "/usr/local/lib/python3.10/dist-packages/pych_client/client.py", line 117, in text
    return self.execute(query, params, data, settings).text.strip()
  File "/usr/local/lib/python3.10/dist-packages/pych_client/client.py", line 68, in execute
    r = self.client.post(
  File "/usr/local/lib/python3.10/dist-packages/httpx/_client.py", line 1132, in post
    return self.request(
  File "/usr/local/lib/python3.10/dist-packages/httpx/_client.py", line 814, in request
    return self.send(request, auth=auth, follow_redirects=follow_redirects)
  File "/usr/local/lib/python3.10/dist-packages/httpx/_client.py", line 915, in send
    raise exc
  File "/usr/local/lib/python3.10/dist-packages/httpx/_client.py", line 909, in send
    response.read()
  File "/usr/local/lib/python3.10/dist-packages/httpx/_models.py", line 810, in read
    self._content = b"".join(self.iter_bytes())
  File "/usr/local/lib/python3.10/dist-packages/httpx/_models.py", line 828, in iter_bytes
    for raw_bytes in self.iter_raw():
  File "/usr/local/lib/python3.10/dist-packages/httpx/_models.py", line 886, in iter_raw
    for raw_stream_bytes in self.stream:
  File "/usr/local/lib/python3.10/dist-packages/httpx/_client.py", line 123, in __iter__
    for chunk in self._stream:
  File "/usr/local/lib/python3.10/dist-packages/httpx/_transports/default.py", line 109, in __iter__
    with map_httpcore_exceptions():
  File "/usr/lib/python3.10/contextlib.py", line 153, in __exit__
    self.gen.throw(typ, value, traceback)
  File "/usr/local/lib/python3.10/dist-packages/httpx/_transports/default.py", line 83, in map_httpcore_exceptions
    raise mapped_exc(message) from exc
httpx.RemoteProtocolError: peer closed connection without sending complete message body (incomplete chunked read)
root@iZwz9hyfiovaqb3vgrbdliZ:~/REVERSE-MDA/diamond-miner-main/diamond_miner/examples# ls /var/log/clickhouse-server/