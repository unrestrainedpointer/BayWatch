import geoip2.database
import pandas as pd

# 读取无列名的 CSV 文件
input_file = "/root/NSDI_24/CloudFlare.csv"
output_file = "/root/NSDI_24/CloudFlare_with_asn_org.csv"

# 读取 CSV 文件并指定列名
columns = ['near_ttl', 'near_addr', 'far_addr']
df = pd.read_csv(input_file, names=columns)

# 打开 GeoLite2 ASN 数据库
asn_reader = geoip2.database.Reader('/root/NSDI_24/rgmda/examples/GeoLite2-ASN.mmdb')

# 检查 autonomous_system_organization 是否包含 "Alibaba Cloud" 或 "Alibaba"
def is_aliyun(ip):
    try:
        response = asn_reader.asn(ip)
        # 检查 organization 字符串中是否包含 "Alibaba Cloud" 或 "Alibaba"
        if "CloudFlare" in response.autonomous_system_organization:
            return True
    except geoip2.errors.AddressNotFoundError:
        return False
    return False

# 获取 ASN 组织名称
def get_asn_organization(ip):
    try:
        response = asn_reader.asn(ip)
        return response.autonomous_system_organization
    except geoip2.errors.AddressNotFoundError:
        return "Unknown"

# 筛选出 reply_src_addr 属于阿里云的行
df_aliyun = df[df['near_addr'].apply(is_aliyun)]

# 为筛选出的阿里云节点添加 ASN 组织名称
df_aliyun['asn_organization'] = df_aliyun['near_addr'].apply(get_asn_organization)

# 保存结果到新文件
df_aliyun.to_csv(output_file, index=False)

# 关闭 ASN 数据库
asn_reader.close()

print(f"筛选后的阿里云节点及其 ASN 组织名称已保存到 {output_file}")