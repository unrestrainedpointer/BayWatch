from dataclasses import asdict, dataclass

from diamond_miner.defaults import UNIVERSE_SUBSET
from get_motivation_invalid_prefixes import GetPrefixesWithAmplification, GetPrefixesWithLoops
from diamond_miner.queries.query import ResultsQuery, prefixes_table, results_table
from diamond_miner.typing import IPNetwork


@dataclass(frozen=True)
class InsertPrefixes(ResultsQuery):
    """
    Insert the results of the `GetPrefixesWithAmplification` and `GetPrefixesWithLoops` queries into the prefixes table.
    """

    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        amplification_query = GetPrefixesWithAmplification(**asdict(self)).statement(
            measurement_id, subset
        )
        loops_query = GetPrefixesWithLoops(**asdict(self)).statement(
            measurement_id, subset
        )
        return f"""
        INSERT INTO {prefixes_table(measurement_id)}
        SELECT
            prefixes.probe_dst_prefix,
            amplification.has_amplification,
            loops.has_loops
        FROM (
            SELECT DISTINCT probe_dst_prefix
            FROM {results_table(measurement_id)}
            -- WHERE {self.filters(subset)}
        ) AS prefixes
        FULL OUTER JOIN ({amplification_query}) AS amplification
        ON  prefixes.probe_dst_prefix = amplification.probe_dst_prefix
        FULL OUTER JOIN ({loops_query}) AS loops
        ON  prefixes.probe_dst_prefix = loops.probe_dst_prefix
        """