from collections.abc import Iterable, Iterator
from ipaddress import IPv6Address

from pych_client import ClickHouseClient

from diamond_miner.defaults import (
    DEFAULT_PREFIX_SIZE_V4,
    DEFAULT_PREFIX_SIZE_V6,
    DEFAULT_PROBE_DST_PORT,
    DEFAULT_PROBE_SRC_PORT,
    PROTOCOLS,
    UNIVERSE_SUBSET,
)
from diamond_miner.logger import logger
from utils.mappers_lb_single_address import SequentialFlowMapper_LB
from diamond_miner.queries import GetProbesDiff
from diamond_miner.typing import IPNetwork, Probe
import random

def probe_generator_from_database_lb(
    client: ClickHouseClient,
    measurement_id: str,
    round_: int,
    *,
    mapper_v4 = SequentialFlowMapper_LB(DEFAULT_PREFIX_SIZE_V4),
    mapper_v6 = SequentialFlowMapper_LB(DEFAULT_PREFIX_SIZE_V6),
    probe_src_port: int = DEFAULT_PROBE_SRC_PORT,
    probe_dst_port: int = DEFAULT_PROBE_DST_PORT,
    probe_ttl_geq: int | None = None,
    probe_ttl_leq: int | None = None,
    subsets: Iterable[IPNetwork] = (UNIVERSE_SUBSET,),
) -> Iterator[Probe]:
    rows = GetProbesDiff(
        round_eq=round_, probe_ttl_geq=probe_ttl_geq, probe_ttl_leq=probe_ttl_leq
    ).execute_iter(client, measurement_id, subsets=subsets)
    for row in rows:
        dst_prefix_int = int(IPv6Address(row["probe_dst_prefix"]))
        mapper = (
            mapper_v4 if row["probe_dst_prefix"].startswith("::ffff:") else mapper_v6
        )
        protocol_str = PROTOCOLS[row["probe_protocol"]]

        for ttl, total_probes, already_sent in row["probes_per_ttl"]:
            for flow_id in range(already_sent, total_probes):
                addr_offset, src_port_offset = mapper.offset(flow_id, dst_prefix_int)
                dst_addr = dst_prefix_int + src_port_offset
                src_port = probe_src_port + addr_offset

                # 这里你可以自定义目标端口号和DSCP字段
                dst_port = probe_dst_port + src_port_offset  # 可以按需求调整目标端口号
                dscp = random.randint(1, 2**6 - 1)

                # 生成2位的ECN字段，这里假设为0
                ecn = 0

                # 将DSCP和ECN拼接成8位的TOS
                tos = (dscp << 2) | ecn

                if src_port > (2**16 - 1):
                    logger.warning("Src port overflow for %s", row)
                    break
                if dst_port > (2**16 - 1):
                    logger.warning("Dst port overflow for %s", row)
                    break

                # 修改生成的探测包，包含新的目标端口号和DSCP字段
                yield dst_addr, src_port, dst_port, ttl, protocol_str, dst_prefix_int