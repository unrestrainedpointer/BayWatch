from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import LinksQuery, links_table
from diamond_miner.typing import IPNetwork

@dataclass(frozen=True)
class Query_links(LinksQuery):
    round_eq: int | None = None  # 这是你可以指定的参数

    def statement(self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET) -> str:
        return f'''
        SELECT
            probe_dst_prefix,
            -- 取出升序后的 near_ttl 列表
            arrayMap(p -> p.1,
                    arraySort(
                        groupArray((near_ttl, links))
                    )
            ) AS link_ttls,
            -- 取出与之对应的 links 列表
            arrayMap(p -> p.2,
                    arraySort(
                        groupArray((near_ttl, links))
                    )
            ) AS links_array
        FROM
        (
            SELECT
                probe_dst_prefix,
                near_ttl,
                countDistinct(near_addr, far_addr) AS links
            FROM {links_table(measurement_id)}
            WHERE near_addr    != far_addr
            AND far_addr     != probe_dst_addr
            AND near_addr    != probe_dst_addr
            GROUP BY
                probe_dst_prefix,
                near_ttl
        )
        GROUP BY
            probe_dst_prefix;
    '''