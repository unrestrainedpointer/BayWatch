from dataclasses import dataclass

from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.fragments import ip_in
from diamond_miner.queries.query import ResultsQuery, prefixes_table, results_table
from diamond_miner.typing import IPNetwork


@dataclass(frozen=True)
class CorrectRound(ResultsQuery):
    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        
        return f"""
        ALTER TABLE {results_table(measurement_id)}
        UPDATE round={self.round_c} where round={self.round_o}
        """