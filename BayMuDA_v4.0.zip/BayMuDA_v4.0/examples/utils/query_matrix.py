from dataclasses import dataclass
from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.query import LinksQuery, links_table, results_table
from diamond_miner.typing import IPNetwork

@dataclass(frozen=True)
class Query_Matrix(LinksQuery):
    def statement(self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET) -> str:
        return f'''
        WITH
           near_addresses AS (
               SELECT 
                   probe_dst_prefix,
                   near_ttl,
                   near_addr,
                   row_number() OVER (PARTITION BY probe_dst_prefix, near_ttl ORDER BY near_addr) AS near_id
               FROM 
                   {links_table(measurement_id)}
               -- WHERE near_addr != '::' AND near_addr != ''
               GROUP BY 
                   probe_dst_prefix, near_ttl, near_addr
           ),
           far_addresses AS (
               SELECT 
                   probe_dst_prefix,
                   far_ttl,
                   far_addr,
                   row_number() OVER (PARTITION BY probe_dst_prefix, far_ttl ORDER BY far_addr) AS far_id
               FROM 
                   {links_table(measurement_id)}
               -- WHERE far_addr != '::' AND far_addr != ''
               GROUP BY 
                   probe_dst_prefix, far_ttl, far_addr
           ),
           mapped_links AS (
               SELECT 
                   l.probe_dst_prefix AS probe_dst_prefix,
                   l.probe_dst_addr AS probe_dst_addr,
                   l.near_ttl AS near_ttl,
                   l.far_ttl AS far_ttl,
                   l.near_addr AS near_addr,
                   l.far_addr AS far_addr,
                   na.near_id AS near_id,
                   fa.far_id AS far_id
               FROM 
                   {links_table(measurement_id)} l
               LEFT JOIN 
                   near_addresses na 
                   ON l.probe_dst_prefix = na.probe_dst_prefix 
                   AND l.near_ttl = na.near_ttl 
                   AND l.near_addr = na.near_addr
               LEFT JOIN 
                   far_addresses fa 
                   ON l.probe_dst_prefix = fa.probe_dst_prefix 
                   AND l.far_ttl = fa.far_ttl 
                   AND l.far_addr = fa.far_addr
           ),
           aggregated_links AS (
               SELECT 
                   probe_dst_prefix,
                   near_ttl,
                   (near_id, far_id) AS id_pair,
                   COUNT(*) AS id_pair_count
               FROM 
                   mapped_links
               GROUP BY 
                   probe_dst_prefix, near_ttl, near_id, far_id
           ),
           ttl_pairs_aggregated AS (
               SELECT 
                   probe_dst_prefix,
                   near_ttl,
                   groupArray((id_pair, id_pair_count)) AS id_pairs
               FROM 
                   aggregated_links
               GROUP BY 
                   probe_dst_prefix, near_ttl
           )
       SELECT 
           probe_dst_prefix,
           groupArray((near_ttl, id_pairs)) AS ttl_pairs
       FROM 
           ttl_pairs_aggregated
       GROUP BY
           probe_dst_prefix
       ORDER BY 
           probe_dst_prefix;
    '''