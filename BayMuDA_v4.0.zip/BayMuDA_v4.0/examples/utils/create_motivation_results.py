from dataclasses import dataclass

from diamond_miner.defaults import (
    DEFAULT_PREFIX_LEN_V4,
    DEFAULT_PREFIX_LEN_V6,
    UNIVERSE_SUBSET,
)
from diamond_miner.queries.fragments import cut_ipv6, date_time
from diamond_miner.queries.query import Query, StoragePolicy, results_table
from diamond_miner.typing import IPNetwork


@dataclass(frozen=True)
class CreateMotivationResultsTable(Query):
    """
    Create the table used to store the measurement results from the prober.

    Examples:
        >>> from diamond_miner.test import client
        >>> from diamond_miner.queries import CreateResultsTable
        >>> CreateResultsTable().execute(client, "test")
        []
    """

    SORTING_KEY = "probe_dst_prefix, probe_dst_addr, probe_ttl"
    "Columns by which the data is ordered."

    prefix_len_v4: int = DEFAULT_PREFIX_LEN_V4
    "The prefix length used to compute the IPv4 prefix of an IP address."

    prefix_len_v6: int = DEFAULT_PREFIX_LEN_V6
    "The prefix length used to compute the IPv6 prefix of an IP address."

    storage_policy: StoragePolicy = StoragePolicy()
    "ClickHouse storage policy to use."

    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        return f"""
        CREATE TABLE IF NOT EXISTS {results_table(measurement_id)}
        (
            -- Since we do not order by capture timestamp, this column compresses badly.
            -- To reduce its size, caracal outputs the timestamp with a one-second resolution (instead of one microsecond).
            -- This is sufficient to know if two replies were received close in time
            -- and avoid the inference of false links over many hours.
            probe_dst_addr         String,
            probe_ttl              UInt8,
            reply_src_addr         String,
            round                  UInt8,
            probe_dst_prefix       String
        )
        ENGINE MergeTree
        ORDER BY ({self.SORTING_KEY})
        TTL {date_time(self.storage_policy.archive_on)} TO VOLUME '{self.storage_policy.archive_to}'
        SETTINGS storage_policy = '{self.storage_policy.name}'
        """