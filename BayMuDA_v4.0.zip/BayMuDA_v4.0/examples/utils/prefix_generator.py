import ipaddress
from clickhouse_driver import Client
# 保留的IP地址段
RESERVED_RANGES = [
    "0.0.0.0/8",       # 当前网络（仅限于软件使用）
    "10.0.0.0/8",      # 私有网络
    "100.64.0.0/10",   # 用于运营商级NAT
    "127.0.0.0/8",     # 回送地址
    "169.254.0.0/16",  # 链接本地地址
    "172.16.0.0/12",   # 私有网络
    "192.0.0.0/24",    # IETF协议分配
    "192.0.2.0/24",    # 文档（测试）地址
    "192.168.0.0/16",  # 私有网络
    "198.18.0.0/15",   # 用于网络基准测试的网络
    "198.51.100.0/24", # 文档（测试）地址
    "203.0.113.0/24",  # 文档（测试）地址
    "224.0.0.0/4",     # 多播地址
    "240.0.0.0/4",     # 未来用途保留
    "255.255.255.255/32"  # 广播
]

def clickhouse_generator():
    credentials_0 = {
        "host": "localhost",  # 通常，ClickHouse HTTP 接口监听在 localhost 的 8123 端口
        "port": "9000",       # 默认端口为 8123，这里显式指定
        "user": "default",    # 默认用户
        "password": "",       # 对应的密码，这里为空
        "database": "default" # 默认数据库
    }
    client = Client(**credentials_0)

    # 将保留的地址范围转换为IPv4Network对象
    reserved_networks = [ipaddress.ip_network(addr) for addr in RESERVED_RANGES]

    # 准备插入的数据列表
    non_reserved_prefixes = []

    # 生成所有的 /24 网络前缀并过滤保留地址
    for first in range(256):
        for second in range(256):
            for third in range(256):
                network = ipaddress.ip_network(f'{first}.{second}.{third}.0/24')
                if not any(network.overlaps(reserved) for reserved in reserved_networks):
                    non_reserved_prefixes.append(network.with_prefixlen.split('/')[0])

    print(f"Inserting!")
    # 批量插入数据到 ClickHouse
    client.execute(
        'INSERT INTO ipv4_prefixes (prefix) VALUES',
        [(prefix,) for prefix in non_reserved_prefixes]
    )

    print("Completed inserting non-reserved IPv4 /24 prefixes into ClickHouse.")

clickhouse_generator()

'''
# 将保留的地址范围转换为IPv4Network对象
reserved_networks = [ipaddress.ip_network(addr) for addr in RESERVED_RANGES]

# 打开文件进行写入
with open('non_reserved_ipv4_prefixes.txt', 'w') as file:
    # 遍历所有可能的/24网络
    for first in range(256):
        for second in range(256):
            for third in range(256):
                network = ipaddress.ip_network(f'{first}.{second}.{third}.0/24')
                # 检查当前网络是否在任何保留网络中
                if not any(network.overlaps(reserved) for reserved in reserved_networks):
                    # 写入网络的基地址
                    file.write(f'{first}.{second}.{third}.0\n')

print("Completed writing non-reserved IPv4 /24 prefixes to file.")
'''