from clickhouse_driver import Client
import copy
# from diamond_miner.generators import probe_generator_parallel
from utils.parallel_lb import probe_generator_parallel
# from diamond_miner.insert import insert_probe_counts
from utils.insert_fast import insert_probe_counts
from diamond_miner.queries import InsertLinks, InsertPrefixes, InsertResults
from diamond_miner.queries.query import probes_table
import gc
import logging
import multiprocessing
from multiprocessing import Pool, Value, Lock
import os
import pandas as pd
from pathlib import Path
from pych_client import ClickHouseClient
import time
from utils.algorithm import rgmda_statistical_gurantee
from utils.configure import credentials, prefixes, logger, ALERT_LEVEL, process_num
from utils.create_tables_mine import CreateTables
from deletet import drop, string
from utils.get_cumulative_probe import Query_probes
from utils.get_links import GetLinksFromResults
from utils.get_nodes import GetNodesFromResults
from utils.query_finished_ttl import Query_finished_ttl
from utils.query_matrix import Query_Matrix
from utils.select_parameter import Query_parameter
from utils_rgmda import correct_round, send_probes

measurement_id = '878be341-9c88-44c7-b5a1-95c7713194f3'
results_filepath_last_round = Path('/root/NSDI_24/rgmda/examples/output/results_2.csv')
with ClickHouseClient(**credentials) as client:
    logger.alert("Insert to Clickhouse!")
    InsertResults().execute(client, measurement_id, data=results_filepath_last_round.read_bytes())
    InsertPrefixes().execute(client, measurement_id)
    InsertLinks().execute(client, measurement_id)