import logging
from uuid import uuid4

# Configuration
credentials = {
    "base_url": "http://localhost:8123",
    "database": "default",
    "username": "default",
    "password": "",
}

measurement_id, start_number, prefix_num, prefixes = str(uuid4()), 0, 500, []
# measurement_id = '067095a8-2a81-406d-b82d-4bd839bc4e46'
# ICMP traceroute towards every /24 in 1.0.0.0/22 starting with 6 flows per prefix between TTLs 2-32
'''
prefixes = [
    ("104.206.45.0/24", "udp", range(10, 12), 50000),
    ("111.233.225.0/24", "udp", range(10, 12), 50000),
    ("20.75.68.0/24", "udp", range(15, 18), 50000),]
'''
with open('/root/NSDI_24/prefix.txt', 'r', encoding='utf-8') as f:
    i = 0
    prefix = f.readline().strip()
    while prefix:
        elem = prefix.split('\t')
        if '.0' not in prefix or i < start_number:
            i += 1
            prefix = f.readline()
            continue
        prefixes.append((elem[0][7:] + '/24', 'udp', range(int(elem[1]), int(elem[2])), 1000))
        i += 1
        if i == prefix_num:
            break
        prefix = f.readline().strip()
    f.close()

ALERT_LEVEL = 60
logging.addLevelName(ALERT_LEVEL, "ALERT")

# 定义一个日志记录函数
def alert(self, message, *args, **kws):
    if self.isEnabledFor(ALERT_LEVEL):
        self._log(ALERT_LEVEL, message, args, **kws)

# 将新的日志级别方法添加到 logging.Logger 类
logging.Logger.alert = alert

# 设置日志配置
logging.basicConfig(level=ALERT_LEVEL)

# 使用新定义的日志级别
logger = logging.getLogger(__name__)