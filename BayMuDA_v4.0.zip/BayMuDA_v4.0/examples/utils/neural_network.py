from collections import Counter
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from math import ceil, log

class TopologyNeuralNetwork(nn.Module):
    def __init__(self, initial_distribution, initial_matrix, num_states_per_layer, ttl_inital=0):
        super(TopologyNeuralNetwork, self).__init__()
        self.num_layers = len(num_states_per_layer)
        self.layers = nn.ModuleList()
        # self.initial_distribution = initial_distribution
        self.initial_matrix = [torch.tensor(matrix, dtype=torch.float32) for matrix in initial_matrix]
        self.ttl_inital = ttl_inital
        self.num_observations = num_states_per_layer[-1]
        self.num_states_per_layer = num_states_per_layer

        for i in range(self.num_layers - 2):
            layer = nn.Linear(num_states_per_layer[i], num_states_per_layer[i + 1], bias=False)
            self.layers.append(layer)
        self.to_observations = nn.Linear(num_states_per_layer[-2], num_states_per_layer[-1], bias=False)
        sub = self.initial_matrix[0].shape[0] - len(initial_distribution)
        for i in range(0, sub):
            initial_distribution.append(0)
        self.initial_distribution = torch.tensor(initial_distribution, dtype=torch.float32)
        self._initialize_transition_matrices()

    def forward(self):
        x = torch.softmax(self.initial_distribution, dim=0).unsqueeze(0)
        layer_index = 0
        for layer in self.layers:
            try:
                x = torch.softmax(layer(x), dim=1)
                layer_index += 1
            except RuntimeError as e:
                print(f"Error computing x: {e}")
                print(f"x: {x.shape}")
                print(f"self.initial_matrix: {self.initial_matrix[0]}")
                print(f"len(model.layers): {len(self.layers)}")
                for layer in self.layers:
                    print(layer.weight.shape)
                print(f"Bug layer: {layer_index}")
        try:
            x = self.to_observations(x)
        except RuntimeError as e:
                print(f"Error computing x: {e}")
                print(f"x: {x.shape}")
                print(f"len(model.layers): {len(self.layers)}")
                for layer in self.layers:
                    print(layer.weight.shape)
                print(f"Bug layer: last one")
        observations = torch.softmax(x, dim=1)
        return observations
    
    def get_distributions(self):
        initial_distribution = torch.softmax(self.initial_distribution, dim=0).tolist()
        
        layer_distributions = []
        x = torch.softmax(self.initial_distribution, dim=0).unsqueeze(0)
        for layer in self.layers:
            x = torch.softmax(layer(x), dim=1)
            layer_distributions.append(x.squeeze(0).tolist())
        layer_distributions.insert(0, initial_distribution)
        return layer_distributions
    
    def get_transition_matrices(self):
        transition_matrices = []
        for layer in self.layers:
            weight = layer.weight.data.T
            transition_matrices.append(softmax_weight(weight))
        weight = self.to_observations.weight.data.T
        transition_matrices.append(softmax_weight(weight))
        return transition_matrices

    def _initialize_transition_matrices(self):
        index_copy = 0
        for index in range(len(self.layers)):
            current_matrix = np.array(self.initial_matrix[index]).T
            self.layers[index].weight.data = torch.tensor(current_matrix, dtype=torch.float32)
            index_copy += 1
        self.to_observations.weight.data = torch.tensor(np.array(self.initial_matrix[index_copy]).T, dtype=torch.float32)

def softmax_weight(weight):
    softmax_w = []
    for distribution in weight:
        distribution = torch.softmax(distribution, dim=0)
        distribution = distribution.detach().numpy().tolist()
        softmax_w.append(distribution)
    return softmax_w

def train(model, observations, num_epochs=100, learning_rate=0.1):
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = nn.KLDivLoss(reduction='batchmean')  # 使用KL散度作为损失函数
    count = list(Counter(observations).values())    
    observations = torch.softmax(torch.tensor(count, dtype=torch.float32), dim=0)

    if len(model.layers) < 1:
        return

    for epoch in range(num_epochs):
        optimizer.zero_grad()
        try:
            predicted_observations = model()
        except RuntimeError as e:
            print(f"Error computing predicted_observations: {e}")
            print(f"len(model.layers): {len(model.layers)}")
            for layer in model.layers:
                print(layer.weight.shape)

        if len(count) != predicted_observations.shape[1]:
            print(f"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL")

        try:
            loss = loss_fn(predicted_observations.log(), observations)
        except RuntimeError as e:
            print(f"Error computing loss: {e}")
            print(f"predicted_observations.shape: {predicted_observations.shape}")
            print(f"predicted_observations.log().shape: {predicted_observations.log().shape}")
            print(f"observations: {observations.shape}")

        loss.backward()
        optimizer.step()
        if epoch == 999:
            # print(f'Epoch {epoch}, Loss: {loss.item()} - Training stopped at 1000!')
            pass
        # if abs(loss.item()) < 0.00001:
        if abs(loss.item()) < 0.01:
            # print(f"{epoch}: {loss.item()} - Training stopped early!")
            break

def cal_n_k(distribution, epsilon):
    if log(1 - min(distribution)) == 0:
        return 0
    return ceil(log(epsilon/len(distribution))/log(1-min(distribution))) if len(distribution) != 1 else 6

def cal_m_k(distribution, p, epsilon):
    if len(distribution) == 0:
        return 0
    # print(f"P: {p}")
    if p == 0:
        return 0
    elif p == 1:
        return 6
    # print(f"len of distribution: {len(distribution)}")
    # print(f"log(1-p): {log(1-p)}")
    return ceil(log(epsilon/len(distribution))/log(1-p)) if len(distribution) != 1 else 6

'''
if __name__ == '__main__':
    d_0 = [0.013253448531031609, 0.011866091750562191, 0.011866091750562191, 0.011814105324447155, 0.011724359355866909, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866040527820587]
    d_1 = [0.013253448531031609, 0.011866091750562191, 0.011866091750562191, 0.011814105324447155, 0.011724359355866909, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866091750562191, 0.011866040527820587, 0.8801454305648804]
    print(cal_n_k(d_0, 0.05))
    print(cal_n_k(d_1, 0.05))
'''