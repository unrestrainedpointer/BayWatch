from dataclasses import dataclass

from diamond_miner.defaults import UNIVERSE_SUBSET
from diamond_miner.queries.fragments import ip_in
from diamond_miner.queries.query import ResultsQuery, prefixes_table, results_table
from diamond_miner.typing import IPNetwork


@dataclass(frozen=True)
class GetNodesFromResults(ResultsQuery):
    """
    Compute the links from the results table.
    This returns one line per `(flow, link)` pair.

    We do not emit a link in the case of single reply in a traceroute.
    For example: `* * node * *`, does not generate a link.
    However, `* * node * * node'`, will generate `(node, *)` and `(*, node')`.

    We emit cross-rounds links.
    For example if flow N sees node A at TTL 10 at round 1 and flow N sees node B at TTL 11 at round 2,
    we will emit `(1, 10, A) - (2, 11, B)`.

    We assume that there exists a single (flow, ttl) pair over all rounds (TODO: assert this).

    If `round_eq` is none, compute the links per flow, across all rounds.
    Otherwise, compute the links per flow, for the specified round.
    This is useful if you want to update a `links` table round-by-round:
    such a table will contain only intra-round links but can be updated incrementally.

    Examples:
        >>> from diamond_miner.test import client
        >>> from diamond_miner.queries import GetLinksFromResults
        >>> links = GetLinksFromResults().execute(client, "test_nsdi_example")
        >>> len(links)
        58
    """

    ignore_invalid_prefixes: bool = True
    "If true, exclude invalid prefixes from links computation."

    def statement(
        self, measurement_id: str, subset: IPNetwork = UNIVERSE_SUBSET
    ) -> str:
        if self.ignore_invalid_prefixes:
            invalid_filter = f"""
            AND probe_dst_prefix
            NOT IN (
                SELECT probe_dst_prefix
                FROM {prefixes_table(measurement_id)}
                AND has_amplification
            )
            """
            # TODO: We currently do not drop prefixes with loops as this considerably
            # reduces the number of discoveries. As such, we send more probe than necessary.
            # A better way would be to detect the min/max TTL of a loop, and to ignore it
            # in the next round query.
        else:
            invalid_filter = ""

        return f"""
        SELECT
            count(distinct reply_src_addr)
        FROM {results_table(measurement_id)}
        """