from clickhouse_driver import Client
import copy
# from diamond_miner.generators import probe_generator_parallel
# from utils.parallel_lb_single_address import probe_generator_parallel
# from utils.parallel_lb import probe_generator_parallel
from utils.parallel_lb_k import probe_generator_parallel
from diamond_miner.insert import insert_probe_counts
# from utils.insert_fast import insert_probe_counts
from diamond_miner.queries import InsertLinks, InsertPrefixes, InsertResults
from diamond_miner.queries.query import probes_table
import gc
import logging
import multiprocessing
from multiprocessing import Pool, Value, Lock
import os
import pandas as pd
from pathlib import Path
from pych_client import ClickHouseClient
import time
from utils.algorithm_em import baymuda_statistical_gurantee
from utils.configure import k_core, credentials, measurement_id, prefixes, logger, ALERT_LEVEL, process_num, pps
from utils.create_tables_mine import CreateTables
from utils.get_cumulative_probe import Query_probes
from utils.get_links import GetLinksFromResults
from utils.get_nodes import GetNodesFromResults
from utils.query_finished_ttl import Query_finished_ttl
from utils.query_matrix import Query_Matrix
from utils.query_links import Query_links
from utils.select_parameter import Query_parameter
from utils.insert_probes import InsertProbes
from utils.correct_round import CorrectRound
from utils_baymuda import send_probes_parallel, send_probes, split_into_chunks, merge_csv_files

logging.basicConfig(level=ALERT_LEVEL)
# 运行需要sudo -s 然后需要ulimit -n 50000 然后再运行

logger.alert(f"{len(prefixes)} prefixes!")
# 创建一个Value来跟踪休眠的进程数
sleeping_processes = Value('i', 0)
# 创建一个Lock以同步对该值的访问
lock = Lock()
# 允许进入休眠状态的最大进程数
max_sleeping_processes = 12

sleeping_processes_write = Value('i', 0)
lock_write = Lock()
max_sleeping_processes_write = 12

last_sleep_time = Value('d', time.time())

def process_result(args):
    i, result, measurement_id, round_, len_results, finished_ttl_prefix, finished_ttl_by_round_p = args
    global sleeping_processes
    global lock
    global last_sleep_time

    sleep_time_base = 2  # 基础睡眠时间
    cooldown_time = 60  # 冷却时间
    high_threshold = 50
    low_threshold = 20    # 低阈值

    current_load = os.getloadavg()[0]

    with lock:
        # 检查是否超过冷却时间，并且负载高于高阈值
        if current_load > high_threshold and time.time() - last_sleep_time.value > cooldown_time:
            while current_load > low_threshold and sleeping_processes.value < max_sleeping_processes:
                print(f"High load detected at {current_load}. Process {i} sleeping for {sleep_time_base} seconds...")
                time.sleep(sleep_time_base)
                sleeping_processes.value += 1
                current_load = os.getloadavg()[0]  # 再次检查负载
            # 更新最后一次睡眠时间
            last_sleep_time.value = time.time()
            print(f"Load reduced to {current_load}, exiting sleep mode.")
    
    # results = calculate_probes_with_inference_with_clickhouse_parameter(result, round_, finished_ttl_prefix, finished_ttl_by_round)
    prefix, results, finished_ttl_by_round_p, F = baymuda_statistical_gurantee(result, round_, finished_ttl_prefix, finished_ttl_by_round_p)

    if i != 0 and i % 100000 == 0:
        logger.alert(f"**********************************************************************************")
        logger.alert(f"The {i}th prefix of {len_results}(round: {round_}, measurement_id: {measurement_id})")
        logger.alert(f"**********************************************************************************")
    
    # 完成工作后，减少休眠进程的计数
    with lock:
        if sleeping_processes.value > 0:
            sleeping_processes.value -= 1
    
    return prefix, results, finished_ttl_by_round_p, F

def write_and_insert_database(all_results, measurement_id, finished_ttl_by_round, finished_prefix):
    start_time = time.time()
    probes_csv, probes_path = [], '/root/multipath-scanning/BayMuDA_v4.0/examples/output/probes.csv'
    for result_i in range(len(all_results)):
        probes_csv.append(all_results[result_i][1])
    flat_data = [item for sublist in probes_csv for item in sublist]
    df = pd.DataFrame(flat_data, columns=['probe_protocol', 'probe_dst_prefix', 'probe_ttl', 'cumulative_probes', 'round'])
    df.to_csv(probes_path, index=False)
    for result_i in range(len(all_results)):
        prefix = all_results[result_i][0]
        finished_ttl_by_round[prefix] = all_results[result_i][2]
        if all_results[result_i][3]: 
            finished_prefix.add(prefix)
        if result_i % 100000 == 0:
            logger.alert(f"**********************************************************************************")
            logger.alert(f"The {result_i}th prefix of {len(all_results)} has been judged(round: {round_}, measurement_id: {measurement_id})")
            logger.alert(f"**********************************************************************************")
    with ClickHouseClient(**credentials) as client:
        InsertProbes().execute(client, measurement_id, data=Path(probes_path).read_bytes())
    os.remove(probes_path)
    del all_results
    gc.collect()
    end_time = time.time()
    logger.alert(f"Insert operation takes {end_time - start_time:.2f} seconds.")
    return finished_ttl_by_round, finished_prefix

parameter_estimation = []
if __name__ == '__main__':
    if multiprocessing.get_start_method(allow_none=True) is None:
        multiprocessing.set_start_method('spawn')    
    print(f"measurement_id: {measurement_id}")
    with ClickHouseClient(**credentials) as client:
        CreateTables().execute(client, measurement_id)
    finished_ttl_by_round, finished_prefix, num_finished_prefix, n_probes_list = {}, set({}), [], []
    for round_ in range(1, 20): 
        num_finished_prefix.append(len(finished_prefix))
        logger.alert(f"**********************************************************************************")
        logger.alert(f"ROUND {round_}--Number of Finished Prefixes: {len(finished_prefix)}")
        logger.alert(f"**********************************************************************************\n")
        if round_ == 1:
            with ClickHouseClient(**credentials) as client:
                insert_probe_counts(client=client, measurement_id=measurement_id, round_=1, prefixes=prefixes)
        else:
            start_time = time.time()
            results_filepath_last_round = Path("/root/multipath-scanning/BayMuDA_v4.0/examples/output/results" + "_" + str(round_ - 1) + "")
            probes_filepath_last_round = Path("/root/multipath-scanning/BayMuDA_v4.0/examples/output/probes" + "_" + str(round_ - 1) + ".csv")
                
            result = []
            with ClickHouseClient(**credentials) as client:
                logger.alert("Insert to Clickhouse!")
                '''
                CorrectRound(round_c=0, round_o=1).execute(client, measurement_id)
                InsertResults().execute(client, measurement_id, data=results_filepath_last_round.read_bytes())
                CorrectRound(round_c=round_-1, round_o=1).execute(client, measurement_id)
                CorrectRound(round_c=1, round_o=0).execute(client, measurement_id)
                # 这里要改成挨个文件插入了
                '''
                for k_i in range(0, k_core):
                    results_filepath_i = Path(f"/root/multipath-scanning/BayMuDA_v4.0/examples/output/results_{str(round_ - 1)}_worker_{k_i}.csv")
                    CorrectRound(round_c=0, round_o=1).execute(client, measurement_id)
                    InsertResults().execute(client, measurement_id, data=results_filepath_i.read_bytes())
                    CorrectRound(round_c=round_-1, round_o=1).execute(client, measurement_id)
                    CorrectRound(round_c=1, round_o=0).execute(client, measurement_id)
                
                InsertPrefixes().execute(client, measurement_id)
                InsertLinks().execute(client, measurement_id)

                logger.alert("Query!")
                result = pd.DataFrame(Query_parameter().execute(client, measurement_id))
                logger.alert(f"result中prefix个数：{result['probe_dst_prefix'].nunique()}\n")
                probes = pd.DataFrame(Query_probes(round_eq=round_ - 1).execute(client, measurement_id=measurement_id))
                logger.alert(f"probes中prefix个数：{probes['probe_dst_prefix'].nunique()}")
                finished_ttl = pd.DataFrame(Query_finished_ttl(round_eq=round_-1).execute(client, measurement_id)) if round_ > 2 else []
                matrix = pd.DataFrame(Query_Matrix().execute(client, measurement_id))
                if len(finished_ttl) > 0:
                    finished_ttl = finished_ttl.groupby('probe_dst_prefix')
                links_num = pd.DataFrame(Query_links().execute(client, measurement_id))
                # print(links_num.head(5))
            '''
            os.remove(results_filepath_last_round)
            os.remove(probes_filepath_last_round)
            '''
            for k_i in range(0, k_core):
                results_filepath_i = Path(f"/root/multipath-scanning/BayMuDA_v4.0/examples/output/results_{str(round_ - 1)}_worker_{k_i}.csv")
                os.remove(results_filepath_i)
                # os.remove(probes_filepath_list[k_i])
            
            result_probes = pd.merge(result, probes, on='probe_dst_prefix', how='inner')  # 默认是 'inner' 连接
            logger.alert(f"result_probes中prefix个数：{result_probes['probe_dst_prefix'].nunique()}\n")
            result_probes_links = pd.merge(result_probes, links_num, on='probe_dst_prefix', how='inner')
            result_probe_matrix = pd.merge(result_probes_links, matrix, on='probe_dst_prefix', how='inner')
            logger.alert(f"result_probe_matrix中prefix个数：{result_probe_matrix['probe_dst_prefix'].nunique()}\n")

            tasks = []
            for i in range(len(result_probe_matrix)):
                prefix = result_probe_matrix.iloc[i]['probe_dst_prefix']
                if prefix in finished_prefix:
                    continue
                finished_ttl_prefix = set([])
                if len(finished_ttl) != 0 and prefix in finished_ttl['probe_dst_prefix'].groups:
                    finished_ttl_prefix = set(finished_ttl.get_group(prefix)['probe_ttl'].tolist())
                if prefix not in finished_ttl_by_round.keys():
                    finished_ttl_by_round[prefix] = {}
                if 'll_round' not in finished_ttl_by_round[prefix].keys():
                    finished_ttl_by_round[prefix]['ll_round'] = set([])
                if 'l_round' not in finished_ttl_by_round[prefix].keys():
                    finished_ttl_by_round[prefix]['l_round'] = set([])
                finished_ttl_by_round_p = copy.deepcopy(finished_ttl_by_round[prefix])
                tasks.append((i, result_probe_matrix.iloc[i], measurement_id, round_, len(result_probe_matrix), finished_ttl_prefix, finished_ttl_by_round_p))
            end_time = time.time()
            logger.alert(f"**********************************************************************************")
            logger.alert(f"Preprocess in round {round_} takes {end_time - start_time:.2f} seconds.")
            logger.alert(f"**********************************************************************************\n")

            start_time = time.time()
            with Pool(processes=process_num) as pool:
                results = pool.map(process_result, tasks, chunksize=500)
            end_time = time.time()
            parameter_estimation.append(end_time - start_time)
            logger.alert(f"**********************************************************************************")
            logger.alert(f"Pararmeter Estimation in round {round_} takes {end_time - start_time:.2f} seconds.")
            logger.alert(f"**********************************************************************************\n")
            time.sleep(10)
            # 分别写入数据库
            logger.alert(f"Begin to write to file and clickhouse!")
            finished_ttl_by_round, finished_prefix = write_and_insert_database(results, measurement_id, finished_ttl_by_round, finished_prefix)
            logger.alert(f"Finish writing to file and clickhouse!")

            

        probes_filepath = Path("/root/multipath-scanning/BayMuDA_v4.0/examples/output/probes" + "_" + str(round_) + ".csv")
        results_filepath = Path("/root/multipath-scanning/BayMuDA_v4.0/examples/output/results" + "_" + str(round_) + "")
        start_time = time.time()
        with ClickHouseClient(**credentials) as client:
            # n_probes = probe_generator_parallel(filepath=probes_filepath, client=client, measurement_id=measurement_id, round_=round_)
            n_probes = probe_generator_parallel(filepath=probes_filepath, client=client, measurement_id=measurement_id, round_=round_, k=k_core)
        end_time = time.time()
        logger.alert(f"**********************************************************************************")
        logger.alert(f"Probe_generator_parallel in round {round_} takes {end_time - start_time:.2f} seconds.")
        logger.alert(f"**********************************************************************************\n")
        logger.alert("n_probes=%s", n_probes)
        time.sleep(10)
        n_probes_list.append(n_probes)
        if n_probes == 0: break
        try:
            start_time = time.time()
            ''''''
            probes_filepath_list = []
            for k_i in range(0, k_core):
                probes_filepath_list.append(Path(f"/root/multipath-scanning/BayMuDA_v4.0/examples/output/probes_{round_}.{k_i}.csv"))        
            send_probes_parallel(results_filepath, probes_filepath_list, pps, k_core)
            # send_probes(results_filepath, probes_filepath, pps)
            end_time = time.time()
            logger.alert(f"**********************************************************************************")
            logger.alert(f"Probing in round {round_} takes {end_time - start_time:.2f} seconds.")
            logger.alert(f"**********************************************************************************\n")
        except RuntimeError as e:
            logging.error("Probing failed: %s", e)
            raise

    with ClickHouseClient(**credentials) as client:
        nodes = GetNodesFromResults().execute(client, measurement_id)
        links = GetLinksFromResults().execute(client, measurement_id)
    logger.alert(f"n_probes: {n_probes_list}")
    logger.alert(f"Parameter estimation time: {parameter_estimation}")
    logger.alert(f"Number of Finished Prefixes: {num_finished_prefix}")
    logger.alert(f"{nodes[0].values()} nodes discovered")
    logger.alert(f"{links[0].values()} links discovered")