from diamond_miner.test import client
from diamond_miner.queries import DropTables

# Configuration
credentials = {
    "base_url": "http://localhost:8123",
    "database": "default",
    "username": "default",
    "password": "",
}

tables = ['0a78b04d_972c_4371_bf82_8b52b288029c',
'0edce4dc_f9dc_4fa9_83e0_65c291ee3881',
'1a643258_16c8_4496_97f8_35cf475ea7bf',
'0e679dce_eea5_4f50_9457_801da3dee8e2',
'04073a33_b02e_4b02_86bc_e06047feaa4b',
'08ec7b95_0f23_4487_b551_f02f65a78775',
'0d3a9fdd_7c5a_4071_be2d_c8ad3f93a6e3',
'17cfe131_b112_4a18_8d98_4291944b0936',
'1b56b009_327c_4db1_b9e5_5c52fd660ec8',
'1f02219a_f0e4_48da_b66c_defb5ad8825b',
'1fd27157_8a8a_4bc3_9bd1_14a6224ac57d',
'2d94c2a5_eacc_4b2d_9012_4c8aa8282f8b',
'31974d7e_9b0b_4db2_a7f7_865d1681d452',
'3977aeec_2eae_4c51_b21c_b9d639501f5e',
'4612d207_1330_43ea_9971_aef6601534a6',
'48105adb_39ce_4a35_9283_cc93006dc979',
'4a8e4d6f_2607_47e4_af0d_15d7fa34b0f3',
'4bb338e1_de21_4b91_ab8b_f0991749c386',
'4e726601_6a34_4795_8697_5f4250d500cc',
'4e8153f6_4d4c_46b4_86f9_2f0d49f92425',
'671dd88e_9b59_4dd3_b223_487147a38b5f',
'698e867e_eadd_42c2_89f3_87866459447c',
'6f4f89f0_6635_4506_b621_ed7aefc4b9f1',
'7601e371_1a66_41b9_bb0f_fd33c901bcf4',
'7b681d33_6a40_4a82_9fa5_7e1b273292b2',
'8a892b3b_33b2_4edd_b610_4b7916ac8947',
'8b93d07c_b4a6_476c_8298_4ffbe49dfe7b',
'8d25e5b5_e993_4577_9382_0928e2749910',
'8f5148e9_be9e_4ff8_bf26_3d00a6de8ee8',
'97468db0_de93_4d9b_b233_421ad33fdced',
'a9004089_b3ed_4c2f_af59_d981494e3495',
'aa523962_6be9_4c1a_a0d2_f61f97082474',
'bc76e9bb_cf0d_4fea_ab17_afd4dcbda2fa',
'bf6aef18_67b2_4dcc_a79c_49cd0854337d',
'c62355e7_abe3_4ef0_b809_fc9b63288ff9',
'ce309c86_d11a_4ddf_817c_4ab0f6377eb1',
'd444ad35_1faa_4bcd_bf27_6afede682ad1',
'd7044cc7_f592_48c8_9b34_d6c0a6d93b8f',
'db2cec46_214e_4d2b_862e_7e7f0ec6ceee',
'ddbafc5e_61f1_4db6_b1d2_dc64931ba57a',
'e41fcf96_bbb9_4d6d_bac4_50c0d95ac9b7',
'e5b8d1ca_861b_4c95_833c_d0d50b4daebe',
'ea2d5a88_39a2_4e79_811d_ebf8e8117892',
'f9c9c0d0_6843_4943_a05d_fcbe8417f5f7',
'fa14c73f_8756_4f0b_bbe5_ae68dcde71de',
'fef24838_67c5_4375_b3b7_5bc1bb6bbf63',
'bfcf8ffe_7fa5_4890_b432_6eb9d01ea4ab',
'f2e95668_cefa_4b68_8113_ba547d2a6981']

def drop(tables=tables):
    for table in tables:
        if table == '1153ab58_0212_4ab1_800f_e5ecbe043aa5' or table == 'fad5f462_f126_4546_a22f_ed2b63ca89f0' or table == '840e8c55_aea0_40ff_8ade_a4ca189d402a':
            continue
        DropTables().execute(client, table)

def string(measurement_id):
    tmp = measurement_id.split('-')
    return tmp[0] + '_' + tmp[1] + '_' + tmp[2] + '_' + tmp[3] + '_' + tmp[4]

if __name__ == '__main__':
    drop()