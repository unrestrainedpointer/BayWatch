import os
import torch
import numpy as np
import pandas as pd
from math import ceil
from pycaracal import prober
from diamond_miner.defaults import DEFAULT_FAILURE_RATE
from utils.neural_network import TopologyNeuralNetwork, train, cal_n_k, cal_m_k
import multiprocessing

attr = ['uniq_nodes', 
        'y_nodes',
        'probe_protocol',
        'probe_dst_prefix',
        'arrayMap(lambda(tuple(t), (tupleElement(t, 1), countEqual(nodes, t))), uniq_nodes)'
        ]
layer = 5

def observation_generate(y, num_observations):
    observations = np.array(y)
    observations_dist = np.zeros(num_observations)
    # print(f"obervations: {str(observations)}")
    # print(f"observations_dist: {str(observations_dist)}")
    for obs in observations:
        observations_dist[obs] += 1
    observations_dist /= observations_dist.sum()  # 转换为概率分布
    observations_dist = torch.tensor(observations_dist, dtype=torch.float32)
    return observations_dist

def model_train_matrix(ttl_final, dict_y, num_states_per_layer, num_observations, matrix_data, ttl_inital, type=0):
    # 构造当前第key跳的观测值，用以估计前layer跳的参数
    y = dict_y[ttl_final]
    # print(f"num_states_per_layer: {num_states_per_layer}")
    transition_matrices = {}
    matrix_data = generate_matrix(matrix_data)
    for data in matrix_data:
        matrix = np.array(data['matrix'])
        transition_matrices[data['near_ttl']] = matrix
    model = TopologyNeuralNetwork(num_states_per_layer, num_observations, transition_matrices, ttl_inital)
    # 生成观测数据的模拟分布
    observations_dist = observation_generate(y, num_observations)
    # 训练模型
    train(model, observations_dist, type=type)
    # 获取第一层、中间层以及最后一层到观测值的分布
    initial_distribution, layer_distributions, observation_distribution = model.get_distributions()
    # 把第一层的分布合并到中间层的list中，方便统一使用
    layer_distributions.insert(0, initial_distribution)
    return layer_distributions, model.get_observation_matrix(), observations_dist, model.get_transition_matrices()

def model_train(ttl_final, dict_y, num_states_per_layer, num_observations, ttl_inital):
    # 构造当前第key跳的观测值，用以估计前layer跳的参数
    y = dict_y[ttl_final]
    # print(f"num_states_per_layer: {num_states_per_layer}")
    
    model = TopologyNeuralNetwork(num_states_per_layer, num_observations, None, ttl_inital)
    # 生成观测数据的模拟分布
    observations_dist = observation_generate(y, num_observations)
    # 训练模型
    train(model, observations_dist, type=type)
    # 获取第一层、中间层以及最后一层到观测值的分布
    initial_distribution, layer_distributions, observation_distribution = model.get_distributions()
    # 把第一层的分布合并到中间层的list中，方便统一使用
    layer_distributions.insert(0, initial_distribution)
    return layer_distributions, model.get_observation_matrix(), observations_dist, model.get_transition_matrices()

import pandas as pd
def correct_round(results_filepath, round_):
    dataframe = pd.read_csv(results_filepath)
    dataframe['round'] = round_ - 1
    dataframe.to_csv(results_filepath, index=False)

''''''
def send_probes(results_filepath, probes_filepath, pps, wait_time=1):
    config = prober.Config()
    config.set_output_file_csv(str(results_filepath))
    config.set_probing_rate(pps)
    config.set_sniffer_wait_time(wait_time)
    prober.probe(config, str(probes_filepath))

def send_probes_worker(worker_id, results_filepath, probes_filepath_list, rate_per_worker):
    """
    单个工作进程的发包任务。
    """
    config = prober.Config()
    config.set_output_file_csv(f"{results_filepath}_worker_{worker_id}.csv")  # 每个进程独立结果文件
    config.set_probing_rate(rate_per_worker)  # 每个进程的发包速率
    config.set_sniffer_wait_time(1)
    print(f"Worker {worker_id} starts probing...")
    prober.probe(config, str(probes_filepath_list[worker_id]))
    os.remove(probes_filepath_list[worker_id])
    print(f"Worker {worker_id} finished probing!")


def send_probes_parallel(results_filepath, probes_filepath_list, total_rate, num_workers):
    """
    使用多进程并行发包。
    """
    # 每个工作进程的发包速率
    # rate_per_worker = total_rate // num_workers
    rate_per_worker = total_rate
    # 创建进程池
    processes = []
    for worker_id in range(num_workers):
        p = multiprocessing.Process(
            target=send_probes_worker,
            args=(worker_id, results_filepath, probes_filepath_list, rate_per_worker)
        )
        processes.append(p)
        p.start()

    # 等待所有进程完成
    for p in processes:
        p.join()

    print("All workers have completed probing.")

def generate_matrix(data):
    result = []
    probe_dst_prefix = data['probe_dst_prefix']
    ttl_pairs = data['ttl_pairs']
    
    for ttl_pair in ttl_pairs:
        near_ttl = ttl_pair[0]
        id_pairs = ttl_pair[1]
        
        if not id_pairs:
            max_near_id = 1
            max_far_id = 1
        else:
            max_near_id = max(pair[0][0] for pair in id_pairs)
            max_far_id = max(pair[0][1] for pair in id_pairs)
        
        matrix = np.zeros((max_near_id, max_far_id), dtype=int)
        
        for (near_id, far_id), count in id_pairs:
            matrix[near_id - 1, far_id - 1] = count
        
        result.append({
            'probe_dst_prefix': probe_dst_prefix,
            'near_ttl': near_ttl,
            'matrix': matrix.tolist()
        })
    
    return result

def generate_dict(ttls, list_n, list_y, cumulative_probes):
    dict_ttls, dict_y = {}, {}
    for ttl_i in range(len(ttls)):
        probes_obtain = 0
        dict_ttls[ttls[ttl_i]] = list_n[ttl_i]
        init_num = 0
        dict_y[ttls[ttl_i]] = []
        for count in list_y[ttl_i]:
            probes_obtain += count
            for count_i in range(0, count):
                dict_y[ttls[ttl_i]].append(init_num)
            init_num += 1
        if cumulative_probes[ttl_i-2][1] - probes_obtain != 0:
            dict_ttls[ttls[ttl_i]] = list_n[ttl_i] + 1
            for count_i in range(0, cumulative_probes[ttl_i-2][1] - probes_obtain):
                dict_y[ttls[ttl_i]].append(init_num)
    return dict_ttls, dict_y

# 我们首先看key-layer在不在dict_ttls.keys()中，如果不在
    # 要么是情况3，负数肯定不在dict_ttls.keys()中，这个时候ttl_inital应该是1
    # 要么是情况2的第一种情况，这个时候应该用keys[i + 1]的下一跳，当然i+1得在keys中，但是如果keys[i+1]就是1或者i+1不在keys中，那就用1就好了
    #那我们直接将dict_ttls.keys中key以及其相邻的跳之间组成一个model
def cal_ttl_init(ttl_final, dict_ttls):
    if (ttl_final - layer + 1) not in dict_ttls.keys():
        i_tmp = ttl_final - layer + 1
        while i_tmp not in dict_ttls.keys() and i_tmp > 0:
            i_tmp -= 1
        ttl_inital = i_tmp + 1 if (i_tmp > 1) else 1
    else: # 那就是2的第二种情况或者1
        ttl_inital = ttl_final - layer + 1 if ttl_final - layer != 1 else 1
    return ttl_inital

# 本函数在原有计算探测数的基础上添加利用推断的冗余减少方法
def calculate_probes_with_inference_with_clickhouse_parameter(dict_result, round_):
    probe_protocol, probe_dst_prefix, ttls, list_n, list_y, cumulative_probes = 17, dict_result['probe_dst_prefix'], dict_result['ttls'], dict_result['list_n'], dict_result['list_y'], dict_result['ttl_and_probes_array']
    dict_ttls, dict_y = generate_dict(ttls, list_n, list_y, cumulative_probes)


    dict_ttls = {k: dict_ttls[k] for k in sorted(dict_ttls, reverse=True)}
    # 从最后一跳（dict_ttls.keys()中的第一个元素）开始遍历，有以下三种情况：
        # 1. 正常的连续layer跳都在dict_ttls.keys()中
        # 2. 断跳了，即要么key-layer不在其中，要么key-layer到key的中间断了
        # 3. 走到头的时候剩下的跳不足layer跳了
    # 以上三种统一为定义好起始ttl和结束ttl即可
    keys, i, results, parameter_nn = list(dict_ttls.keys()), 0, [], []
    while i < len(keys):
        ttl_final = keys[i]
        num_states_per_layer, num_observations = [], dict_ttls[ttl_final]  # 每层的状态数, 观测值的可能状态数

        ttl_inital = cal_ttl_init(ttl_final, dict_ttls)

        # 下面开始根据ttl_inital和ttl_final构造model
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            num_states_per_layer.append(dict_ttls[ttl_tmp] + 1 if ttl_tmp in dict_ttls.keys() else 1)
        num_states_per_layer[ttl_final - ttl_inital] = dict_ttls[ttl_final]
        
        layer_distributions, observation_matrix, observations_dist, transition_matrices = model_train(ttl_final, dict_y, num_states_per_layer, num_observations, ttl_inital)

        # 根据得到的每跳的分布，计算每跳所需要的探测数
        list_n_k = []
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            # 当前层的下标，如果第一层，那么ttl_inital-ttl_inital=0，正好是下标为0
            layer_index = ttl_tmp - ttl_inital
            # 当前这层节点的概率分布以及这层最后一个节点的概率
            distribution_current, p_reach_new_node = layer_distributions[layer_index], distribution_current[len(distribution_current) - 1]
            # 这层最后一个节点到下一层所有节点的转移概率
            transition_current = transition_matrices[layer_index][-1] if ttl_tmp == ttl_final else observation_matrix[-1]
            # 计算假设的这个节点（该层最后一个节点）每条后继边的概率
            p_reach_new_edges = []
            for edge_index in range(len(transition_current)):
                p_reach_new_edges.append(p_reach_new_node * transition_current[edge_index])
            # 计算要确定这个假设的节点不存在至少需要发多少包
            n_k = 0 if p_reach_new_node < 1 / (len(distribution_current) * 100) else cal_n_k(distribution_current, DEFAULT_FAILURE_RATE)
            # 计算要发现这个假设节点的每条后继边不存在分别至少需要发送多少包
            
            list_n_k.append(n_k)
            results.append((probe_protocol, probe_dst_prefix, ttl_tmp, n_k, round_))
        
        results_enhance, last_index = [], len(results) - 1
        results_enhance.append((results[0][0], results[0][1], results[0][2], max(results[0][3], results[1][3]) ,results[0][4]))
        for result_i in range(1, last_index):
            results_enhance.append((results[result_i][0], results[result_i][1], results[result_i][2], max(max(results[result_i][3], results[result_i + 1][3]), results[result_i - 1][3]) ,results[result_i][4]))
        results_enhance.append((results[last_index][0], results[last_index][1], results[last_index][2], max(results[last_index][3], results[last_index - 1][3]) ,results[last_index][4]))
        
        parameter_nn.append((num_states_per_layer, observations_dist, list_n_k))
        # 下面根据当前步长确定下一个i值
        if ttl_inital == 1: break
        elif (ttl_inital - 1) in dict_ttls.keys():
            for i_tmp in range(len(keys)):
                if keys[i_tmp] == ttl_inital - 1:
                    i = i_tmp
                    break
        else:# 如果ttl_inital - 1不在keys中，比如keys=[16, 15, 14, 10]，如果14-16是一个模型，则找不到11的
        # 此时把ttl_inital之后第一个存在于keys中的ttl当成最后一跳
            for i_tmp in range(len(keys)):
                flag = False
                while i_tmp < len(keys) and keys[i_tmp] >= ttl_inital and keys[i_tmp] < ttl_final:
                    flag = True
                    i_tmp += 1
                if flag:
                    i = i_tmp - 1
                    break
    return results

# 我们首先看key-layer在不在dict_ttls.keys()中，如果不在
    # 要么是情况3，负数肯定不在dict_ttls.keys()中，这个时候ttl_inital应该是1
    # 要么是情况2的第一种情况，这个时候应该用keys[i + 1]的下一跳，当然i+1得在keys中，但是如果keys[i+1]就是1或者i+1不在keys中，那就用1就好了
    #那我们直接将dict_ttls.keys中key以及其相邻的跳之间组成一个model
def cal_ttl_init(ttl_final, dict_ttls):
    if (ttl_final - layer + 1) not in dict_ttls.keys():
        i_tmp = ttl_final - layer + 1
        while i_tmp not in dict_ttls.keys() and i_tmp > 0:
            i_tmp -= 1
        ttl_inital = i_tmp + 1 if (i_tmp > 1) else 1
    else: # 那就是2的第二种情况或者1
        ttl_inital = ttl_final - layer + 1 if ttl_final - layer != 1 else 1
    return ttl_inital

# 本函数在原有计算探测数的基础上添加利用推断的冗余减少方法
def parameter_estimate_motivation(dict_result, round_, matrix):
    probe_dst_prefix, ttls, list_n, list_y = dict_result['probe_dst_prefix'], dict_result['ttls'], dict_result['list_n'], dict_result['list_y']
    dict_ttls, dict_y = generate_dict(ttls, list_n, list_y)


    dict_ttls = {k: dict_ttls[k] for k in sorted(dict_ttls, reverse=True)}

    keys, i, results, parameter_nn = list(dict_ttls.keys()), 0, [], []
    while i < len(keys):
        ttl_final = keys[i]
        num_states_per_layer, num_observations = [], dict_ttls[ttl_final]  # 每层的状态数, 观测值的可能状态数

        ttl_inital = cal_ttl_init(ttl_final, dict_ttls)

        # 下面开始根据ttl_inital和ttl_final构造model
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            num_states_per_layer.append(dict_ttls[ttl_tmp] + 1 if ttl_tmp in dict_ttls.keys() else 1)
        num_states_per_layer[ttl_final - ttl_inital] = dict_ttls[ttl_final]
        
        # 这里需要把matrix处理成ttl_inital到ttl_final之间的
        
        if ttl_final == 10:
            ttl_final = 9
        layer_distributions, observation_matrix, observations_dist, transition_matrices = model_train(ttl_final, dict_y, num_states_per_layer, num_observations, matrix, ttl_inital)

        # 根据得到的每跳的分布，计算每跳所需要的探测数
        list_n_k = []
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            # 当前层的下标，如果第一层，那么ttl_inital-ttl_inital=0，正好是下标为0
            layer_index = ttl_tmp - ttl_inital
            # 当前这层节点的概率分布以及这层最后一个节点的概率
            distribution_current = layer_distributions[layer_index]
            p_reach_new_node = min(distribution_current)
            # 这层最后一个节点到下一层所有节点的转移概率
            # transition_current = transition_matrices[layer_index][-1] if ttl_tmp == ttl_final else observation_matrix[-1]
            # 计算假设的这个节点（该层最后一个节点）每条后继边的概率
            # p_reach_new_edges = []
            # for edge_index in range(len(transition_current)):
                # p_reach_new_edges.append(p_reach_new_node * transition_current[edge_index])
            # 计算要确定这个假设的节点不存在至少需要发多少包
            n_k = 0 if p_reach_new_node < 1 / (len(distribution_current) * 20) else cal_n_k(distribution_current, DEFAULT_FAILURE_RATE)
            # 计算要发现这个假设节点的每条后继边不存在分别至少需要发送多少包
            if ttl_tmp == 1:
                print("分布在此：")
                print(f"Round {round_}: {distribution_current}")
                print(n_k)
            
            list_n_k.append(n_k)
            results.append((probe_dst_prefix, ttl_tmp, n_k, round_))
        
        results = sorted(results, key=lambda x: x[1])
        results_enhance, last_index = [], len(results) - 1
        results_enhance.append((results[0][0], results[0][1], max(results[0][2], results[1][2]) ,results[0][3]))
        for result_i in range(1, last_index):
            results_enhance.append((results[result_i][0], results[result_i][1], max(results[result_i][2], results[result_i + 1][2]) ,results[result_i][3]))
        results_enhance.append((results[last_index][0], results[last_index][1], max(results[last_index][2], results[last_index - 1][2]) ,results[last_index][3]))
        
        parameter_nn.append((num_states_per_layer, observations_dist, list_n_k))
        # 下面根据当前步长确定下一个i值
        if ttl_inital == 1: break
        else:
            for i_tmp in range(len(keys)):
                if keys[i_tmp] == ttl_inital:
                    i = i_tmp
                    break
        '''
        elif (ttl_inital - 1) in dict_ttls.keys():
            for i_tmp in range(len(keys)):
                if keys[i_tmp] == ttl_inital - 1:
                    i = i_tmp
                    break
        else:# 如果ttl_inital - 1不在keys中，比如keys=[16, 15, 14, 10]，如果14-16是一个模型，则找不到11的
        # 此时把ttl_inital之后第一个存在于keys中的ttl当成最后一跳
            for i_tmp in range(len(keys)):
                flag = False
                while i_tmp < len(keys) and keys[i_tmp] >= ttl_inital and keys[i_tmp] < ttl_final:
                    flag = True
                    i_tmp += 1
                if flag:
                    i = i_tmp - 1
                    break
        '''
    return results

# 本函数在原有计算探测数的基础上添加利用推断的冗余减少方法
def parameter_estimate_motivation_for_edge(dict_result, round_, matrix):
    probe_dst_prefix, ttls, list_n, list_y = dict_result['probe_dst_prefix'], dict_result['ttls'], dict_result['list_n'], dict_result['list_y']
    dict_ttls, dict_y = generate_dict(ttls, list_n, list_y)

    benifit_probe = []

    dict_ttls = {k: dict_ttls[k] for k in sorted(dict_ttls, reverse=True)}

    keys, i, results, parameter_nn = list(dict_ttls.keys()), 0, [], []
    while i < len(keys):
        ttl_final = keys[i]
        num_states_per_layer, num_observations = [], dict_ttls[ttl_final]  # 每层的状态数, 观测值的可能状态数

        ttl_inital = cal_ttl_init(ttl_final, dict_ttls)

        # 下面开始根据ttl_inital和ttl_final构造model
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            num_states_per_layer.append(dict_ttls[ttl_tmp] if ttl_tmp in dict_ttls.keys() else 1)
        num_states_per_layer[ttl_final - ttl_inital] = dict_ttls[ttl_final]
        
        layer_distributions, observation_matrix, observations_dist, transition_matrices = model_train(ttl_final, dict_y, num_states_per_layer, num_observations, matrix, ttl_inital, 1)

        # 根据得到的每跳的分布，计算每跳所需要的探测数
        list_n_k = []
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            # 当前层的下标，如果第一层，那么ttl_inital-ttl_inital=0，正好是下标为0
            layer_index = ttl_tmp - ttl_inital
            benifit_probe_layer = []
            # 当前这层节点的概率分布以及这层最后一个节点的概率
            distribution_current = layer_distributions[layer_index]
            # 这层最后一个节点到下一层所有节点的转移概率
            transition_current = transition_matrices[layer_index] if ttl_tmp != ttl_final else observation_matrix
            # transition_current = [[transition_current[j][i] for j in range(len(transition_current))] for i in range(len(transition_current[0]))]
            # 计算假设的这个节点（该层最后一个节点）每条后继边的概率
            
            N_l = 0
            for current_index in range(len(distribution_current)):
                benifit_probe_node = []
                p_current_node = distribution_current[current_index]
                p_current_transition = transition_current[current_index]

                for edge_index in range(len(p_current_transition)):
                    probes_current = ceil(cal_m_k(p_current_transition, p_current_transition[edge_index], DEFAULT_FAILURE_RATE) / p_current_node)
                    benifit_probe_node.append(probes_current)
                    N_l = max(N_l, probes_current)

                benifit_probe_layer.append(benifit_probe_node)
            benifit_probe.append(benifit_probe_layer)
            print(f"{ttl_tmp}: {distribution_current}")

            list_n_k.append(N_l)
            results.append((probe_dst_prefix, ttl_tmp, N_l, round_))
        
        results_enhance, last_index = [], len(results) - 1
        results_enhance.append((results[0][0], results[0][1], max(results[0][2], results[1][2]) ,results[0][3]))
        for result_i in range(1, last_index):
            results_enhance.append((results[result_i][0], results[result_i][1], max(results[result_i][2], results[result_i + 1][2]) ,results[result_i][3]))
        results_enhance.append((results[last_index][0], results[last_index][1], max(results[last_index][2], results[last_index - 1][2]) ,results[last_index][3]))
        
        parameter_nn.append((num_states_per_layer, observations_dist, list_n_k))
        # 下面根据当前步长确定下一个i值
        if ttl_inital == 1: break
        else:
            for i_tmp in range(len(keys)):
                if keys[i_tmp] == ttl_inital:
                    i = i_tmp
                    break
        '''
        elif (ttl_inital - 1) in dict_ttls.keys():
            for i_tmp in range(len(keys)):
                if keys[i_tmp] == ttl_inital - 1:
                    i = i_tmp
                    break
        else:# 如果ttl_inital - 1不在keys中，比如keys=[16, 15, 14, 10]，如果14-16是一个模型，则找不到11的
        # 此时把ttl_inital之后第一个存在于keys中的ttl当成最后一跳
            for i_tmp in range(len(keys)):
                flag = False
                while i_tmp < len(keys) and keys[i_tmp] >= ttl_inital and keys[i_tmp] < ttl_final:
                    flag = True
                    i_tmp += 1
                if flag:
                    i = i_tmp - 1
                    break
        '''
    '''
    for jk in range(6):
        print(f"Layer {jk}: ")
        for jkl in range(len(benifit_probe[jk])):
            print(f"Node_{jkl}: {benifit_probe[jk][jkl]}")
            print(f"{layer_distributions[jk][jkl]}")
    '''
    print(results_enhance)
    return results_enhance

'''
def calculate_probes_with_inference_with_clickhouse_parameter_improved(dict_result, round_):
    probe_protocol, probe_dst_prefix, ttls, list_n, list_y = 1, dict_result['probe_dst_prefix'], dict_result['ttls'], dict_result['list_n'], dict_result['list_y']
    dict_ttls, dict_y = {}, {}

    for ttl_i in range(len(ttls)):
        # dict_ttls是当前前缀所有轮探测结果中出现的ttl组成的字典，value是每跳的节点数
        dict_ttls[ttls[ttl_i]] = list_n[ttl_i]
        init_num = 0
        dict_y[ttls[ttl_i]] = []
        for count in list_y[ttl_i]:
            for count_i in range(0, count):
                dict_y[ttls[ttl_i]].append(init_num)
            init_num += 1

    dict_ttls = {k: dict_ttls[k] for k in sorted(dict_ttls, reverse=True)}
    # 从最后一跳（dict_ttls.keys()中的第一个元素）开始遍历，有以下三种情况：
        # 1. 正常的连续layer跳都在dict_ttls.keys()中
        # 2. 断跳了，即要么key-layer不在其中，要么key-layer到key的中间断了
        # 3. 走到头的时候剩下的跳不足layer跳了
    # 以上三种统一为定义好起始ttl和结束ttl即可
    keys, i, results = list(dict_ttls.keys()), 0, []
    while i < len(keys):
        ttl_final = keys[i]
        # df = pd.DataFrame(columns=['probe_protocol', 'probe_dst_prefix', 'probe_ttl', 'cumulative_probes', 'round'])
        num_states_per_layer, num_observations = [], dict_ttls[ttl_final]  # 每层的状态数, 观测值的可能状态数

        # 我们首先看key-layer在不在dict_ttls.keys()中，如果不在
            # 要么是情况3，负数肯定不在dict_ttls.keys()中，这个时候ttl_inital应该是1
            # 要么是情况2的第一种情况，这个时候应该用keys[i + 1]的下一跳，当然i+1得在keys中，但是如果keys[i+1]就是1或者i+1不在keys中，那就用1就好了
        #那我们直接将dict_ttls.keys中key以及其相邻的跳之间组成一个model
        if (ttl_final - layer + 1) not in dict_ttls.keys():
            i_tmp = ttl_final - layer + 1
            while i_tmp not in dict_ttls.keys() and i_tmp > 0:
                i_tmp -= 1
            ttl_inital = i_tmp + 1 if (i_tmp > 1) else 1
        else: # 那就是2的第二种情况或者1
            ttl_inital = ttl_final - layer + 1 if ttl_final - layer != 1 else 1

        # 下面开始根据ttl_inital和ttl_final构造model
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            num_states_per_layer.append(dict_ttls[ttl_tmp] + 1 if ttl_tmp in dict_ttls.keys() else 1)
        num_states_per_layer[ttl_final - ttl_inital] = dict_ttls[ttl_final]

        if len(num_states_per_layer) < 2:
            with open('./prefixes_remain.txt', 'a') as fk:
                fk.write(str(probe_dst_prefix) + '\n')
            i += 1
            continue
        
        start = time.time()
        layer_distributions, observation_distribution, observations_dist = model_train(ttl_final, dict_y, num_states_per_layer, num_observations)
        end = time.time()
        duration = end - start
        # if round_ >= 4 and duration > 0.5:
            # print(f"Round {round_} {probe_dst_prefix} took {duration:.2f} seconds")
        # 根据得到的每跳的分布，计算每跳所需要的探测数
        list_n_k = []
        for ttl_tmp in range(ttl_inital, ttl_final + 1):
            distribution_current = layer_distributions[ttl_tmp - ttl_inital]
            n_k = 0 if distribution_current[len(distribution_current) - 1] < 1 / (len(distribution_current) * 100) else cal_n_k(distribution_current, DEFAULT_FAILURE_RATE)
            # n_k = n_k if n_k < 255 else 255
            list_n_k.append(n_k)
            results.append((probe_protocol, probe_dst_prefix, ttl_tmp, n_k, round_))
        
        results_enhance = []
        for result_i in range(len(results) - 1):
            results_enhance.append((results[result_i][0], results[result_i][1], results[result_i][2], max(results[result_i][3], results[result_i + 1][3]) ,results[result_i][4]))

        # 下面根据当前步长确定下一个i值
        if ttl_inital == 1: break
        elif (ttl_inital - 1) in dict_ttls.keys():
            for i_tmp in range(len(keys)):
                if keys[i_tmp] == ttl_inital - 1:
                    i = i_tmp
                    break
        else:# 如果ttl_inital - 1不在keys中，比如keys=[16, 15, 14, 10]，如果14-16是一个模型，则找不到11的
        # 此时把ttl_inital之后第一个存在于keys中的ttl当成最后一跳
            for i_tmp in range(len(keys)):
                flag = False
                while i_tmp < len(keys) and keys[i_tmp] >= ttl_inital and keys[i_tmp] < ttl_final:
                    flag = True
                    i_tmp += 1
                if flag:
                    i = i_tmp - 1
                    break
    return results_enhance
'''
'''
if __name__ == '__main__':
    dict_result = {
        'probe_dst_prefix': '::ffff:119.231.17.0', 
        'ttls': [2, 11, 12, 13, 14, 15, 16], 
        'list_n': [1, 2, 3, 2, 3, 3, 1], 
        'list_y': [[6], [1, 1], [1, 1, 1], [1, 1], [1, 1, 1], [1, 1, 1], [2]],
        'ttl_and_probes_array': [[2, 6], [3, 6], [4, 6], [5, 6], [6, 6], [7, 6], [8, 6], [9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6], [15, 6], [16, 6], [17, 6], [18, 6], [19, 6], [20, 6], [21, 6], [22, 6], [23, 6], [24, 6], [25, 6], [26, 6], [27, 6], [28, 6], [29, 6], [30, 6], [31, 6], [32, 6]]
        }
    round_ = 2
    results = calculate_probes_with_inference_with_clickhouse_parameter(dict_result, round_)
'''

def split_into_chunks(lst, x):
    n = len(lst)
    k, m = divmod(n, x)
    k = int(k)
    x = int(x)
    # k = 每份的基本大小，m = 需要“+1”补齐的前 m 份
    chunks = []
    start = 0
    for i in range(int(x)):
        end = start + k + (1 if i < m else 0)
        chunks.append(lst[start:end])
        start = end
    return chunks

import csv
def merge_csv_files(file_list, output_path):
    """
    将 file_list 中的 CSV 文件合并为一个 CSV，仅保留第一个文件的表头
    file_list: 包含 CSV 文件路径的列表
    output_path: 合并后 CSV 的保存路径
    """
    with open(output_path, 'w', newline='', encoding='utf-8') as fout:
        writer = None
        for idx, csv_path in enumerate(file_list):
            with open(csv_path, newline='', encoding='utf-8') as fin:
                reader = csv.reader(fin)
                header = next(reader)
                if idx == 0:
                    writer = csv.writer(fout)
                    writer.writerow(header)  # 只写入第一个文件的表头
                # 写入数据行，忽略后续文件的表头
                for row in reader:
                    writer.writerow(row)